-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Июл 04 2021 г., 10:09
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `garton5k_wp1`
--

-- --------------------------------------------------------

--
-- Структура таблицы `wp_actionscheduler_actions`
--
-- Создание: Июн 01 2021 г., 11:15
--

DROP TABLE IF EXISTS `wp_actionscheduler_actions`;
CREATE TABLE `wp_actionscheduler_actions` (
  `action_id` bigint(20) UNSIGNED NOT NULL,
  `hook` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `scheduled_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `scheduled_date_local` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `args` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schedule` longtext COLLATE utf8mb4_unicode_520_ci,
  `group_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `attempts` int(11) NOT NULL DEFAULT '0',
  `last_attempt_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_attempt_local` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `claim_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `extended_args` varchar(8000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_actionscheduler_actions`
--

INSERT INTO `wp_actionscheduler_actions` (`action_id`, `hook`, `status`, `scheduled_date_gmt`, `scheduled_date_local`, `args`, `schedule`, `group_id`, `attempts`, `last_attempt_gmt`, `last_attempt_local`, `claim_id`, `extended_args`) VALUES
(6, 'action_scheduler/migration_hook', 'complete', '2021-06-01 11:17:01', '2021-06-01 11:17:01', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1622546221;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1622546221;}', 1, 1, '2021-06-01 11:17:08', '2021-06-01 14:17:08', 0, NULL),
(7, 'wc-admin_import_customers', 'complete', '2021-06-01 19:08:26', '2021-06-01 19:08:26', '[1]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1622574506;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1622574506;}', 2, 1, '2021-06-01 20:57:48', '2021-06-01 23:57:48', 0, NULL),
(8, 'wc-admin_import_orders', 'complete', '2021-06-01 19:08:26', '2021-06-01 19:08:26', '[22]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1622574506;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1622574506;}', 2, 1, '2021-06-01 20:57:48', '2021-06-01 23:57:48', 0, NULL),
(9, 'action_scheduler/migration_hook', 'complete', '2021-06-03 19:54:00', '2021-06-03 19:54:00', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1622750040;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1622750040;}', 1, 1, '2021-06-03 19:54:21', '2021-06-03 22:54:21', 0, NULL),
(10, 'wc-admin_import_customers', 'complete', '2021-06-03 20:13:44', '2021-06-03 20:13:44', '[1]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1622751224;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1622751224;}', 2, 1, '2021-06-03 20:14:09', '2021-06-03 23:14:09', 0, NULL),
(11, 'wc-admin_import_orders', 'complete', '2021-06-03 20:13:44', '2021-06-03 20:13:44', '[206]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1622751224;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1622751224;}', 2, 1, '2021-06-03 20:14:09', '2021-06-03 23:14:09', 0, NULL),
(12, 'wc-admin_import_customers', 'complete', '2021-06-03 20:29:55', '2021-06-03 20:29:55', '[1]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1622752195;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1622752195;}', 2, 1, '2021-06-03 20:30:11', '2021-06-03 23:30:11', 0, NULL),
(13, 'wc-admin_import_orders', 'complete', '2021-06-03 20:29:55', '2021-06-03 20:29:55', '[206]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1622752195;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1622752195;}', 2, 1, '2021-06-03 20:30:11', '2021-06-03 23:30:11', 0, NULL),
(14, 'wc-admin_import_orders', 'complete', '2021-06-15 15:32:40', '2021-06-15 15:32:40', '[220]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1623771160;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1623771160;}', 2, 1, '2021-06-15 15:33:10', '2021-06-15 18:33:10', 0, NULL),
(15, 'wc-admin_import_orders', 'complete', '2021-06-15 21:06:56', '2021-06-15 21:06:56', '[221]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1623791216;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1623791216;}', 2, 1, '2021-06-15 21:07:08', '2021-06-16 00:07:08', 0, NULL),
(16, 'wc-admin_import_orders', 'complete', '2021-06-15 23:47:12', '2021-06-15 23:47:12', '[221]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1623800832;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1623800832;}', 2, 1, '2021-06-15 23:47:48', '2021-06-16 02:47:48', 0, NULL),
(17, 'wc-admin_import_orders', 'complete', '2021-06-15 23:48:14', '2021-06-15 23:48:14', '[22]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1623800894;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1623800894;}', 2, 1, '2021-06-15 23:48:53', '2021-06-16 02:48:53', 0, NULL),
(18, 'wc-admin_import_orders', 'complete', '2021-06-15 23:48:35', '2021-06-15 23:48:35', '[220]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1623800915;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1623800915;}', 2, 1, '2021-06-15 23:48:53', '2021-06-16 02:48:53', 0, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_actionscheduler_claims`
--
-- Создание: Июн 01 2021 г., 11:16
--

DROP TABLE IF EXISTS `wp_actionscheduler_claims`;
CREATE TABLE `wp_actionscheduler_claims` (
  `claim_id` bigint(20) UNSIGNED NOT NULL,
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_actionscheduler_groups`
--
-- Создание: Июн 01 2021 г., 11:16
--

DROP TABLE IF EXISTS `wp_actionscheduler_groups`;
CREATE TABLE `wp_actionscheduler_groups` (
  `group_id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_actionscheduler_groups`
--

INSERT INTO `wp_actionscheduler_groups` (`group_id`, `slug`) VALUES
(1, 'action-scheduler-migration'),
(2, 'wc-admin-data');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_actionscheduler_logs`
--
-- Создание: Июн 01 2021 г., 11:16
--

DROP TABLE IF EXISTS `wp_actionscheduler_logs`;
CREATE TABLE `wp_actionscheduler_logs` (
  `log_id` bigint(20) UNSIGNED NOT NULL,
  `action_id` bigint(20) UNSIGNED NOT NULL,
  `message` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `log_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `log_date_local` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_actionscheduler_logs`
--

INSERT INTO `wp_actionscheduler_logs` (`log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES
(1, 6, 'действие создано', '2021-06-01 11:16:01', '2021-06-01 11:16:01'),
(2, 6, 'действие началось через Async Request', '2021-06-01 11:17:08', '2021-06-01 11:17:08'),
(3, 6, 'действие завершено через Async Request', '2021-06-01 11:17:08', '2021-06-01 11:17:08'),
(4, 7, 'действие создано', '2021-06-01 19:08:21', '2021-06-01 19:08:21'),
(5, 8, 'действие создано', '2021-06-01 19:08:21', '2021-06-01 19:08:21'),
(6, 7, 'действие началось через WP Cron', '2021-06-01 20:57:48', '2021-06-01 20:57:48'),
(7, 7, 'действие завершено через WP Cron', '2021-06-01 20:57:48', '2021-06-01 20:57:48'),
(8, 8, 'действие началось через WP Cron', '2021-06-01 20:57:48', '2021-06-01 20:57:48'),
(9, 8, 'действие завершено через WP Cron', '2021-06-01 20:57:48', '2021-06-01 20:57:48'),
(10, 9, 'действие создано', '2021-06-03 19:53:00', '2021-06-03 19:53:00'),
(11, 9, 'действие началось через WP Cron', '2021-06-03 19:54:21', '2021-06-03 19:54:21'),
(12, 9, 'действие завершено через WP Cron', '2021-06-03 19:54:21', '2021-06-03 19:54:21'),
(13, 10, 'действие создано', '2021-06-03 20:13:39', '2021-06-03 20:13:39'),
(14, 11, 'действие создано', '2021-06-03 20:13:39', '2021-06-03 20:13:39'),
(15, 10, 'действие началось через WP Cron', '2021-06-03 20:14:09', '2021-06-03 20:14:09'),
(16, 10, 'действие завершено через WP Cron', '2021-06-03 20:14:09', '2021-06-03 20:14:09'),
(17, 11, 'действие началось через WP Cron', '2021-06-03 20:14:09', '2021-06-03 20:14:09'),
(18, 11, 'действие завершено через WP Cron', '2021-06-03 20:14:09', '2021-06-03 20:14:09'),
(19, 12, 'действие создано', '2021-06-03 20:29:50', '2021-06-03 20:29:50'),
(20, 13, 'действие создано', '2021-06-03 20:29:50', '2021-06-03 20:29:50'),
(21, 12, 'действие началось через WP Cron', '2021-06-03 20:30:11', '2021-06-03 20:30:11'),
(22, 12, 'действие завершено через WP Cron', '2021-06-03 20:30:11', '2021-06-03 20:30:11'),
(23, 13, 'действие началось через WP Cron', '2021-06-03 20:30:11', '2021-06-03 20:30:11'),
(24, 13, 'действие завершено через WP Cron', '2021-06-03 20:30:11', '2021-06-03 20:30:11'),
(25, 14, 'действие создано', '2021-06-15 15:32:35', '2021-06-15 15:32:35'),
(26, 14, 'действие началось через WP Cron', '2021-06-15 15:33:10', '2021-06-15 15:33:10'),
(27, 14, 'действие завершено через WP Cron', '2021-06-15 15:33:10', '2021-06-15 15:33:10'),
(28, 15, 'действие создано', '2021-06-15 21:06:51', '2021-06-15 21:06:51'),
(29, 15, 'действие началось через WP Cron', '2021-06-15 21:07:08', '2021-06-15 21:07:08'),
(30, 15, 'действие завершено через WP Cron', '2021-06-15 21:07:08', '2021-06-15 21:07:08'),
(31, 16, 'действие создано', '2021-06-15 23:47:07', '2021-06-15 23:47:07'),
(32, 16, 'действие началось через Async Request', '2021-06-15 23:47:48', '2021-06-15 23:47:48'),
(33, 16, 'действие завершено через Async Request', '2021-06-15 23:47:48', '2021-06-15 23:47:48'),
(34, 17, 'действие создано', '2021-06-15 23:48:09', '2021-06-15 23:48:09'),
(35, 18, 'действие создано', '2021-06-15 23:48:30', '2021-06-15 23:48:30'),
(36, 17, 'действие началось через Async Request', '2021-06-15 23:48:53', '2021-06-15 23:48:53'),
(37, 17, 'действие завершено через Async Request', '2021-06-15 23:48:53', '2021-06-15 23:48:53'),
(38, 18, 'действие началось через Async Request', '2021-06-15 23:48:53', '2021-06-15 23:48:53'),
(39, 18, 'действие завершено через Async Request', '2021-06-15 23:48:53', '2021-06-15 23:48:53');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_commentmeta`
--
-- Создание: Июн 01 2021 г., 08:28
--

DROP TABLE IF EXISTS `wp_commentmeta`;
CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_commentmeta`
--

INSERT INTO `wp_commentmeta` (`meta_id`, `comment_id`, `meta_key`, `meta_value`) VALUES
(1, 3, 'rating', '4'),
(2, 3, 'verified', '0'),
(3, 3, '_wp_trash_meta_status', '1'),
(4, 3, '_wp_trash_meta_time', '1622718657'),
(5, 1, '_wp_trash_meta_status', '1'),
(6, 1, '_wp_trash_meta_time', '1622718659');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_comments`
--
-- Создание: Июн 01 2021 г., 11:16
--

DROP TABLE IF EXISTS `wp_comments`;
CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Автор комментария', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2021-04-08 10:30:00', '2021-04-08 07:30:00', 'Привет! Это комментарий.\nЧтобы начать модерировать, редактировать и удалять комментарии, перейдите на экран «Комментарии» в консоли.\nАватары авторов комментариев загружаются с сервиса <a href=\"https://ru.gravatar.com\">Gravatar</a>.', 0, 'trash', '', 'comment', 0, 0),
(2, 22, 'WooCommerce', 'woocommerce@manufacturer-cloth.ru', '', '', '2021-06-01 22:08:21', '2021-06-01 19:08:21', 'Оплата по факту доставки. Статус заказа изменен с В ожидании оплаты на Обработка.', 0, 'post-trashed', 'WooCommerce', 'order_note', 0, 0),
(3, 29, 'admin', 'gartonot62@gmail.com', 'http://manufacturer-cloth.ru', '46.61.99.57', '2021-06-03 14:10:21', '2021-06-03 11:10:21', 'ыфв', 0, 'trash', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.72 YaBrowser/21.5.1.330 Yowser/2.5 Safari/537.36', 'review', 0, 1),
(4, 206, 'WooCommerce', 'woocommerce@manufacturer-cloth.ru', '', '', '2021-06-03 23:13:39', '2021-06-03 20:13:39', 'Оплата по факту доставки. Статус заказа изменен с В ожидании оплаты на Обработка.', 0, '1', 'WooCommerce', 'order_note', 0, 0),
(5, 206, 'admin', 'gartonot62@gmail.com', '', '', '2021-06-03 23:29:50', '2021-06-03 20:29:50', 'Статус заказа изменен с Обработка на Выполнен.', 0, '1', 'WooCommerce', 'order_note', 0, 0),
(6, 220, 'WooCommerce', 'woocommerce@manufacturer-cloth.ru', '', '', '2021-06-15 18:32:35', '2021-06-15 15:32:35', 'Оплата по факту доставки. Статус заказа изменён с «В ожидании оплаты» на «Обработка».', 0, 'post-trashed', 'WooCommerce', 'order_note', 0, 0),
(7, 221, 'WooCommerce', 'woocommerce@manufacturer-cloth.ru', '', '', '2021-06-16 00:06:51', '2021-06-15 21:06:51', 'Оплата по факту доставки. Статус заказа изменён с «В ожидании оплаты» на «Обработка».', 0, 'post-trashed', 'WooCommerce', 'order_note', 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_links`
--
-- Создание: Июн 01 2021 г., 08:28
--

DROP TABLE IF EXISTS `wp_links`;
CREATE TABLE `wp_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_options`
--
-- Создание: Июн 01 2021 г., 08:28
--

DROP TABLE IF EXISTS `wp_options`;
CREATE TABLE `wp_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'https://manufacturer-cloth.ru', 'yes'),
(2, 'home', 'https://manufacturer-cloth.ru', 'yes'),
(3, 'blogname', 'Магазин Одежды | Minufacturer-Cloth', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'gartonot62@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'd.m.Y', 'yes'),
(24, 'time_format', 'H:i', 'yes'),
(25, 'links_updated_date_format', 'd.m.Y H:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%category%/%postname%', 'yes'),
(29, 'rewrite_rules', 'a:168:{s:24:\"^wc-auth/v([1]{1})/(.*)?\";s:63:\"index.php?wc-auth-version=$matches[1]&wc-auth-route=$matches[2]\";s:22:\"^wc-api/v([1-3]{1})/?$\";s:51:\"index.php?wc-api-version=$matches[1]&wc-api-route=/\";s:24:\"^wc-api/v([1-3]{1})(.*)?\";s:61:\"index.php?wc-api-version=$matches[1]&wc-api-route=$matches[2]\";s:7:\"shop/?$\";s:27:\"index.php?post_type=product\";s:37:\"shop/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=product&feed=$matches[1]\";s:32:\"shop/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=product&feed=$matches[1]\";s:24:\"shop/page/([0-9]{1,})/?$\";s:45:\"index.php?post_type=product&paged=$matches[1]\";s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:17:\"^wp-sitemap\\.xml$\";s:23:\"index.php?sitemap=index\";s:17:\"^wp-sitemap\\.xsl$\";s:36:\"index.php?sitemap-stylesheet=sitemap\";s:23:\"^wp-sitemap-index\\.xsl$\";s:34:\"index.php?sitemap-stylesheet=index\";s:48:\"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$\";s:75:\"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]\";s:34:\"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$\";s:47:\"index.php?sitemap=$matches[1]&paged=$matches[2]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:32:\"category/(.+?)/wc-api(/(.*))?/?$\";s:54:\"index.php?category_name=$matches[1]&wc-api=$matches[3]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:29:\"tag/([^/]+)/wc-api(/(.*))?/?$\";s:44:\"index.php?tag=$matches[1]&wc-api=$matches[3]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:55:\"product-category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:50:\"product-category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:31:\"product-category/(.+?)/embed/?$\";s:44:\"index.php?product_cat=$matches[1]&embed=true\";s:43:\"product-category/(.+?)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_cat=$matches[1]&paged=$matches[2]\";s:25:\"product-category/(.+?)/?$\";s:33:\"index.php?product_cat=$matches[1]\";s:52:\"product-tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:47:\"product-tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:28:\"product-tag/([^/]+)/embed/?$\";s:44:\"index.php?product_tag=$matches[1]&embed=true\";s:40:\"product-tag/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_tag=$matches[1]&paged=$matches[2]\";s:22:\"product-tag/([^/]+)/?$\";s:33:\"index.php?product_tag=$matches[1]\";s:35:\"product/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"product/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"product/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"product/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:24:\"product/([^/]+)/embed/?$\";s:40:\"index.php?product=$matches[1]&embed=true\";s:28:\"product/([^/]+)/trackback/?$\";s:34:\"index.php?product=$matches[1]&tb=1\";s:48:\"product/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?product=$matches[1]&feed=$matches[2]\";s:43:\"product/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?product=$matches[1]&feed=$matches[2]\";s:36:\"product/([^/]+)/page/?([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&paged=$matches[2]\";s:43:\"product/([^/]+)/comment-page-([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&cpage=$matches[2]\";s:33:\"product/([^/]+)/wc-api(/(.*))?/?$\";s:48:\"index.php?product=$matches[1]&wc-api=$matches[3]\";s:39:\"product/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:50:\"product/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:32:\"product/([^/]+)(?:/([0-9]+))?/?$\";s:46:\"index.php?product=$matches[1]&page=$matches[2]\";s:24:\"product/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:34:\"product/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:54:\"product/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:30:\"product/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:13:\"favicon\\.ico$\";s:19:\"index.php?favicon=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:38:\"index.php?&page_id=6&cpage=$matches[1]\";s:17:\"wc-api(/(.*))?/?$\";s:29:\"index.php?&wc-api=$matches[2]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:26:\"comments/wc-api(/(.*))?/?$\";s:29:\"index.php?&wc-api=$matches[2]\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:29:\"search/(.+)/wc-api(/(.*))?/?$\";s:42:\"index.php?s=$matches[1]&wc-api=$matches[3]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:32:\"author/([^/]+)/wc-api(/(.*))?/?$\";s:52:\"index.php?author_name=$matches[1]&wc-api=$matches[3]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:54:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:82:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc-api=$matches[5]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:41:\"([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:66:\"index.php?year=$matches[1]&monthnum=$matches[2]&wc-api=$matches[4]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:28:\"([0-9]{4})/wc-api(/(.*))?/?$\";s:45:\"index.php?year=$matches[1]&wc-api=$matches[3]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:25:\"(.?.+?)/wc-api(/(.*))?/?$\";s:49:\"index.php?pagename=$matches[1]&wc-api=$matches[3]\";s:28:\"(.?.+?)/order-pay(/(.*))?/?$\";s:52:\"index.php?pagename=$matches[1]&order-pay=$matches[3]\";s:33:\"(.?.+?)/order-received(/(.*))?/?$\";s:57:\"index.php?pagename=$matches[1]&order-received=$matches[3]\";s:25:\"(.?.+?)/orders(/(.*))?/?$\";s:49:\"index.php?pagename=$matches[1]&orders=$matches[3]\";s:29:\"(.?.+?)/view-order(/(.*))?/?$\";s:53:\"index.php?pagename=$matches[1]&view-order=$matches[3]\";s:28:\"(.?.+?)/downloads(/(.*))?/?$\";s:52:\"index.php?pagename=$matches[1]&downloads=$matches[3]\";s:31:\"(.?.+?)/edit-account(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-account=$matches[3]\";s:31:\"(.?.+?)/edit-address(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-address=$matches[3]\";s:34:\"(.?.+?)/payment-methods(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&payment-methods=$matches[3]\";s:32:\"(.?.+?)/lost-password(/(.*))?/?$\";s:56:\"index.php?pagename=$matches[1]&lost-password=$matches[3]\";s:34:\"(.?.+?)/customer-logout(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&customer-logout=$matches[3]\";s:37:\"(.?.+?)/add-payment-method(/(.*))?/?$\";s:61:\"index.php?pagename=$matches[1]&add-payment-method=$matches[3]\";s:40:\"(.?.+?)/delete-payment-method(/(.*))?/?$\";s:64:\"index.php?pagename=$matches[1]&delete-payment-method=$matches[3]\";s:45:\"(.?.+?)/set-default-payment-method(/(.*))?/?$\";s:69:\"index.php?pagename=$matches[1]&set-default-payment-method=$matches[3]\";s:31:\".?.+?/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:42:\".?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:31:\".+?/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:41:\".+?/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:61:\".+?/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\".+?/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\".+?/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:37:\".+?/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:22:\"(.+?)/([^/]+)/embed/?$\";s:63:\"index.php?category_name=$matches[1]&name=$matches[2]&embed=true\";s:26:\"(.+?)/([^/]+)/trackback/?$\";s:57:\"index.php?category_name=$matches[1]&name=$matches[2]&tb=1\";s:46:\"(.+?)/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:69:\"index.php?category_name=$matches[1]&name=$matches[2]&feed=$matches[3]\";s:41:\"(.+?)/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:69:\"index.php?category_name=$matches[1]&name=$matches[2]&feed=$matches[3]\";s:34:\"(.+?)/([^/]+)/page/?([0-9]{1,})/?$\";s:70:\"index.php?category_name=$matches[1]&name=$matches[2]&paged=$matches[3]\";s:41:\"(.+?)/([^/]+)/comment-page-([0-9]{1,})/?$\";s:70:\"index.php?category_name=$matches[1]&name=$matches[2]&cpage=$matches[3]\";s:31:\"(.+?)/([^/]+)/wc-api(/(.*))?/?$\";s:71:\"index.php?category_name=$matches[1]&name=$matches[2]&wc-api=$matches[4]\";s:35:\".+?/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:46:\".+?/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:30:\"(.+?)/([^/]+)(?:/([0-9]+))?/?$\";s:69:\"index.php?category_name=$matches[1]&name=$matches[2]&page=$matches[3]\";s:20:\".+?/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:30:\".+?/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:50:\".+?/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:45:\".+?/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:45:\".+?/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:26:\".+?/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:38:\"(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:33:\"(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:14:\"(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:26:\"(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:33:\"(.+?)/comment-page-([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&cpage=$matches[2]\";s:23:\"(.+?)/wc-api(/(.*))?/?$\";s:54:\"index.php?category_name=$matches[1]&wc-api=$matches[3]\";s:8:\"(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:4:{i:0;s:23:\"cyrlitera/cyrlitera.php\";i:1;s:47:\"really-simple-ssl/rlrsssl-really-simple-ssl.php\";i:2;s:56:\"woo-checkout-field-editor-pro/checkout-form-designer.php\";i:3;s:27:\"woocommerce/woocommerce.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '3', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'twentyfifteen', 'yes'),
(41, 'stylesheet', 'twentyfifteen', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '49752', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '1', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:0:{}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '6', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1633419000', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'initial_db_version', '49752', 'yes'),
(99, 'wp_user_roles', 'a:7:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:114:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:8:\"customer\";a:2:{s:4:\"name\";s:8:\"Customer\";s:12:\"capabilities\";a:1:{s:4:\"read\";b:1;}}s:12:\"shop_manager\";a:2:{s:4:\"name\";s:12:\"Shop manager\";s:12:\"capabilities\";a:92:{s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:4:\"read\";b:1;s:18:\"read_private_pages\";b:1;s:18:\"read_private_posts\";b:1;s:10:\"edit_posts\";b:1;s:10:\"edit_pages\";b:1;s:20:\"edit_published_posts\";b:1;s:20:\"edit_published_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"edit_private_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:17:\"edit_others_pages\";b:1;s:13:\"publish_posts\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_posts\";b:1;s:12:\"delete_pages\";b:1;s:20:\"delete_private_pages\";b:1;s:20:\"delete_private_posts\";b:1;s:22:\"delete_published_pages\";b:1;s:22:\"delete_published_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:19:\"delete_others_pages\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:17:\"moderate_comments\";b:1;s:12:\"upload_files\";b:1;s:6:\"export\";b:1;s:6:\"import\";b:1;s:10:\"list_users\";b:1;s:18:\"edit_theme_options\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;}}}', 'yes'),
(100, 'fresh_site', '0', 'yes'),
(101, 'WPLANG', 'ru_RU', 'yes'),
(102, 'widget_search', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(103, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'widget_archives', 'a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_meta', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'sidebars_widgets', 'a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:13:\"array_version\";i:3;}', 'yes'),
(108, 'cron', 'a:14:{i:1625122980;a:1:{s:26:\"action_scheduler_run_queue\";a:1:{s:32:\"0d04ed39571b55704c122d726248bbac\";a:3:{s:8:\"schedule\";s:12:\"every_minute\";s:4:\"args\";a:1:{i:0;s:7:\"WP Cron\";}s:8:\"interval\";i:60;}}}i:1625123761;a:1:{s:33:\"wc_admin_process_orders_milestone\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1625123766;a:1:{s:29:\"wc_admin_unsnooze_admin_notes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1625124600;a:6:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:18:\"wp_https_detection\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1625126529;a:1:{s:32:\"woocommerce_cancel_unpaid_orders\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1625137517;a:3:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1625138161;a:1:{s:14:\"wc_admin_daily\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1625138170;a:2:{s:33:\"woocommerce_cleanup_personal_data\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:30:\"woocommerce_tracker_send_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1625138220;a:1:{s:25:\"woocommerce_geoip_updater\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:11:\"fifteendays\";s:4:\"args\";a:0:{}s:8:\"interval\";i:1296000;}}}i:1625148960;a:1:{s:24:\"woocommerce_cleanup_logs\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1625159760;a:1:{s:28:\"woocommerce_cleanup_sessions\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1625173200;a:1:{s:27:\"woocommerce_scheduled_sales\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1625211000;a:1:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}s:7:\"version\";i:2;}', 'yes'),
(109, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(112, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(113, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(114, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(115, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(116, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(117, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(119, 'recovery_keys', 'a:0:{}', 'yes'),
(120, 'https_detection_errors', 'a:0:{}', 'yes'),
(122, 'theme_mods_twentytwentyone', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1622546006;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";}s:9:\"sidebar-2\";a:3:{i:0;s:10:\"archives-2\";i:1;s:12:\"categories-2\";i:2;s:6:\"meta-2\";}}}}', 'yes'),
(138, 'auto_core_update_notified', 'a:4:{s:4:\"type\";s:7:\"success\";s:5:\"email\";s:20:\"gartonot62@gmail.com\";s:7:\"version\";s:5:\"5.7.2\";s:9:\"timestamp\";i:1622536432;}', 'no'),
(141, '_transient_health-check-site-status-result', '{\"good\":16,\"recommended\":4,\"critical\":0}', 'yes'),
(149, 'can_compress_scripts', '1', 'no'),
(160, 'recently_activated', 'a:1:{s:26:\"robokassa/wp_robokassa.php\";i:1622749980;}', 'yes'),
(169, 'rlrsssl_options', 'a:15:{s:12:\"site_has_ssl\";b:1;s:4:\"hsts\";b:0;s:22:\"htaccess_warning_shown\";b:0;s:19:\"review_notice_shown\";b:0;s:25:\"ssl_success_message_shown\";b:0;s:26:\"autoreplace_insecure_links\";b:1;s:17:\"plugin_db_version\";s:6:\"4.0.15\";s:20:\"do_not_edit_htaccess\";b:0;s:17:\"htaccess_redirect\";b:1;s:11:\"ssl_enabled\";b:1;s:19:\"javascript_redirect\";b:0;s:11:\"wp_redirect\";b:1;s:31:\"switch_mixed_content_fixer_hook\";b:0;s:19:\"dismiss_all_notices\";b:0;s:21:\"dismiss_review_notice\";b:0;}', 'yes'),
(170, 'rsssl_remaining_tasks', '1', 'yes'),
(179, 'rsssl_current_version', '4.0.15', 'yes'),
(182, 'rsssl_activation_timestamp', '1622545592', 'yes'),
(188, 'finished_updating_comment_type', '1', 'yes'),
(205, 'category_children', 'a:0:{}', 'yes'),
(210, 'wbcr_cyrlitera_use_transliteration', '1', 'yes'),
(211, 'wbcr_cyrlitera_use_transliteration_filename', '1', 'yes'),
(212, 'wbcr_cyrlitera_filename_to_lowercase', '1', 'yes'),
(213, 'wbcr_cyrlitera_plugin_activated', '1622545843', 'yes'),
(214, 'wbcr_cyrlitera_plugin_version', '1.1.2', 'yes'),
(219, 'wbcr_cyrlitera_use_force_transliteration', '1', 'yes'),
(220, 'wbcr_cyrlitera_redirect_from_old_urls', '1', 'yes'),
(221, 'wbcr_cyrlitera_dont_use_transliteration_on_frontend', '0', 'yes'),
(222, 'wbcr_cyrlitera_custom_symbols_pack', '', 'yes'),
(223, 'wbcr_wp_term_1_old_slug', '%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8', 'no'),
(224, 'wbcr_cyrlitera_transliterate_existing_slugs', '1', 'yes'),
(229, 'current_theme', 'Twenty Fifteen', 'yes'),
(230, 'theme_mods_twentyfifteen', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:7:\"primary\";i:18;}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1622663073;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}}', 'yes'),
(231, 'theme_switched', '', 'yes'),
(238, 'action_scheduler_hybrid_store_demarkation', '5', 'yes'),
(239, 'schema-ActionScheduler_StoreSchema', '3.0.1622546160', 'yes'),
(240, 'schema-ActionScheduler_LoggerSchema', '2.0.1622546160', 'yes'),
(243, 'woocommerce_schema_version', '430', 'yes'),
(244, 'woocommerce_store_address', 'manufacturer-cloth.ru', 'yes'),
(245, 'woocommerce_store_address_2', 'manufacturer-cloth.ru', 'yes'),
(246, 'woocommerce_store_city', 'Ростов-на-Дону', 'yes'),
(247, 'woocommerce_default_country', 'RU', 'yes'),
(248, 'woocommerce_store_postcode', '344000', 'yes'),
(249, 'woocommerce_allowed_countries', 'all', 'yes'),
(250, 'woocommerce_all_except_countries', 'a:0:{}', 'yes'),
(251, 'woocommerce_specific_allowed_countries', 'a:0:{}', 'yes'),
(252, 'woocommerce_ship_to_countries', '', 'yes'),
(253, 'woocommerce_specific_ship_to_countries', 'a:0:{}', 'yes'),
(254, 'woocommerce_default_customer_address', 'base', 'yes'),
(255, 'woocommerce_calc_taxes', 'no', 'yes'),
(256, 'woocommerce_enable_coupons', 'no', 'yes'),
(257, 'woocommerce_calc_discounts_sequentially', 'no', 'no'),
(258, 'woocommerce_currency', 'RUB', 'yes'),
(259, 'woocommerce_currency_pos', 'left', 'yes'),
(260, 'woocommerce_price_thousand_sep', '', 'yes'),
(261, 'woocommerce_price_decimal_sep', '', 'yes'),
(262, 'woocommerce_price_num_decimals', '0', 'yes'),
(263, 'woocommerce_shop_page_id', '6', 'yes'),
(264, 'woocommerce_cart_redirect_after_add', 'no', 'yes'),
(265, 'woocommerce_enable_ajax_add_to_cart', 'yes', 'yes'),
(266, 'woocommerce_placeholder_image', '5', 'yes'),
(267, 'woocommerce_weight_unit', 'kg', 'yes'),
(268, 'woocommerce_dimension_unit', 'cm', 'yes'),
(269, 'woocommerce_enable_reviews', 'no', 'yes'),
(270, 'woocommerce_review_rating_verification_label', 'yes', 'no'),
(271, 'woocommerce_review_rating_verification_required', 'no', 'no'),
(272, 'woocommerce_enable_review_rating', 'yes', 'yes'),
(273, 'woocommerce_review_rating_required', 'yes', 'no'),
(274, 'woocommerce_manage_stock', 'yes', 'yes'),
(275, 'woocommerce_hold_stock_minutes', '60', 'no'),
(276, 'woocommerce_notify_low_stock', 'yes', 'no'),
(277, 'woocommerce_notify_no_stock', 'yes', 'no'),
(278, 'woocommerce_stock_email_recipient', 'gartonot62@gmail.com', 'no'),
(279, 'woocommerce_notify_low_stock_amount', '2', 'no'),
(280, 'woocommerce_notify_no_stock_amount', '0', 'yes'),
(281, 'woocommerce_hide_out_of_stock_items', 'no', 'yes'),
(282, 'woocommerce_stock_format', '', 'yes'),
(283, 'woocommerce_file_download_method', 'force', 'no'),
(284, 'woocommerce_downloads_require_login', 'no', 'no'),
(285, 'woocommerce_downloads_grant_access_after_payment', 'yes', 'no'),
(286, 'woocommerce_downloads_add_hash_to_filename', 'yes', 'yes'),
(287, 'woocommerce_prices_include_tax', 'no', 'yes'),
(288, 'woocommerce_tax_based_on', 'shipping', 'yes'),
(289, 'woocommerce_shipping_tax_class', 'inherit', 'yes'),
(290, 'woocommerce_tax_round_at_subtotal', 'no', 'yes'),
(291, 'woocommerce_tax_classes', '', 'yes'),
(292, 'woocommerce_tax_display_shop', 'excl', 'yes'),
(293, 'woocommerce_tax_display_cart', 'excl', 'yes'),
(294, 'woocommerce_price_display_suffix', '', 'yes'),
(295, 'woocommerce_tax_total_display', 'itemized', 'no'),
(296, 'woocommerce_enable_shipping_calc', 'yes', 'no'),
(297, 'woocommerce_shipping_cost_requires_address', 'no', 'yes'),
(298, 'woocommerce_ship_to_destination', 'billing', 'no'),
(299, 'woocommerce_shipping_debug_mode', 'no', 'yes'),
(300, 'woocommerce_enable_guest_checkout', 'yes', 'no'),
(301, 'woocommerce_enable_checkout_login_reminder', 'yes', 'no'),
(302, 'woocommerce_enable_signup_and_login_from_checkout', 'yes', 'no'),
(303, 'woocommerce_enable_myaccount_registration', 'no', 'no'),
(304, 'woocommerce_registration_generate_username', 'yes', 'no'),
(305, 'woocommerce_registration_generate_password', 'yes', 'no'),
(306, 'woocommerce_erasure_request_removes_order_data', 'no', 'no'),
(307, 'woocommerce_erasure_request_removes_download_data', 'no', 'no'),
(308, 'woocommerce_allow_bulk_remove_personal_data', 'no', 'no'),
(309, 'woocommerce_registration_privacy_policy_text', 'Ваши личные данные будут использоваться для упрощения вашей работы с сайтом, управления доступом к вашей учётной записи и для других целей, описанных в нашей [privacy_policy].', 'yes'),
(310, 'woocommerce_checkout_privacy_policy_text', 'Ваши личные данные будут использоваться для обработки ваших заказов, упрощения вашей работы с сайтом и для других целей, описанных в нашей [privacy_policy].', 'yes'),
(311, 'woocommerce_delete_inactive_accounts', 'a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}', 'no'),
(312, 'woocommerce_trash_pending_orders', 'a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:4:\"days\";}', 'no'),
(313, 'woocommerce_trash_failed_orders', 'a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:4:\"days\";}', 'no'),
(314, 'woocommerce_trash_cancelled_orders', 'a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:4:\"days\";}', 'no'),
(315, 'woocommerce_anonymize_completed_orders', 'a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}', 'no'),
(316, 'woocommerce_email_from_name', 'Minufacturer-Cloth', 'no'),
(317, 'woocommerce_email_from_address', 'gartonot62@gmail.com', 'no'),
(318, 'woocommerce_email_header_image', '', 'no'),
(319, 'woocommerce_email_footer_text', '{site_title} &mdash; Built with {WooCommerce}', 'no'),
(320, 'woocommerce_email_base_color', '#96588a', 'no'),
(321, 'woocommerce_email_background_color', '#f7f7f7', 'no'),
(322, 'woocommerce_email_body_background_color', '#ffffff', 'no'),
(323, 'woocommerce_email_text_color', '#3c3c3c', 'no'),
(324, 'woocommerce_merchant_email_notifications', 'no', 'no'),
(325, 'woocommerce_cart_page_id', '7', 'no'),
(326, 'woocommerce_checkout_page_id', '8', 'no'),
(327, 'woocommerce_myaccount_page_id', '9', 'no'),
(328, 'woocommerce_terms_page_id', '', 'no'),
(329, 'woocommerce_checkout_pay_endpoint', 'order-pay', 'yes'),
(330, 'woocommerce_checkout_order_received_endpoint', 'order-received', 'yes'),
(331, 'woocommerce_myaccount_add_payment_method_endpoint', 'add-payment-method', 'yes'),
(332, 'woocommerce_myaccount_delete_payment_method_endpoint', 'delete-payment-method', 'yes'),
(333, 'woocommerce_myaccount_set_default_payment_method_endpoint', 'set-default-payment-method', 'yes'),
(334, 'woocommerce_myaccount_orders_endpoint', 'orders', 'yes'),
(335, 'woocommerce_myaccount_view_order_endpoint', 'view-order', 'yes'),
(336, 'woocommerce_myaccount_downloads_endpoint', 'downloads', 'yes'),
(337, 'woocommerce_myaccount_edit_account_endpoint', 'edit-account', 'yes'),
(338, 'woocommerce_myaccount_edit_address_endpoint', 'edit-address', 'yes'),
(339, 'woocommerce_myaccount_payment_methods_endpoint', 'payment-methods', 'yes'),
(340, 'woocommerce_myaccount_lost_password_endpoint', 'lost-password', 'yes'),
(341, 'woocommerce_logout_endpoint', 'customer-logout', 'yes'),
(342, 'woocommerce_api_enabled', 'no', 'yes'),
(343, 'woocommerce_allow_tracking', 'no', 'no'),
(344, 'woocommerce_show_marketplace_suggestions', 'yes', 'no'),
(345, 'woocommerce_single_image_width', '600', 'yes'),
(346, 'woocommerce_thumbnail_image_width', '300', 'yes'),
(347, 'woocommerce_checkout_highlight_required_fields', 'yes', 'yes'),
(348, 'woocommerce_demo_store', 'no', 'no'),
(349, 'woocommerce_permalinks', 'a:5:{s:12:\"product_base\";s:7:\"product\";s:13:\"category_base\";s:16:\"product-category\";s:8:\"tag_base\";s:11:\"product-tag\";s:14:\"attribute_base\";s:0:\"\";s:22:\"use_verbose_page_rules\";b:0;}', 'yes'),
(350, 'current_theme_supports_woocommerce', 'yes', 'yes'),
(351, 'woocommerce_queue_flush_rewrite_rules', 'no', 'yes'),
(352, '_transient_wc_attribute_taxonomies', 'a:0:{}', 'yes'),
(354, 'default_product_cat', '15', 'yes'),
(357, 'woocommerce_version', '5.3.0', 'yes'),
(358, 'woocommerce_db_version', '5.3.0', 'yes'),
(362, '_transient_jetpack_autoloader_plugin_paths', 'a:1:{i:0;s:29:\"{{WP_PLUGIN_DIR}}/woocommerce\";}', 'yes'),
(363, 'action_scheduler_lock_async-request-runner', '1625052428', 'yes'),
(364, 'woocommerce_admin_notices', 'a:0:{}', 'yes'),
(365, 'woocommerce_maxmind_geolocation_settings', 'a:1:{s:15:\"database_prefix\";s:32:\"9JkczV8bK50odLAgOeYNnPFGWTaGwhQh\";}', 'yes'),
(366, '_transient_woocommerce_webhook_ids_status_active', 'a:0:{}', 'yes'),
(367, 'widget_woocommerce_widget_cart', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(368, 'widget_woocommerce_layered_nav_filters', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(369, 'widget_woocommerce_layered_nav', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(370, 'widget_woocommerce_price_filter', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(371, 'widget_woocommerce_product_categories', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(372, 'widget_woocommerce_product_search', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(373, 'widget_woocommerce_product_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(374, 'widget_woocommerce_products', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(375, 'widget_woocommerce_recently_viewed_products', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(376, 'widget_woocommerce_top_rated_products', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(377, 'widget_woocommerce_recent_reviews', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(378, 'widget_woocommerce_rating_filter', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(381, 'woocommerce_admin_version', '2.2.6', 'yes'),
(382, 'woocommerce_admin_install_timestamp', '1622546161', 'yes'),
(383, 'wc_remote_inbox_notifications_wca_updated', '', 'yes'),
(387, 'wc_blocks_db_schema_version', '260', 'yes'),
(388, 'wc_remote_inbox_notifications_stored_state', 'O:8:\"stdClass\":3:{s:22:\"there_were_no_products\";b:1;s:22:\"there_are_now_products\";b:1;s:17:\"new_product_count\";i:0;}', 'yes'),
(389, 'woocommerce_meta_box_errors', 'a:0:{}', 'yes');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(390, 'wc_remote_inbox_notifications_specs', 'a:28:{s:19:\"eu_vat_changes_2021\";O:8:\"stdClass\":8:{s:4:\"slug\";s:19:\"eu_vat_changes_2021\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:54:\"Get your business ready for the new EU tax regulations\";s:7:\"content\";s:617:\"On July 1, 2021, new taxation rules will come into play when the <a href=\"https://ec.europa.eu/taxation_customs/business/vat/modernising-vat-cross-border-ecommerce_en\">European Union (EU) Value-Added Tax (VAT) eCommerce package</a> takes effect.<br/><br/>The new regulations will impact virtually every B2C business involved in cross-border eCommerce trade with the EU.<br/><br/>We therefore recommend <a href=\"https://woocommerce.com/posts/new-eu-vat-regulations\">familiarizing yourself with the new updates</a>, and consult with a tax professional to ensure your business is following regulations and best practice.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:19:\"eu_vat_changes_2021\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:39:\"Learn more about the EU tax regulations\";}}s:3:\"url\";s:52:\"https://woocommerce.com/posts/new-eu-vat-regulations\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:3:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2021-06-24 00:00:00\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:19:\"publish_before_time\";s:14:\"publish_before\";s:19:\"2021-07-11 00:00:00\";}i:2;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:3:{i:0;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:29:\"woocommerce_allowed_countries\";s:5:\"value\";s:3:\"all\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:1;a:2:{i:0;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:29:\"woocommerce_allowed_countries\";s:5:\"value\";s:10:\"all_except\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:27:{i:0;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"BE\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:1;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"BG\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:2;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"CZ\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:3;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"DK\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:4;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"DE\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:5;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"EE\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:6;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"IE\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:7;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"EL\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:8;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"ES\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:9;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"FR\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:10;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"HR\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:11;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"IT\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:12;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"CY\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:13;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"LV\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:14;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"LT\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:15;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"LU\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:16;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"HU\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:17;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"MT\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:18;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"NL\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:19;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"AT\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:20;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"PL\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:21;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"PT\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:22;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"RO\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:23;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"SI\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:24;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"SK\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:25;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"FI\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:26;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"SE\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}}}}i:2;a:3:{i:0;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:29:\"woocommerce_allowed_countries\";s:5:\"value\";s:3:\"all\";s:7:\"default\";b:0;s:9:\"operation\";s:2:\"!=\";}i:1;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:29:\"woocommerce_allowed_countries\";s:5:\"value\";s:10:\"all_except\";s:7:\"default\";b:0;s:9:\"operation\";s:2:\"!=\";}i:2;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:27:{i:0;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"BE\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:1;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"BG\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:2;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"CZ\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:3;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"DK\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:4;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"DE\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:5;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"EE\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:6;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"IE\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:7;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"EL\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:8;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"ES\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:9;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"FR\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:10;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"HR\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:11;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"IT\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:12;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"CY\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:13;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"LV\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:14;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"LT\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:15;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"LU\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:16;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"HU\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:17;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"MT\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:18;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"NL\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:19;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"AT\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:20;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"PL\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:21;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"PT\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:22;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"RO\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:23;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"SI\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:24;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"SK\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:25;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"FI\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:26;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"SE\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}}}}}}}}s:20:\"paypal_ppcp_gtm_2021\";O:8:\"stdClass\":8:{s:4:\"slug\";s:20:\"paypal_ppcp_gtm_2021\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:38:\"Offer more options with the new PayPal\";s:7:\"content\";s:113:\"Get the latest PayPal extension for a full suite of payment methods with extensive currency and country coverage.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:36:\"open_wc_paypal_payments_product_page\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:61:\"https://woocommerce.com/products/woocommerce-paypal-payments/\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:4:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2021-04-05 00:00:00\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:19:\"publish_before_time\";s:14:\"publish_before\";s:19:\"2021-04-21 00:00:00\";}i:2;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:7:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:43:\"woocommerce-gateway-paypal-express-checkout\";}}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:30:\"woocommerce-gateway-paypal-pro\";}}i:2;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:37:\"woocommerce-gateway-paypal-pro-hosted\";}}i:3;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:35:\"woocommerce-gateway-paypal-advanced\";}}i:4;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:40:\"woocommerce-gateway-paypal-digital-goods\";}}i:5;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:31:\"woocommerce-paypal-here-gateway\";}}i:6;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:44:\"woocommerce-gateway-paypal-adaptive-payments\";}}}}i:3;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:27:\"woocommerce-paypal-payments\";}}}}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:27:\"woocommerce-paypal-payments\";s:7:\"version\";s:5:\"1.2.1\";s:8:\"operator\";s:1:\"<\";}}}}}s:23:\"facebook_pixel_api_2021\";O:8:\"stdClass\":8:{s:4:\"slug\";s:23:\"facebook_pixel_api_2021\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:44:\"Improve the performance of your Facebook ads\";s:7:\"content\";s:152:\"Enable Facebook Pixel and Conversions API through the latest version of Facebook for WooCommerce for improved measurement and ad targeting capabilities.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:30:\"upgrade_now_facebook_pixel_api\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:11:\"Upgrade now\";}}s:3:\"url\";s:67:\"plugin-install.php?tab=plugin-information&plugin=&section=changelog\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:3:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2021-05-17 00:00:00\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:19:\"publish_before_time\";s:14:\"publish_before\";s:19:\"2021-06-14 00:00:00\";}i:2;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:24:\"facebook-for-woocommerce\";s:7:\"version\";s:5:\"2.4.0\";s:8:\"operator\";s:2:\"<=\";}}}s:16:\"facebook_ec_2021\";O:8:\"stdClass\":8:{s:4:\"slug\";s:16:\"facebook_ec_2021\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:59:\"Sync your product catalog with Facebook to help boost sales\";s:7:\"content\";s:170:\"A single click adds all products to your Facebook Business Page shop. Product changes are automatically synced, with the flexibility to control which products are listed.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:22:\"learn_more_facebook_ec\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:42:\"https://woocommerce.com/products/facebook/\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:10:\"unactioned\";}}s:5:\"rules\";a:3:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2021-03-01 00:00:00\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:19:\"publish_before_time\";s:14:\"publish_before\";s:19:\"2021-03-15 00:00:00\";}i:2;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:24:\"facebook-for-woocommerce\";}}}}s:37:\"ecomm-need-help-setting-up-your-store\";O:8:\"stdClass\":8:{s:4:\"slug\";s:37:\"ecomm-need-help-setting-up-your-store\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:32:\"Need help setting up your Store?\";s:7:\"content\";s:350:\"Schedule a free 30-min <a href=\"https://wordpress.com/support/concierge-support/\">quick start session</a> and get help from our specialists. We’re happy to walk through setup steps, show you around the WordPress.com dashboard, troubleshoot any issues you may have, and help you the find the features you need to accomplish your goals for your site.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:16:\"set-up-concierge\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:21:\"Schedule free session\";}}s:3:\"url\";s:34:\"https://wordpress.com/me/concierge\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:3:{i:0;s:35:\"woocommerce-shipping-australia-post\";i:1;s:32:\"woocommerce-shipping-canada-post\";i:2;s:30:\"woocommerce-shipping-royalmail\";}}}}s:20:\"woocommerce-services\";O:8:\"stdClass\":8:{s:4:\"slug\";s:20:\"woocommerce-services\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:26:\"WooCommerce Shipping & Tax\";s:7:\"content\";s:255:\"WooCommerce Shipping & Tax helps get your store “ready to sell” as quickly as possible. You create your products. We take care of tax calculation, payment processing, and shipping label printing! Learn more about the extension that you just installed.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:10:\"learn-more\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:84:\"https://docs.woocommerce.com/document/woocommerce-shipping-and-tax/?utm_source=inbox\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:10:\"unactioned\";}}s:5:\"rules\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:20:\"woocommerce-services\";}}i:1;O:8:\"stdClass\":3:{s:4:\"type\";s:18:\"wcadmin_active_for\";s:9:\"operation\";s:1:\"<\";s:4:\"days\";i:2;}}}s:32:\"ecomm-unique-shopping-experience\";O:8:\"stdClass\":8:{s:4:\"slug\";s:32:\"ecomm-unique-shopping-experience\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:53:\"For a shopping experience as unique as your customers\";s:7:\"content\";s:274:\"Product Add-Ons allow your customers to personalize products while they’re shopping on your online store. No more follow-up email requests—customers get what they want, before they’re done checking out. Learn more about this extension that comes included in your plan.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:43:\"learn-more-ecomm-unique-shopping-experience\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:71:\"https://docs.woocommerce.com/document/product-add-ons/?utm_source=inbox\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:3:{i:0;s:35:\"woocommerce-shipping-australia-post\";i:1;s:32:\"woocommerce-shipping-canada-post\";i:2;s:30:\"woocommerce-shipping-royalmail\";}}i:1;O:8:\"stdClass\":3:{s:4:\"type\";s:18:\"wcadmin_active_for\";s:9:\"operation\";s:1:\"<\";s:4:\"days\";i:2;}}}s:37:\"wc-admin-getting-started-in-ecommerce\";O:8:\"stdClass\":8:{s:4:\"slug\";s:37:\"wc-admin-getting-started-in-ecommerce\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:38:\"Getting Started in eCommerce - webinar\";s:7:\"content\";s:174:\"We want to make eCommerce and this process of getting started as easy as possible for you. Watch this webinar to get tips on how to have our store up and running in a breeze.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:17:\"watch-the-webinar\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:17:\"Watch the webinar\";}}s:3:\"url\";s:28:\"https://youtu.be/V_2XtCOyZ7o\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:2:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:18:\"onboarding_profile\";s:5:\"index\";s:12:\"setup_client\";s:9:\"operation\";s:2:\"!=\";s:5:\"value\";b:1;}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:3:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:18:\"onboarding_profile\";s:5:\"index\";s:13:\"product_count\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:1:\"0\";}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:18:\"onboarding_profile\";s:5:\"index\";s:7:\"revenue\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:4:\"none\";}i:2;O:8:\"stdClass\":4:{s:4:\"type\";s:18:\"onboarding_profile\";s:5:\"index\";s:7:\"revenue\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:10:\"up-to-2500\";}}}}}s:18:\"your-first-product\";O:8:\"stdClass\":8:{s:4:\"slug\";s:18:\"your-first-product\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:18:\"Your first product\";s:7:\"content\";s:461:\"That\'s huge! You\'re well on your way to building a successful online store — now it’s time to think about how you\'ll fulfill your orders.<br/><br/>Read our shipping guide to learn best practices and options for putting together your shipping strategy. And for WooCommerce stores in the United States, you can print discounted shipping labels via USPS with <a href=\"https://href.li/?https://woocommerce.com/shipping\" target=\"_blank\">WooCommerce Shipping</a>.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:10:\"learn-more\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:82:\"https://woocommerce.com/posts/ecommerce-shipping-solutions-guide/?utm_source=inbox\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:4:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:12:\"stored_state\";s:5:\"index\";s:22:\"there_were_no_products\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";b:1;}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:12:\"stored_state\";s:5:\"index\";s:22:\"there_are_now_products\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";b:1;}i:2;O:8:\"stdClass\":3:{s:4:\"type\";s:13:\"product_count\";s:9:\"operation\";s:2:\">=\";s:5:\"value\";i:1;}i:3;O:8:\"stdClass\":5:{s:4:\"type\";s:18:\"onboarding_profile\";s:5:\"index\";s:13:\"product_types\";s:9:\"operation\";s:8:\"contains\";s:5:\"value\";s:8:\"physical\";s:7:\"default\";a:0:{}}}}s:31:\"wc-square-apple-pay-boost-sales\";O:8:\"stdClass\":8:{s:4:\"slug\";s:31:\"wc-square-apple-pay-boost-sales\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:26:\"Boost sales with Apple Pay\";s:7:\"content\";s:191:\"Now that you accept Apple Pay® with Square you can increase conversion rates by letting your customers know that Apple Pay® is available. Here’s a marketing guide to help you get started.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:27:\"boost-sales-marketing-guide\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:19:\"See marketing guide\";}}s:3:\"url\";s:97:\"https://developer.apple.com/apple-pay/marketing/?utm_source=inbox&utm_campaign=square-boost-sales\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:9:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:3:\"4.8\";}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:18:\"woocommerce-square\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:3:\"2.3\";}i:2;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:27:\"wc_square_apple_pay_enabled\";s:5:\"value\";i:1;s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:3;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:38:\"wc-square-apple-pay-grow-your-business\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:4;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:38:\"wc-square-apple-pay-grow-your-business\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}i:5;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:27:\"wcpay-apple-pay-boost-sales\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:6;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:27:\"wcpay-apple-pay-boost-sales\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}i:7;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:34:\"wcpay-apple-pay-grow-your-business\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:8;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:34:\"wcpay-apple-pay-grow-your-business\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}}}s:38:\"wc-square-apple-pay-grow-your-business\";O:8:\"stdClass\":8:{s:4:\"slug\";s:38:\"wc-square-apple-pay-grow-your-business\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:45:\"Grow your business with Square and Apple Pay \";s:7:\"content\";s:178:\"Now more than ever, shoppers want a fast, simple, and secure online checkout experience. Increase conversion rates by letting your customers know that you now accept Apple Pay®.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:34:\"grow-your-business-marketing-guide\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:19:\"See marketing guide\";}}s:3:\"url\";s:104:\"https://developer.apple.com/apple-pay/marketing/?utm_source=inbox&utm_campaign=square-grow-your-business\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:9:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:3:\"4.8\";}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:18:\"woocommerce-square\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:3:\"2.3\";}i:2;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:27:\"wc_square_apple_pay_enabled\";s:5:\"value\";i:2;s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:3;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:31:\"wc-square-apple-pay-boost-sales\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:4;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:31:\"wc-square-apple-pay-boost-sales\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}i:5;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:27:\"wcpay-apple-pay-boost-sales\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:6;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:27:\"wcpay-apple-pay-boost-sales\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}i:7;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:34:\"wcpay-apple-pay-grow-your-business\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:8;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:34:\"wcpay-apple-pay-grow-your-business\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}}}s:32:\"wcpay-apple-pay-is-now-available\";O:8:\"stdClass\":8:{s:4:\"slug\";s:32:\"wcpay-apple-pay-is-now-available\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:53:\"Apple Pay is now available with WooCommerce Payments!\";s:7:\"content\";s:397:\"Increase your conversion rate by offering a fast and secure checkout with <a href=\"https://woocommerce.com/apple-pay/?utm_source=inbox&utm_medium=product&utm_campaign=wcpay_applepay\" target=\"_blank\">Apple Pay</a>®. It’s free to get started with <a href=\"https://woocommerce.com/payments/?utm_source=inbox&utm_medium=product&utm_campaign=wcpay_applepay\" target=\"_blank\">WooCommerce Payments</a>.\";}}s:7:\"actions\";a:2:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:13:\"add-apple-pay\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:13:\"Add Apple Pay\";}}s:3:\"url\";s:69:\"/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}i:1;O:8:\"stdClass\":6:{s:4:\"name\";s:10:\"learn-more\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:121:\"https://docs.woocommerce.com/document/payments/apple-pay/?utm_source=inbox&utm_medium=product&utm_campaign=wcpay_applepay\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:3:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:3:\"4.8\";}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:20:\"woocommerce-payments\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:5:\"2.3.0\";}i:2;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:26:\"wcpay_is_apple_pay_enabled\";s:5:\"value\";b:0;s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}}}s:27:\"wcpay-apple-pay-boost-sales\";O:8:\"stdClass\":8:{s:4:\"slug\";s:27:\"wcpay-apple-pay-boost-sales\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:26:\"Boost sales with Apple Pay\";s:7:\"content\";s:205:\"Now that you accept Apple Pay® with WooCommerce Payments you can increase conversion rates by letting your customers know that Apple Pay® is available. Here’s a marketing guide to help you get started.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:27:\"boost-sales-marketing-guide\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:19:\"See marketing guide\";}}s:3:\"url\";s:96:\"https://developer.apple.com/apple-pay/marketing/?utm_source=inbox&utm_campaign=wcpay-boost-sales\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:4:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:3:\"4.8\";}i:1;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:26:\"wcpay_is_apple_pay_enabled\";s:5:\"value\";i:1;s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:2;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:34:\"wcpay-apple-pay-grow-your-business\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:3;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:34:\"wcpay-apple-pay-grow-your-business\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}}}s:34:\"wcpay-apple-pay-grow-your-business\";O:8:\"stdClass\":8:{s:4:\"slug\";s:34:\"wcpay-apple-pay-grow-your-business\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:58:\"Grow your business with WooCommerce Payments and Apple Pay\";s:7:\"content\";s:178:\"Now more than ever, shoppers want a fast, simple, and secure online checkout experience. Increase conversion rates by letting your customers know that you now accept Apple Pay®.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:34:\"grow-your-business-marketing-guide\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:19:\"See marketing guide\";}}s:3:\"url\";s:103:\"https://developer.apple.com/apple-pay/marketing/?utm_source=inbox&utm_campaign=wcpay-grow-your-business\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:4:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:3:\"4.8\";}i:1;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:26:\"wcpay_is_apple_pay_enabled\";s:5:\"value\";i:2;s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:2;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:27:\"wcpay-apple-pay-boost-sales\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:3;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:27:\"wcpay-apple-pay-boost-sales\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}}}s:37:\"wc-admin-optimizing-the-checkout-flow\";O:8:\"stdClass\":8:{s:4:\"slug\";s:37:\"wc-admin-optimizing-the-checkout-flow\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:28:\"Optimizing the checkout flow\";s:7:\"content\";s:171:\"It\'s crucial to get your store\'s checkout as smooth as possible to avoid losing sales. Let\'s take a look at how you can optimize the checkout experience for your shoppers.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:28:\"optimizing-the-checkout-flow\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:78:\"https://woocommerce.com/posts/optimizing-woocommerce-checkout?utm_source=inbox\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:2:{i:0;O:8:\"stdClass\":3:{s:4:\"type\";s:18:\"wcadmin_active_for\";s:9:\"operation\";s:1:\">\";s:4:\"days\";i:3;}i:1;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:45:\"woocommerce_task_list_tracked_completed_tasks\";s:9:\"operation\";s:8:\"contains\";s:5:\"value\";s:8:\"payments\";s:7:\"default\";a:0:{}}}}s:39:\"wc-admin-first-five-things-to-customize\";O:8:\"stdClass\":8:{s:4:\"slug\";s:39:\"wc-admin-first-five-things-to-customize\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:45:\"The first 5 things to customize in your store\";s:7:\"content\";s:173:\"Deciding what to start with first is tricky. To help you properly prioritize, we\'ve put together this short list of the first few things you should customize in WooCommerce.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:10:\"learn-more\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:82:\"https://woocommerce.com/posts/first-things-customize-woocommerce/?utm_source=inbox\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:10:\"unactioned\";}}s:5:\"rules\";a:2:{i:0;O:8:\"stdClass\":3:{s:4:\"type\";s:18:\"wcadmin_active_for\";s:9:\"operation\";s:1:\">\";s:4:\"days\";i:2;}i:1;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:45:\"woocommerce_task_list_tracked_completed_tasks\";s:5:\"value\";s:9:\"NOT EMPTY\";s:7:\"default\";s:9:\"NOT EMPTY\";s:9:\"operation\";s:2:\"!=\";}}}s:32:\"wc-payments-qualitative-feedback\";O:8:\"stdClass\":8:{s:4:\"slug\";s:32:\"wc-payments-qualitative-feedback\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:55:\"WooCommerce Payments setup - let us know what you think\";s:7:\"content\";s:146:\"Congrats on enabling WooCommerce Payments for your store. Please share your feedback in this 2 minute survey to help us improve the setup process.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:35:\"qualitative-feedback-from-new-users\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:14:\"Share feedback\";}}s:3:\"url\";s:39:\"https://automattic.survey.fm/wc-pay-new\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:1:{i:0;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:45:\"woocommerce_task_list_tracked_completed_tasks\";s:9:\"operation\";s:8:\"contains\";s:5:\"value\";s:20:\"woocommerce-payments\";s:7:\"default\";a:0:{}}}}s:29:\"share-your-feedback-on-paypal\";O:8:\"stdClass\":8:{s:4:\"slug\";s:29:\"share-your-feedback-on-paypal\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:29:\"Share your feedback on PayPal\";s:7:\"content\";s:127:\"Share your feedback in this 2 minute survey about how we can make the process of accepting payments more useful for your store.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:14:\"share-feedback\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:14:\"Share feedback\";}}s:3:\"url\";s:43:\"http://automattic.survey.fm/paypal-feedback\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:10:\"unactioned\";}}s:5:\"rules\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:26:\"woocommerce-gateway-stripe\";}}}}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:43:\"woocommerce-gateway-paypal-express-checkout\";}}}}s:31:\"wcpay_instant_deposits_gtm_2021\";O:8:\"stdClass\":8:{s:4:\"slug\";s:31:\"wcpay_instant_deposits_gtm_2021\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:69:\"Get paid within minutes – Instant Deposits for WooCommerce Payments\";s:7:\"content\";s:384:\"Stay flexible with immediate access to your funds when you need them – including nights, weekends, and holidays. With <a href=\"https://woocommerce.com/products/woocommerce-payments/?utm_source=inbox&utm_medium=product&utm_campaign=wcpay_instant_deposits\">WooCommerce Payments\'</a> new Instant Deposits feature, you’re able to transfer your earnings to a debit card within minutes.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:10:\"learn-more\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:40:\"Learn about Instant Deposits eligibility\";}}s:3:\"url\";s:136:\"https://docs.woocommerce.com/document/payments/instant-deposits/?utm_source=inbox&utm_medium=product&utm_campaign=wcpay_instant_deposits\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:4:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2021-05-18 00:00:00\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:19:\"publish_before_time\";s:14:\"publish_before\";s:19:\"2021-06-01 00:00:00\";}i:2;O:8:\"stdClass\":3:{s:4:\"type\";s:21:\"base_location_country\";s:5:\"value\";s:2:\"US\";s:9:\"operation\";s:1:\"=\";}i:3;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:20:\"woocommerce-payments\";}}}}s:31:\"google_listings_and_ads_install\";O:8:\"stdClass\":8:{s:4:\"slug\";s:31:\"google_listings_and_ads_install\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:35:\"Drive traffic and sales with Google\";s:7:\"content\";s:123:\"Reach online shoppers to drive traffic and sales for your store by showcasing products across Google, for free or with ads.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:11:\"get-started\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:11:\"Get started\";}}s:3:\"url\";s:56:\"https://woocommerce.com/products/google-listings-and-ads\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:3:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2021-06-09 00:00:00\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:23:\"google_listings_and_ads\";}}}}i:2;O:8:\"stdClass\":3:{s:4:\"type\";s:11:\"order_count\";s:9:\"operation\";s:1:\">\";s:5:\"value\";i:10;}}}s:39:\"wc-subscriptions-security-update-3-0-15\";O:8:\"stdClass\":8:{s:4:\"slug\";s:39:\"wc-subscriptions-security-update-3-0-15\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:42:\"WooCommerce Subscriptions security update!\";s:7:\"content\";s:736:\"We recently released an important security update to WooCommerce Subscriptions. To ensure your site\'s data is protected, please upgrade <strong>WooCommerce Subscriptions to version 3.0.15</strong> or later.<br/><br/>Click the button below to view and update to the latest Subscriptions version, or log in to <a href=\"https://woocommerce.com/my-dashboard\">WooCommerce.com Dashboard</a> and navigate to your <strong>Downloads</strong> page.<br/><br/>We recommend always using the latest version of WooCommerce Subscriptions, and other software running on your site, to ensure maximum security.<br/><br/>If you have any questions we are here to help — just <a href=\"https://woocommerce.com/my-account/create-a-ticket/\">open a ticket</a>.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:30:\"update-wc-subscriptions-3-0-15\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:19:\"View latest version\";}}s:3:\"url\";s:30:\"&page=wc-addons&section=helper\";s:18:\"url_is_admin_query\";b:1;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:1:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:25:\"woocommerce-subscriptions\";s:8:\"operator\";s:1:\"<\";s:7:\"version\";s:6:\"3.0.15\";}}}s:29:\"woocommerce-core-update-5-4-0\";O:8:\"stdClass\":8:{s:4:\"slug\";s:29:\"woocommerce-core-update-5-4-0\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:31:\"Update to WooCommerce 5.4.1 now\";s:7:\"content\";s:140:\"WooCommerce 5.4.1 addresses a checkout issue discovered in WooCommerce 5.4. We recommend upgrading to WooCommerce 5.4.1 as soon as possible.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:20:\"update-wc-core-5-4-0\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:25:\"How to update WooCommerce\";}}s:3:\"url\";s:64:\"https://docs.woocommerce.com/document/how-to-update-woocommerce/\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:1:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.4.0\";}}}s:19:\"wcpay-promo-2020-11\";O:8:\"stdClass\":7:{s:4:\"slug\";s:19:\"wcpay-promo-2020-11\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:19:\"wcpay-promo-2020-11\";s:7:\"content\";s:19:\"wcpay-promo-2020-11\";}}s:5:\"rules\";a:0:{}}s:19:\"wcpay-promo-2020-12\";O:8:\"stdClass\":7:{s:4:\"slug\";s:19:\"wcpay-promo-2020-12\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:19:\"wcpay-promo-2020-12\";s:7:\"content\";s:19:\"wcpay-promo-2020-12\";}}s:5:\"rules\";a:0:{}}s:30:\"wcpay-promo-2021-6-incentive-1\";O:8:\"stdClass\":8:{s:4:\"slug\";s:30:\"wcpay-promo-2021-6-incentive-1\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:74:\"Special offer: Save 50% on transaction fees for up to $125,000 in payments\";s:7:\"content\";s:715:\"Save big when you add <a href=\"https://woocommerce.com/payments/?utm_medium=notification&utm_source=product&utm_campaign=wcpay_exp222\">WooCommerce Payments</a> to your store today.\n                Get a discounted rate of 1.5% + $0.15 on all transactions – that’s 50% off the standard fee on up to $125,000 in processed payments (or six months, whichever comes first). Act now – this offer is available for a limited time only.\n                <br/><br/>By clicking \"Get WooCommerce Payments,\" you agree to the promotional <a href=\"https://woocommerce.com/terms-conditions/woocommerce-payments-half-off-six-promotion/?utm_medium=notification&utm_source=product&utm_campaign=wcpay_exp222\">Terms of Service</a>.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:25:\"get-woo-commerce-payments\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:24:\"Get WooCommerce Payments\";}}s:3:\"url\";s:57:\"admin.php?page=wc-admin&action=setup-woocommerce-payments\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:12:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:6:{i:0;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:36:\"woocommerce_inbox_variant_assignment\";s:5:\"value\";s:1:\"1\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:1;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:36:\"woocommerce_inbox_variant_assignment\";s:5:\"value\";s:1:\"3\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:2;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:36:\"woocommerce_inbox_variant_assignment\";s:5:\"value\";s:1:\"5\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:3;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:36:\"woocommerce_inbox_variant_assignment\";s:5:\"value\";s:1:\"7\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:4;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:36:\"woocommerce_inbox_variant_assignment\";s:5:\"value\";s:1:\"9\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:5;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:36:\"woocommerce_inbox_variant_assignment\";s:5:\"value\";s:2:\"11\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}}}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:4:{i:0;s:17:\"crowdsignal-forms\";i:1;s:11:\"layout-grid\";i:2;s:17:\"full-site-editing\";i:3;s:13:\"page-optimize\";}}}}i:2;O:8:\"stdClass\":3:{s:4:\"type\";s:21:\"base_location_country\";s:5:\"value\";s:2:\"US\";s:9:\"operation\";s:1:\"=\";}i:3;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:26:\"woocommerce_allow_tracking\";s:5:\"value\";s:3:\"yes\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:4;O:8:\"stdClass\":3:{s:4:\"type\";s:18:\"wcadmin_active_for\";s:9:\"operation\";s:2:\">=\";s:4:\"days\";i:31;}i:5;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:20:\"woocommerce-payments\";}}}}i:6;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:3:\"4.0\";}i:7;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:10:\"db_version\";s:5:\"value\";s:5:\"45805\";s:7:\"default\";i:0;s:9:\"operation\";s:2:\">=\";}i:8;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:19:\"wcpay-promo-2020-11\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:9;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:19:\"wcpay-promo-2020-11\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}i:10;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:19:\"wcpay-promo-2020-12\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:11;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:19:\"wcpay-promo-2020-12\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}}}s:30:\"wcpay-promo-2021-6-incentive-2\";O:8:\"stdClass\":8:{s:4:\"slug\";s:30:\"wcpay-promo-2021-6-incentive-2\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:58:\"Special offer: No transaction fees* for up to three months\";s:7:\"content\";s:684:\"Save big when you add <a href=\"https://woocommerce.com/payments/?utm_medium=notification&utm_source=product&utm_campaign=wcpay_exp233\">WooCommerce Payments</a> to your store today. Pay zero transaction fees* on up to $25,000 in processed payments (or three months, whichever comes first). Act now – this offer is available for a limited time only. *Currency conversion fees excluded.\n                <br/><br/>By clicking \"Get WooCommerce Payments,\" you agree to the promotional <a href=\"https://woocommerce.com/terms-conditions/woocommerce-payments-no-transaction-fees-for-three-promotion/?utm_medium=notification&utm_source=product&utm_campaign=wcpay_exp233\">Terms of Service</a>.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:24:\"get-woocommerce-payments\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:24:\"Get WooCommerce Payments\";}}s:3:\"url\";s:57:\"admin.php?page=wc-admin&action=setup-woocommerce-payments\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:12:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:6:{i:0;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:36:\"woocommerce_inbox_variant_assignment\";s:5:\"value\";s:1:\"2\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:1;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:36:\"woocommerce_inbox_variant_assignment\";s:5:\"value\";s:1:\"4\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:2;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:36:\"woocommerce_inbox_variant_assignment\";s:5:\"value\";s:1:\"6\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:3;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:36:\"woocommerce_inbox_variant_assignment\";s:5:\"value\";s:1:\"8\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:4;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:36:\"woocommerce_inbox_variant_assignment\";s:5:\"value\";s:2:\"10\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:5;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:36:\"woocommerce_inbox_variant_assignment\";s:5:\"value\";s:2:\"12\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}}}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:4:{i:0;s:17:\"crowdsignal-forms\";i:1;s:11:\"layout-grid\";i:2;s:17:\"full-site-editing\";i:3;s:13:\"page-optimize\";}}}}i:2;O:8:\"stdClass\":3:{s:4:\"type\";s:21:\"base_location_country\";s:5:\"value\";s:2:\"US\";s:9:\"operation\";s:1:\"=\";}i:3;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:26:\"woocommerce_allow_tracking\";s:5:\"value\";s:3:\"yes\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:4;O:8:\"stdClass\":3:{s:4:\"type\";s:18:\"wcadmin_active_for\";s:9:\"operation\";s:2:\">=\";s:4:\"days\";i:31;}i:5;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:20:\"woocommerce-payments\";}}}}i:6;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:3:\"4.0\";}i:7;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:10:\"db_version\";s:5:\"value\";s:5:\"45805\";s:7:\"default\";i:0;s:9:\"operation\";s:2:\">=\";}i:8;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:19:\"wcpay-promo-2020-11\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:9;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:19:\"wcpay-promo-2020-11\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}i:10;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:19:\"wcpay-promo-2020-12\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:11;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:19:\"wcpay-promo-2020-12\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}}}s:34:\"ppxo-pps-upgrade-paypal-payments-1\";O:8:\"stdClass\":8:{s:4:\"slug\";s:34:\"ppxo-pps-upgrade-paypal-payments-1\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:47:\"Get the latest PayPal extension for WooCommerce\";s:7:\"content\";s:440:\"Heads up! There\'s a new PayPal on the block!<br/><br/>Now is a great time to upgrade to our latest <a href=\"https://woocommerce.com/products/woocommerce-paypal-payments/\" target=\"_blank\">PayPal extension</a> to continue to receive support and updates with PayPal.<br/><br/>Get access to a full suite of PayPal payment methods, extensive currency and country coverage, and pay later options with the all-new PayPal extension for WooCommerce.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:34:\"ppxo-pps-install-paypal-payments-1\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:18:\"View upgrade guide\";}}s:3:\"url\";s:96:\"https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:3:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:27:\"woocommerce-paypal-payments\";}}}}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:43:\"woocommerce-gateway-paypal-express-checkout\";}}i:1;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:27:\"woocommerce_paypal_settings\";s:9:\"operation\";s:2:\"!=\";s:5:\"value\";b:0;s:7:\"default\";b:0;}}}i:2;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:36:\"woocommerce_inbox_variant_assignment\";s:5:\"value\";i:7;s:7:\"default\";i:1;s:9:\"operation\";s:1:\"<\";}}}s:34:\"ppxo-pps-upgrade-paypal-payments-2\";O:8:\"stdClass\":8:{s:4:\"slug\";s:34:\"ppxo-pps-upgrade-paypal-payments-2\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:31:\"Upgrade your PayPal experience!\";s:7:\"content\";s:513:\"We\'ve developed a whole new <a href=\"https://woocommerce.com/products/woocommerce-paypal-payments/\" target=\"_blank\">PayPal extension for WooCommerce</a> that combines the best features of our many PayPal extensions into just one extension.<br/><br/>Get access to a full suite of PayPal payment methods, extensive currency and country coverage, offer subscription and recurring payments, and the new PayPal pay later options.<br/><br/>Start using our latest PayPal today to continue to receive support and updates.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:34:\"ppxo-pps-install-paypal-payments-2\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:18:\"View upgrade guide\";}}s:3:\"url\";s:96:\"https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:3:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:27:\"woocommerce-paypal-payments\";}}}}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:43:\"woocommerce-gateway-paypal-express-checkout\";}}i:1;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:27:\"woocommerce_paypal_settings\";s:9:\"operation\";s:2:\"!=\";s:5:\"value\";b:0;s:7:\"default\";b:0;}}}i:2;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:36:\"woocommerce_inbox_variant_assignment\";s:5:\"value\";i:6;s:7:\"default\";i:1;s:9:\"operation\";s:1:\">\";}}}}', 'yes');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(396, '_transient_woocommerce_reports-transient-version', '1624440034', 'yes'),
(408, 'woocommerce_onboarding_profile', 'a:8:{s:12:\"setup_client\";b:0;s:8:\"industry\";a:1:{i:0;a:1:{s:4:\"slug\";s:27:\"fashion-apparel-accessories\";}}s:13:\"product_types\";a:1:{i:0;s:8:\"physical\";}s:13:\"product_count\";s:4:\"1-10\";s:14:\"selling_venues\";s:2:\"no\";s:19:\"business_extensions\";a:0:{}s:5:\"theme\";s:13:\"twentyfifteen\";s:9:\"completed\";b:1;}', 'yes'),
(421, 'woocommerce_task_list_tracked_completed_tasks', 'a:3:{i:0;s:13:\"store_details\";i:1;s:8:\"products\";i:2;s:8:\"payments\";}', 'yes'),
(422, 'woocommerce_task_list_welcome_modal_dismissed', 'yes', 'yes'),
(435, '_transient_product_query-transient-version', '1624399310', 'yes'),
(436, '_transient_product-transient-version', '1622737736', 'yes'),
(441, '_transient_shipping-transient-version', '1622546707', 'yes'),
(442, '_transient_timeout_wc_shipping_method_count_legacy', '1625138707', 'no'),
(443, '_transient_wc_shipping_method_count_legacy', 'a:2:{s:7:\"version\";s:10:\"1622546707\";s:5:\"value\";i:0;}', 'no'),
(464, 'nav_menu_options', 'a:1:{s:8:\"auto_add\";a:0:{}}', 'yes'),
(465, 'woocommerce_maybe_regenerate_images_hash', '991b1ca641921cf0f5baf7a2fe85861b', 'yes'),
(525, 'theme_mods_manufacturer', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:7:\"primary\";i:18;}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1622714737;s:4:\"data\";a:1:{s:19:\"wp_inactive_widgets\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}}', 'yes'),
(538, 'new_admin_email', 'gartonot62@gmail.com', 'yes'),
(573, 'recovery_mode_email_last_sent', '1622717088', 'yes'),
(615, 'robokassa_payment_wc_robokassa_enabled', 'no', 'yes'),
(616, 'robokassa_payment_test_onoff', 'false', 'yes'),
(617, 'robokassa_payment_type_commission', 'true', 'yes'),
(618, 'robokassa_payment_tax', 'none', 'yes'),
(619, 'robokassa_payment_sno', 'fckoff', 'yes'),
(620, 'robokassa_payment_who_commission', 'shop', 'yes'),
(621, 'robokassa_payment_paytype', 'false', 'yes'),
(622, 'robokassa_payment_SuccessURL', 'wc_success', 'yes'),
(623, 'robokassa_payment_FailURL', 'wc_checkout', 'yes'),
(650, 'woocommerce_bacs_settings', 'a:11:{s:7:\"enabled\";s:2:\"no\";s:5:\"title\";s:48:\"Прямой банковский перевод\";s:11:\"description\";s:324:\"Оплату нужно направлять напрямую на наш банковский счет. Используйте идентификатор заказа в качестве кода платежа. Заказ будет отправлен после поступления средств на наш счет.\";s:12:\"instructions\";s:0:\"\";s:15:\"account_details\";s:0:\"\";s:12:\"account_name\";s:0:\"\";s:14:\"account_number\";s:0:\"\";s:9:\"sort_code\";s:0:\"\";s:9:\"bank_name\";s:0:\"\";s:4:\"iban\";s:0:\"\";s:3:\"bic\";s:0:\"\";}', 'yes'),
(651, 'woocommerce_cod_settings', 'a:6:{s:7:\"enabled\";s:3:\"yes\";s:5:\"title\";s:36:\"Оплата при доставке\";s:11:\"description\";s:69:\"Оплата наличными при доставке заказа.\";s:12:\"instructions\";s:69:\"Оплата наличными при доставке заказа.\";s:18:\"enable_for_methods\";a:0:{}s:18:\"enable_for_virtual\";s:3:\"yes\";}', 'yes'),
(652, 'woocommerce_gateway_order', 'a:4:{s:4:\"bacs\";i:0;s:6:\"cheque\";i:1;s:3:\"cod\";i:2;s:6:\"paypal\";i:3;}', 'yes'),
(654, '_transient_orders-transient-version', '1623800910', 'yes'),
(658, 'woocommerce_admin_last_orders_milestone', '1', 'yes'),
(732, 'woocommerce_sales_record_date', '2021-06-01', 'yes'),
(733, 'woocommerce_sales_record_amount', '23270', 'yes'),
(790, '_transient_timeout_wc_product_loop_0c7163e51e281d9b3fbb8dabf2cd7fda', '1625226850', 'no'),
(791, '_transient_wc_product_loop_0c7163e51e281d9b3fbb8dabf2cd7fda', 'a:2:{s:7:\"version\";s:10:\"1622634560\";s:5:\"value\";O:8:\"stdClass\":5:{s:3:\"ids\";a:1:{i:0;i:10;}s:5:\"total\";i:1;s:11:\"total_pages\";i:1;s:8:\"per_page\";i:-1;s:12:\"current_page\";i:1;}}', 'no'),
(811, '_transient_timeout_wc_shipping_method_count', '1625227318', 'no'),
(812, '_transient_wc_shipping_method_count', 'a:2:{s:7:\"version\";s:10:\"1622546707\";s:5:\"value\";i:0;}', 'no'),
(1333, '_transient_timeout_wc_customer_bought_product_e51c32cd8464872c163d0fcbda5955da', '1625310621', 'no'),
(1334, '_transient_wc_customer_bought_product_e51c32cd8464872c163d0fcbda5955da', 'a:2:{s:7:\"version\";s:10:\"1622574501\";s:5:\"value\";a:2:{i:0;i:10;i:1;i:10;}}', 'no'),
(1500, 'product_cat_children', 'a:0:{}', 'yes'),
(1690, '_transient_timeout_wc_term_counts', '1625337142', 'no'),
(1691, '_transient_wc_term_counts', 'a:6:{i:22;s:2:\"10\";i:20;s:2:\"18\";i:16;s:2:\"24\";i:23;s:1:\"2\";i:21;s:2:\"18\";i:17;s:1:\"1\";}', 'no'),
(1935, 'action_scheduler_migration_status', 'complete', 'yes'),
(1951, 'thwcfd_since', '1622750327', 'no'),
(1953, 'wc_fields_billing', 'a:10:{s:18:\"billing_first_name\";a:9:{s:5:\"label\";s:6:\"Имя\";s:8:\"required\";b:1;s:5:\"class\";a:1:{i:0;s:14:\"form-row-first\";}s:12:\"autocomplete\";s:10:\"given-name\";s:8:\"priority\";i:10;s:6:\"custom\";i:0;s:7:\"enabled\";s:1:\"1\";s:13:\"show_in_email\";i:1;s:13:\"show_in_order\";i:1;}s:17:\"billing_last_name\";a:9:{s:5:\"label\";s:14:\"Фамилия\";s:8:\"required\";b:1;s:5:\"class\";a:1:{i:0;s:13:\"form-row-last\";}s:12:\"autocomplete\";s:11:\"family-name\";s:8:\"priority\";i:20;s:6:\"custom\";i:0;s:7:\"enabled\";s:1:\"1\";s:13:\"show_in_email\";i:1;s:13:\"show_in_order\";i:1;}s:13:\"billing_phone\";a:11:{s:5:\"label\";s:14:\"Телефон\";s:8:\"required\";b:1;s:4:\"type\";s:3:\"tel\";s:5:\"class\";a:1:{i:0;s:13:\"form-row-wide\";}s:8:\"validate\";a:1:{i:0;s:5:\"phone\";}s:12:\"autocomplete\";s:3:\"tel\";s:8:\"priority\";i:30;s:6:\"custom\";i:0;s:7:\"enabled\";s:1:\"1\";s:13:\"show_in_email\";i:1;s:13:\"show_in_order\";i:1;}s:13:\"billing_email\";a:11:{s:5:\"label\";s:5:\"Email\";s:8:\"required\";b:1;s:4:\"type\";s:5:\"email\";s:5:\"class\";a:1:{i:0;s:13:\"form-row-wide\";}s:8:\"validate\";a:1:{i:0;s:5:\"email\";}s:12:\"autocomplete\";s:14:\"email username\";s:8:\"priority\";i:40;s:6:\"custom\";i:0;s:7:\"enabled\";s:1:\"1\";s:13:\"show_in_email\";i:1;s:13:\"show_in_order\";i:1;}s:15:\"billing_country\";a:10:{s:4:\"type\";s:7:\"country\";s:5:\"label\";s:25:\"Страна/регион\";s:8:\"required\";b:1;s:5:\"class\";a:3:{i:0;s:13:\"form-row-wide\";i:1;s:13:\"address-field\";i:2;s:23:\"update_totals_on_change\";}s:12:\"autocomplete\";s:7:\"country\";s:8:\"priority\";i:50;s:6:\"custom\";i:0;s:7:\"enabled\";s:1:\"1\";s:13:\"show_in_email\";i:1;s:13:\"show_in_order\";i:1;}s:13:\"billing_state\";a:13:{s:4:\"type\";s:5:\"state\";s:5:\"label\";s:27:\"Область / район\";s:8:\"required\";b:1;s:5:\"class\";a:2:{i:0;s:13:\"form-row-wide\";i:1;s:13:\"address-field\";}s:8:\"validate\";a:1:{i:0;s:5:\"state\";}s:12:\"autocomplete\";s:14:\"address-level1\";s:8:\"priority\";i:60;s:13:\"country_field\";s:15:\"billing_country\";s:7:\"country\";s:2:\"RU\";s:6:\"custom\";i:0;s:7:\"enabled\";s:1:\"1\";s:13:\"show_in_email\";i:1;s:13:\"show_in_order\";i:1;}s:12:\"billing_city\";a:9:{s:5:\"label\";s:31:\"Населённый пункт\";s:8:\"required\";b:1;s:5:\"class\";a:2:{i:0;s:13:\"form-row-wide\";i:1;s:13:\"address-field\";}s:12:\"autocomplete\";s:14:\"address-level2\";s:8:\"priority\";i:70;s:6:\"custom\";i:0;s:7:\"enabled\";s:1:\"1\";s:13:\"show_in_email\";i:1;s:13:\"show_in_order\";i:1;}s:17:\"billing_address_1\";a:10:{s:5:\"label\";s:10:\"Адрес\";s:11:\"placeholder\";s:50:\"Номер дома и название улицы\";s:8:\"required\";b:1;s:5:\"class\";a:2:{i:0;s:13:\"form-row-wide\";i:1;s:13:\"address-field\";}s:12:\"autocomplete\";s:13:\"address-line1\";s:8:\"priority\";i:80;s:6:\"custom\";i:0;s:7:\"enabled\";s:1:\"1\";s:13:\"show_in_email\";i:1;s:13:\"show_in_order\";i:1;}s:17:\"billing_address_2\";a:11:{s:5:\"label\";s:46:\"Крыло, подъезд, этаж и т.д.\";s:11:\"label_class\";a:1:{i:0;s:18:\"screen-reader-text\";}s:11:\"placeholder\";s:75:\"Крыло, подъезд, этаж и т.д. (необязательно)\";s:5:\"class\";a:2:{i:0;s:13:\"form-row-wide\";i:1;s:13:\"address-field\";}s:12:\"autocomplete\";s:13:\"address-line2\";s:8:\"priority\";i:90;s:8:\"required\";b:0;s:6:\"custom\";i:0;s:7:\"enabled\";s:1:\"1\";s:13:\"show_in_email\";i:1;s:13:\"show_in_order\";i:1;}s:16:\"billing_postcode\";a:10:{s:5:\"label\";s:29:\"Почтовый индекс\";s:8:\"required\";b:1;s:5:\"class\";a:2:{i:0;s:13:\"form-row-wide\";i:1;s:13:\"address-field\";}s:8:\"validate\";a:1:{i:0;s:8:\"postcode\";}s:12:\"autocomplete\";s:11:\"postal-code\";s:8:\"priority\";i:100;s:6:\"custom\";i:0;s:7:\"enabled\";s:1:\"1\";s:13:\"show_in_email\";i:1;s:13:\"show_in_order\";i:1;}}', 'yes'),
(2945, '_transient_wc_count_comments', 'O:8:\"stdClass\":7:{s:14:\"total_comments\";i:0;s:3:\"all\";i:0;s:5:\"trash\";s:1:\"2\";s:9:\"moderated\";i:0;s:8:\"approved\";i:0;s:4:\"spam\";i:0;s:12:\"post-trashed\";i:0;}', 'yes'),
(3033, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/ru_RU/wordpress-5.7.2.zip\";s:6:\"locale\";s:5:\"ru_RU\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/ru_RU/wordpress-5.7.2.zip\";s:10:\"no_content\";s:0:\"\";s:11:\"new_bundled\";s:0:\"\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:5:\"5.7.2\";s:7:\"version\";s:5:\"5.7.2\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.6\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1625081971;s:15:\"version_checked\";s:5:\"5.7.2\";s:12:\"translations\";a:0:{}}', 'no'),
(6746, '_transient_timeout_wc_onboarding_product_data', '1625054281', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(6747, '_transient_wc_onboarding_product_data', 'a:6:{s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:18:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Tue, 29 Jun 2021 11:58:01 GMT\";s:12:\"content-type\";s:31:\"application/json; charset=UTF-8\";s:14:\"content-length\";s:5:\"11617\";s:12:\"x-robots-tag\";s:7:\"noindex\";s:4:\"link\";s:60:\"<https://woocommerce.com/wp-json/>; rel=\"https://api.w.org/\"\";s:22:\"x-content-type-options\";s:7:\"nosniff\";s:29:\"access-control-expose-headers\";s:33:\"X-WP-Total, X-WP-TotalPages, Link\";s:28:\"access-control-allow-headers\";s:73:\"Authorization, X-WP-Nonce, Content-Disposition, Content-MD5, Content-Type\";s:13:\"x-wccom-cache\";s:3:\"HIT\";s:13:\"cache-control\";s:10:\"max-age=60\";s:5:\"allow\";s:3:\"GET\";s:16:\"content-encoding\";s:4:\"gzip\";s:4:\"x-rq\";s:16:\"hhn1 91 142 3184\";s:3:\"age\";s:2:\"30\";s:7:\"x-cache\";s:3:\"hit\";s:4:\"vary\";s:23:\"Accept-Encoding, Origin\";s:13:\"accept-ranges\";s:5:\"bytes\";}}s:4:\"body\";s:48319:\"{\"products\":[{\"title\":\"WooCommerce Google Analytics\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/GA-Dark.png\",\"excerpt\":\"Understand your customers and increase revenue with world\\u2019s leading analytics platform - integrated with WooCommerce for free.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-google-analytics\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"2d21f7de14dfb8e9885a4622be701ddf\",\"slug\":\"woocommerce-google-analytics-integration\",\"id\":1442927},{\"title\":\"WooCommerce Tax\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Tax-Dark.png\",\"excerpt\":\"Automatically calculate how much sales tax should be collected for WooCommerce orders - by city, country, or state - at checkout.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/tax\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"f31b3b9273cce188cc2b27f7849d02dd\",\"slug\":\"woocommerce-services\",\"id\":3220291},{\"title\":\"Stripe\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Stripe-Dark-1.png\",\"excerpt\":\"Accept all major debit and credit cards as well as local payment methods with Stripe.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/stripe\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"50bb7a985c691bb943a9da4d2c8b5efd\",\"slug\":\"woocommerce-gateway-stripe\",\"id\":18627},{\"title\":\"Jetpack\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Jetpack-Dark.png\",\"excerpt\":\"Power up and protect your store with Jetpack\\r\\n\\r\\nFor free security, insights and monitoring, connect to Jetpack. It\'s everything you need for a strong, secure start.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/jetpack\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"d5bfef9700b62b2b132c74c74c3193eb\",\"slug\":\"jetpack\",\"id\":2725249},{\"title\":\"Facebook for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Facebook-Dark.png\",\"excerpt\":\"Get the Official Facebook for WooCommerce plugin for three powerful ways to help grow your business.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/facebook\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"0ea4fe4c2d7ca6338f8a322fb3e4e187\",\"slug\":\"facebook-for-woocommerce\",\"id\":2127297},{\"title\":\"Amazon Pay\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Amazon-Pay-Dark.png\",\"excerpt\":\"Amazon Pay is embedded in your WooCommerce store. Transactions take place via\\u00a0Amazon widgets, so the buyer never leaves your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/pay-with-amazon\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"9865e043bbbe4f8c9735af31cb509b53\",\"slug\":\"woocommerce-gateway-amazon-payments-advanced\",\"id\":238816},{\"title\":\"Square for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Square-Dark.png\",\"excerpt\":\"Accepting payments is easy with Square. Clear rates, fast deposits (1-2 business days). Sell online and in person, and sync all payments, items and inventory.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/square\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"e907be8b86d7df0c8f8e0d0020b52638\",\"slug\":\"woocommerce-square\",\"id\":1770503},{\"title\":\"WooCommerce Shipping\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Ship-Dark-1.png\",\"excerpt\":\"Print USPS and DHL labels right from your WooCommerce dashboard and instantly save up to 90%. WooCommerce Shipping is free to use and saves you time and money.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipping\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"f31b3b9273cce188cc2b27f7849d02dd\",\"slug\":\"woocommerce-services\",\"id\":2165910},{\"title\":\"WooCommerce Payments\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Pay-Dark.png\",\"excerpt\":\"Securely accept payments, track cash flow, and manage recurring revenue from your dashboard \\u2014 all without setup costs or monthly fees.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-payments\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"8c6319ca-8f41-4e69-be63-6b15ee37773b\",\"slug\":\"woocommerce-payments\",\"id\":5278104},{\"title\":\"Mailchimp for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/09\\/logo-mailchimp-dark-v2.png\",\"excerpt\":\"Increase traffic, drive repeat purchases, and personalize your marketing when you connect to Mailchimp.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/mailchimp-for-woocommerce\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"b4481616ebece8b1ff68fc59b90c1a91\",\"slug\":\"mailchimp-for-woocommerce\",\"id\":2545166},{\"title\":\"WooCommerce Subscriptions\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Subscriptions-Dark.png\",\"excerpt\":\"Let customers subscribe to your products or services and pay on a weekly, monthly or annual basis.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-subscriptions\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;199.00\",\"hash\":\"6115e6d7e297b623a169fdcf5728b224\",\"slug\":\"woocommerce-subscriptions\",\"id\":27147},{\"title\":\"PayPal Checkout\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Paypal-Dark.png\",\"excerpt\":\"PayPal Checkout now with Smart Payment Buttons\\u2122, dynamically displays, PayPal, Venmo, PayPal Credit, or other local payment options in a single stack giving customers the choice to pay with their preferred option.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gateway-paypal-checkout\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"69e6cba62ac4021df9e117cc3f716d07\",\"slug\":\"woocommerce-gateway-paypal-express-checkout\",\"id\":1597922},{\"title\":\"ShipStation Integration\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Shipstation-Dark.png\",\"excerpt\":\"Fulfill all your Woo orders (and wherever else you sell) quickly and easily using ShipStation. Try it free for 30 days today!\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipstation-integration\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"9de8640767ba64237808ed7f245a49bb\",\"slug\":\"woocommerce-shipstation-integration\",\"id\":18734},{\"title\":\"Product Add-Ons\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Product-Add-Ons-Dark.png\",\"excerpt\":\"Offer add-ons like gift wrapping, special messages or other special options for your products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"147d0077e591e16db9d0d67daeb8c484\",\"slug\":\"woocommerce-product-addons\",\"id\":18618},{\"title\":\"PayFast Payment Gateway\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Payfast-Dark-1.png\",\"excerpt\":\"Take payments on your WooCommerce store via PayFast (redirect method).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/payfast-payment-gateway\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"557bf07293ad916f20c207c6c9cd15ff\",\"slug\":\"woocommerce-payfast-gateway\",\"id\":18596},{\"title\":\"Google Ads &amp; Marketing by Kliken\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2019\\/02\\/GA-for-Woo-Logo-374x192px-qu3duk.png\",\"excerpt\":\"Get in front of shoppers and drive traffic to your store so you can grow your business with Smart Shopping Campaigns and free listings.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/google-ads-and-marketing\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"bf66e173-a220-4da7-9512-b5728c20fc16\",\"slug\":\"kliken-marketing-for-google\",\"id\":3866145},{\"title\":\"USPS Shipping Method\",\"image\":\"\",\"excerpt\":\"Get shipping rates from the USPS API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/usps-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"83d1524e8f5f1913e58889f83d442c32\",\"slug\":\"woocommerce-shipping-usps\",\"id\":18657},{\"title\":\"UPS Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/UPS-Shipping-Method-Dark.png\",\"excerpt\":\"Get shipping rates from the UPS API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/ups-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"8dae58502913bac0fbcdcaba515ea998\",\"slug\":\"woocommerce-shipping-ups\",\"id\":18665},{\"title\":\"Shipment Tracking\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Ship-Tracking-Dark-1.png\",\"excerpt\":\"Add shipment tracking information to your orders.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipment-tracking\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"1968e199038a8a001c9f9966fd06bf88\",\"slug\":\"woocommerce-shipment-tracking\",\"id\":18693},{\"title\":\"Table Rate Shipping\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Product-Table-Rate-Shipping-Dark.png\",\"excerpt\":\"Advanced, flexible shipping. Define multiple shipping rates based on location, price, weight, shipping class or item count.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/table-rate-shipping\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"3034ed8aff427b0f635fe4c86bbf008a\",\"slug\":\"woocommerce-table-rate-shipping\",\"id\":18718},{\"title\":\"Checkout Field Editor\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Checkout-Field-Editor-Dark.png\",\"excerpt\":\"Optimize your checkout process by adding, removing or editing fields to suit your needs.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-checkout-field-editor\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"2b8029f0d7cdd1118f4d843eb3ab43ff\",\"slug\":\"woocommerce-checkout-field-editor\",\"id\":184594},{\"title\":\"Braintree for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2016\\/02\\/braintree-black-copy.png\",\"excerpt\":\"Accept PayPal, credit cards and debit cards with a single payment gateway solution \\u2014 PayPal Powered by Braintree.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gateway-paypal-powered-by-braintree\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"27f010c8e34ca65b205ddec88ad14536\",\"slug\":\"woocommerce-gateway-paypal-powered-by-braintree\",\"id\":1489837},{\"title\":\"WooCommerce Bookings\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Bookings-Dark.png\",\"excerpt\":\"Allow customers to book appointments, make reservations or rent equipment without leaving your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-bookings\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/themes.woocommerce.com\\/hotel\\/\",\"price\":\"&#36;249.00\",\"hash\":\"911c438934af094c2b38d5560b9f50f3\",\"slug\":\"WooCommerce Bookings\",\"id\":390890},{\"title\":\"WooCommerce Memberships\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2015\\/06\\/Thumbnail-Memberships-updated.png\",\"excerpt\":\"Give members access to restricted content or products, for a fee or for free.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-memberships\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;199.00\",\"hash\":\"9288e7609ad0b487b81ef6232efa5cfc\",\"slug\":\"woocommerce-memberships\",\"id\":958589},{\"title\":\"Product Bundles\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/07\\/Logo-PB.png?v=1\",\"excerpt\":\"Offer personalized product bundles, bulk discount packages, and assembled\\u00a0products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-bundles\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"aa2518b5-ab19-4b75-bde9-60ca51e20f28\",\"slug\":\"woocommerce-product-bundles\",\"id\":18716},{\"title\":\"Multichannel for WooCommerce: Google, Amazon, eBay &amp; Walmart Integration\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2018\\/10\\/Woo-Extension-Store-Logo-v2.png\",\"excerpt\":\"Get the official Google, Amazon, eBay and Walmart extension and create, sync and manage multichannel listings directly from WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/amazon-ebay-integration\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"e4000666-9275-4c71-8619-be61fb41c9f9\",\"slug\":\"woocommerce-amazon-ebay-integration\",\"id\":3545890},{\"title\":\"Min\\/Max Quantities\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Min-Max-Qua-Dark.png\",\"excerpt\":\"Specify minimum and maximum allowed product quantities for orders to be completed.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/minmax-quantities\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"2b5188d90baecfb781a5aa2d6abb900a\",\"slug\":\"woocommerce-min-max-quantities\",\"id\":18616},{\"title\":\"FedEx Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2013\\/01\\/FedEx_Logo_Wallpaper.jpeg\",\"excerpt\":\"Get shipping rates from the FedEx API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/fedex-shipping-module\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"1a48b598b47a81559baadef15e320f64\",\"slug\":\"woocommerce-shipping-fedex\",\"id\":18620},{\"title\":\"LiveChat for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2015\\/11\\/LC_woo_regular-zmiaym.png\",\"excerpt\":\"Live Chat and messaging platform for sales and support -- increase average order value and overall sales through live conversations.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/livechat\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/www.livechat.com\\/livechat-for-ecommerce\\/?a=woocommerce&amp;utm_source=woocommerce.com&amp;utm_medium=integration&amp;utm_campaign=woocommerce.com\",\"price\":\"&#36;0.00\",\"hash\":\"5344cc1f-ed4a-4d00-beff-9d67f6d372f3\",\"slug\":\"livechat-woocommerce\",\"id\":1348888},{\"title\":\"Product CSV Import Suite\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Product-CSV-Import-Dark.png\",\"excerpt\":\"Import, merge, and export products and variations to and from WooCommerce using a CSV file.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-csv-import-suite\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"7ac9b00a1fe980fb61d28ab54d167d0d\",\"slug\":\"woocommerce-product-csv-import-suite\",\"id\":18680},{\"title\":\"Follow-Ups\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Follow-Ups-Dark.png\",\"excerpt\":\"Automatically contact customers after purchase - be it everyone, your most loyal or your biggest spenders - and keep your store top-of-mind.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/follow-up-emails\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"05ece68fe94558e65278fe54d9ec84d2\",\"slug\":\"woocommerce-follow-up-emails\",\"id\":18686},{\"title\":\"Authorize.Net\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2013\\/04\\/Thumbnail-Authorize.net-updated.png\",\"excerpt\":\"Authorize.Net gateway with support for pre-orders and subscriptions.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/authorize-net\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"8b61524fe53add7fdd1a8d1b00b9327d\",\"slug\":\"woocommerce-gateway-authorize-net-cim\",\"id\":178481},{\"title\":\"Australia Post Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/09\\/australia-post.gif\",\"excerpt\":\"Get shipping rates for your WooCommerce store from the Australia Post API, which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/australia-post-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"1dbd4dc6bd91a9cda1bd6b9e7a5e4f43\",\"slug\":\"woocommerce-shipping-australia-post\",\"id\":18622},{\"title\":\"Canada Post Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/09\\/canada-post.png\",\"excerpt\":\"Get shipping rates from the Canada Post Ratings API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/canada-post-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"ac029cdf3daba20b20c7b9be7dc00e0e\",\"slug\":\"woocommerce-shipping-canada-post\",\"id\":18623},{\"title\":\"WooCommerce Customer \\/ Order \\/ Coupon Export\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/02\\/Thumbnail-Customer-Order-Coupon-Export-updated.png\",\"excerpt\":\"Export customers, orders, and coupons from WooCommerce manually or on an automated schedule.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/ordercustomer-csv-export\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"914de15813a903c767b55445608bf290\",\"slug\":\"woocommerce-customer-order-csv-export\",\"id\":18652},{\"title\":\"Product Vendors\",\"image\":\"\",\"excerpt\":\"Turn your store into a multi-vendor marketplace\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-vendors\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"a97d99fccd651bbdd728f4d67d492c31\",\"slug\":\"woocommerce-product-vendors\",\"id\":219982},{\"title\":\"WooCommerce Accommodation Bookings\",\"image\":\"\",\"excerpt\":\"Book accommodation using WooCommerce and the WooCommerce Bookings extension.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-accommodation-bookings\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"99b2a7a4af90b6cefd2a733b3b1f78e7\",\"slug\":\"woocommerce-accommodation-bookings\",\"id\":1412069},{\"title\":\"Royal Mail\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2013\\/04\\/royalmail.png\",\"excerpt\":\"Offer Royal Mail shipping rates to your customers\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/royal-mail\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"03839cca1a16c4488fcb669aeb91a056\",\"slug\":\"woocommerce-shipping-royalmail\",\"id\":182719},{\"title\":\"WooCommerce Brands\",\"image\":\"\",\"excerpt\":\"Create, assign and list brands for products, and allow customers to view by brand.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/brands\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"8a88c7cbd2f1e73636c331c7a86f818c\",\"slug\":\"woocommerce-brands\",\"id\":18737},{\"title\":\"Xero\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2012\\/08\\/xero2.png\",\"excerpt\":\"Save time with automated sync between WooCommerce and your Xero account.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/xero\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"f0dd29d338d3c67cf6cee88eddf6869b\",\"slug\":\"woocommerce-xero\",\"id\":18733},{\"title\":\"Smart Coupons\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/10\\/wc-product-smart-coupons.png\",\"excerpt\":\"Everything you need for discounts, coupons, credits, gift cards, product giveaways, offers, and promotions. Most popular and complete coupons plugin for WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/smart-coupons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"http:\\/\\/demo.storeapps.org\\/?demo=sc\",\"price\":\"&#36;99.00\",\"hash\":\"05c45f2aa466106a466de4402fff9dde\",\"slug\":\"woocommerce-smart-coupons\",\"id\":18729},{\"title\":\"AutomateWoo\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-AutomateWoo-Dark-1.png\",\"excerpt\":\"Powerful marketing automation for WooCommerce. AutomateWoo has the tools you need to grow your store and make more money.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/automatewoo\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"ba9299b8-1dba-4aa0-a313-28bc1755cb88\",\"slug\":\"automatewoo\",\"id\":4652610},{\"title\":\"Advanced Notifications\",\"image\":\"\",\"excerpt\":\"Easily setup \\\"new order\\\" and stock email notifications for multiple recipients of your choosing.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/advanced-notifications\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"112372c44b002fea2640bd6bfafbca27\",\"slug\":\"woocommerce-advanced-notifications\",\"id\":18740},{\"title\":\"WooCommerce Points and Rewards\",\"image\":\"\",\"excerpt\":\"Reward your customers for purchases and other actions with points which can be redeemed for discounts.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-points-and-rewards\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"1649b6cca5da8b923b01ca56b5cdd246\",\"slug\":\"woocommerce-points-and-rewards\",\"id\":210259},{\"title\":\"WooCommerce Zapier\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/woocommerce-zapier-logo.png\",\"excerpt\":\"Integrate with 3000+ cloud apps and services today.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-zapier\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;59.00\",\"hash\":\"0782bdbe932c00f4978850268c6cfe40\",\"slug\":\"woocommerce-zapier\",\"id\":243589},{\"title\":\"Dynamic Pricing\",\"image\":\"\",\"excerpt\":\"Bulk discounts, role-based pricing and much more\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/dynamic-pricing\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"9a41775bb33843f52c93c922b0053986\",\"slug\":\"woocommerce-dynamic-pricing\",\"id\":18643},{\"title\":\"WooCommerce Pre-Orders\",\"image\":\"\",\"excerpt\":\"Allow customers to order products before they are available.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-pre-orders\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"b2dc75e7d55e6f5bbfaccb59830f66b7\",\"slug\":\"woocommerce-pre-orders\",\"id\":178477},{\"title\":\"WooCommerce Subscription Downloads\",\"image\":\"\",\"excerpt\":\"Offer additional downloads to your subscribers, via downloadable products listed in your store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-subscription-downloads\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"5be9e21c13953253e4406d2a700382ec\",\"slug\":\"woocommerce-subscription-downloads\",\"id\":420458},{\"title\":\"Name Your Price\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2012\\/09\\/nyp-icon-dark-v83owf.png\",\"excerpt\":\"Allow customers to define the product price. Also useful for accepting user-set donations.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/name-your-price\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"31b4e11696cd99a3c0572975a84f1c08\",\"slug\":\"woocommerce-name-your-price\",\"id\":18738},{\"title\":\"WooCommerce Additional Variation Images\",\"image\":\"\",\"excerpt\":\"Add gallery images per variation on variable products within WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-additional-variation-images\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/themes.woocommerce.com\\/storefront\\/product\\/woo-single-1\\/\",\"price\":\"&#36;49.00\",\"hash\":\"c61dd6de57dcecb32bd7358866de4539\",\"slug\":\"woocommerce-additional-variation-images\",\"id\":477384},{\"title\":\"WooCommerce Print Invoices &amp; Packing lists\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/03\\/Thumbnail-Print-Invoices-Packing-lists-updated.png\",\"excerpt\":\"Generate invoices, packing slips, and pick lists for your WooCommerce orders.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/print-invoices-packing-lists\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"465de1126817cdfb42d97ebca7eea717\",\"slug\":\"woocommerce-pip\",\"id\":18666},{\"title\":\"WooCommerce Deposits\",\"image\":\"\",\"excerpt\":\"Enable customers to pay for products using a deposit or a payment plan.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-deposits\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;179.00\",\"hash\":\"de192a6cf12c4fd803248da5db700762\",\"slug\":\"woocommerce-deposits\",\"id\":977087},{\"title\":\"Amazon S3 Storage\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/09\\/amazon.png\",\"excerpt\":\"Serve digital products via Amazon S3\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/amazon-s3-storage\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"473bf6f221b865eff165c97881b473bb\",\"slug\":\"woocommerce-amazon-s3-storage\",\"id\":18663},{\"title\":\"Cart Add-ons\",\"image\":\"\",\"excerpt\":\"A powerful tool for driving incremental and impulse purchases by customers once they are in the shopping cart\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/cart-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"3a8ef25334396206f5da4cf208adeda3\",\"slug\":\"woocommerce-cart-add-ons\",\"id\":18717},{\"title\":\"Google Product Feed\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2011\\/11\\/logo-regular-lscryp.png\",\"excerpt\":\"Feed product data to Google Merchant Center for setting up Google product listings &amp; product ads.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/google-product-feed\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"d55b4f852872025741312839f142447e\",\"slug\":\"woocommerce-product-feeds\",\"id\":18619},{\"title\":\"Shipping Multiple Addresses\",\"image\":\"\",\"excerpt\":\"Allow your customers to ship individual items in a single order to multiple addresses.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipping-multiple-addresses\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"aa0eb6f777846d329952d5b891d6f8cc\",\"slug\":\"woocommerce-shipping-multiple-addresses\",\"id\":18741},{\"title\":\"WooCommerce AvaTax\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2016\\/01\\/Thumbnail-Avalara-updated.png\",\"excerpt\":\"Get 100% accurate sales tax calculations and on time tax return filing. No more tracking sales tax rates, rules, or jurisdictional boundaries.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-avatax\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"57077a4b28ba71cacf692bcf4a1a7f60\",\"slug\":\"woocommerce-avatax\",\"id\":1389326},{\"title\":\"Klarna Checkout\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2018\\/01\\/Partner_marketing_Klarna_Checkout_Black-1.png\",\"excerpt\":\"Klarna Checkout is a full checkout experience embedded on your site that includes all popular payment methods (Pay Now, Pay Later, Financing, Installments).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/klarna-checkout\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/demo.krokedil.se\\/klarnacheckout\\/\",\"price\":\"&#36;0.00\",\"hash\":\"90f8ce584e785fcd8c2d739fd4f40d78\",\"slug\":\"klarna-checkout-for-woocommerce\",\"id\":2754152},{\"title\":\"TaxJar\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/10\\/taxjar-logotype.png\",\"excerpt\":\"Save hours every month by putting your sales tax on autopilot. Automated, multi-state sales tax calculation, reporting, and filing for your WooCommerce store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/taxjar\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"12072d8e-e933-4561-97b1-9db3c7eeed91\",\"slug\":\"taxjar-simplified-taxes-for-woocommerce\",\"id\":514914},{\"title\":\"Bulk Stock Management\",\"image\":\"\",\"excerpt\":\"Edit product and variation stock levels in bulk via this handy interface\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/bulk-stock-management\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"02f4328d52f324ebe06a78eaaae7934f\",\"slug\":\"woocommerce-bulk-stock-management\",\"id\":18670},{\"title\":\"WooCommerce Email Customizer\",\"image\":\"\",\"excerpt\":\"Connect with your customers with each email you send by visually modifying your email templates via the WordPress Customizer.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-email-customizer\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"bd909fa97874d431f203b5336c7e8873\",\"slug\":\"woocommerce-email-customizer\",\"id\":853277},{\"title\":\"Force Sells\",\"image\":\"\",\"excerpt\":\"Force products to be added to the cart\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/force-sells\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"3ebddfc491ca168a4ea4800b893302b0\",\"slug\":\"woocommerce-force-sells\",\"id\":18678},{\"title\":\"WooCommerce Quick View\",\"image\":\"\",\"excerpt\":\"Show a quick-view button to view product details and add to cart via lightbox popup\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-quick-view\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"619c6e57ce72c49c4b57e15b06eddb65\",\"slug\":\"woocommerce-quick-view\",\"id\":187509},{\"title\":\"WooCommerce Purchase Order Gateway\",\"image\":\"\",\"excerpt\":\"Receive purchase orders via your WooCommerce-powered online store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gateway-purchase-order\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"573a92318244ece5facb449d63e74874\",\"slug\":\"woocommerce-gateway-purchase-order\",\"id\":478542},{\"title\":\"PayPal Payments Pro\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Paypal-Payments-Pro-Dark.png\",\"excerpt\":\"Take credit card payments directly on your checkout using PayPal Pro.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/paypal-pro\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"6d23ba7f0e0198937c0029f9e865b40e\",\"slug\":\"woocommerce-gateway-paypal-pro\",\"id\":18594},{\"title\":\"Returns and Warranty Requests\",\"image\":\"\",\"excerpt\":\"Manage the RMA process, add warranties to products &amp; let customers request &amp; manage returns \\/ exchanges from their account.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/warranty-requests\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"9b4c41102e6b61ea5f558e16f9b63e25\",\"slug\":\"woocommerce-warranty\",\"id\":228315},{\"title\":\"Gravity Forms Product Add-ons\",\"image\":\"\",\"excerpt\":\"Powerful product add-ons, Gravity style\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/gravity-forms-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/www.elementstark.com\\/woocommerce-extension-demos\\/product-category\\/gravity-forms\\/\",\"price\":\"&#36;99.00\",\"hash\":\"a6ac0ab1a1536e3a357ccf24c0650ed0\",\"slug\":\"woocommerce-gravityforms-product-addons\",\"id\":18633},{\"title\":\"Product Enquiry Form\",\"image\":\"\",\"excerpt\":\"Allow visitors to contact you directly from the product details page via a reCAPTCHA protected form to enquire about a product.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-enquiry-form\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"5a0f5d72519a8ffcc86669f042296937\",\"slug\":\"woocommerce-product-enquiry-form\",\"id\":18601},{\"title\":\"WooCommerce Box Office\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-BO-Dark.png\",\"excerpt\":\"Sell tickets for your next event, concert, function, fundraiser or conference directly on your own site\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-box-office\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"e704c9160de318216a8fa657404b9131\",\"slug\":\"woocommerce-box-office\",\"id\":1628717},{\"title\":\"Composite Products\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/07\\/Logo-CP.png?v=1\",\"excerpt\":\"Create product kit builders and custom product configurators using existing products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/composite-products\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"0343e0115bbcb97ccd98442b8326a0af\",\"slug\":\"woocommerce-composite-products\",\"id\":216836},{\"title\":\"WooCommerce Order Barcodes\",\"image\":\"\",\"excerpt\":\"Generates a unique barcode for each order on your site - perfect for e-tickets, packing slips, reservations and a variety of other uses.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-order-barcodes\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"889835bb29ee3400923653e1e44a3779\",\"slug\":\"woocommerce-order-barcodes\",\"id\":391708},{\"title\":\"WooCommerce 360\\u00ba Image\",\"image\":\"\",\"excerpt\":\"An easy way to add a dynamic, controllable 360\\u00ba image rotation to your WooCommerce site, by adding a group of images to a product\\u2019s gallery.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-360-image\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"24eb2cfa3738a66bf3b2587876668cd2\",\"slug\":\"woocommerce-360-image\",\"id\":512186},{\"title\":\"WooCommerce Photography\",\"image\":\"\",\"excerpt\":\"Sell photos in the blink of an eye using this simple as dragging &amp; dropping interface.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-photography\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"ee76e8b9daf1d97ca4d3874cc9e35687\",\"slug\":\"woocommerce-photography\",\"id\":583602},{\"title\":\"WooCommerce Bookings Availability\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Bookings-Aval-Dark.png\",\"excerpt\":\"Sell more bookings by presenting a calendar or schedule of available slots in a page or post.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/bookings-availability\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"30770d2a-e392-4e82-baaa-76cfc7d02ae3\",\"slug\":\"woocommerce-bookings-availability\",\"id\":4228225},{\"title\":\"Software Add-on\",\"image\":\"\",\"excerpt\":\"Sell License Keys for Software\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/software-add-on\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"79f6dbfe1f1d3a56a86f0509b6d6b04b\",\"slug\":\"woocommerce-software-add-on\",\"id\":18683},{\"title\":\"WooCommerce Products Compare\",\"image\":\"\",\"excerpt\":\"WooCommerce Products Compare will allow your potential customers to easily compare products within your store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-products-compare\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"c3ba0a4a3199a0cc7a6112eb24414548\",\"slug\":\"woocommerce-products-compare\",\"id\":853117},{\"title\":\"WooCommerce Store Catalog PDF Download\",\"image\":\"\",\"excerpt\":\"Offer your customers a PDF download of your product catalog, generated by WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-store-catalog-pdf-download\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"79ca7aadafe706364e2d738b7c1090c4\",\"slug\":\"woocommerce-store-catalog-pdf-download\",\"id\":675790},{\"title\":\"WooCommerce Paid Courses\",\"image\":\"\",\"excerpt\":\"Sell your online courses using the most popular eCommerce platform on the web \\u2013 WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-paid-courses\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"bad2a02a063555b7e2bee59924690763\",\"slug\":\"woothemes-sensei\",\"id\":152116},{\"title\":\"eWAY\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2011\\/10\\/eway-logo-3000-2000.jpg\",\"excerpt\":\"Take credit card payments securely via eWay (SG, MY, HK, AU, and NZ) keeping customers on your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/eway\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"2c497769d98d025e0d340cd0b5ea5da1\",\"slug\":\"woocommerce-gateway-eway\",\"id\":18604},{\"title\":\"PayPal\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2020\\/10\\/PPCP-Tile-PayPal-Logo-and-Cart-Art-2x-2-uozwz8.jpg\",\"excerpt\":\"PayPal\\u2019s latest, most complete payment processing solution. Accept PayPal exclusives, credit\\/debit cards and local payment methods. Turn on only PayPal options or process a full suite of payment methods. Enable global transactions with extensive currency and country coverage. Built and supported by WooCommerce and PayPal.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-paypal-payments\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"934115ab-e3f3-4435-9580-345b1ce21899\",\"slug\":\"woocommerce-paypal-payments\",\"id\":6410731},{\"title\":\"Catalog Visibility Options\",\"image\":\"\",\"excerpt\":\"Transform WooCommerce into an online catalog by removing eCommerce functionality\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/catalog-visibility-options\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"12e791110365fdbb5865c8658907967e\",\"slug\":\"woocommerce-catalog-visibility-options\",\"id\":18648},{\"title\":\"QuickBooks Sync for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2019\\/04\\/woocommerce-com-logo-1-hyhzbh.png\",\"excerpt\":\"Automatic two-way sync for orders, customers, products, inventory and more between WooCommerce and QuickBooks (Online, Desktop, or POS).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/quickbooks-sync-for-woocommerce\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"c5e32e20-7c1f-4585-8b15-d930c2d842ac\",\"slug\":\"myworks-woo-sync-for-quickbooks-online\",\"id\":4065824},{\"title\":\"WooCommerce Blocks\",\"image\":\"\",\"excerpt\":\"WooCommerce Blocks offers a range of Gutenberg blocks you can use to build and customise your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gutenberg-products-block\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"c2e9f13a-f90c-4ffe-a8a5-b432399ec263\",\"slug\":\"woo-gutenberg-products-block\",\"id\":3076677},{\"title\":\"Conditional Shipping and Payments\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/07\\/Logo-CSP.png?v=1\",\"excerpt\":\"Use conditional logic to restrict the shipping and payment options available on your store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/conditional-shipping-and-payments\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"1f56ff002fa830b77017b0107505211a\",\"slug\":\"woocommerce-conditional-shipping-and-payments\",\"id\":680253},{\"title\":\"Sequential Order Numbers Pro\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/05\\/Thumbnail-Sequential-Order-Numbers-Pro-updated.png\",\"excerpt\":\"Tame your order numbers! Advanced &amp; sequential order numbers with optional prefixes \\/ suffixes\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/sequential-order-numbers-pro\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"0b18a2816e016ba9988b93b1cd8fe766\",\"slug\":\"woocommerce-sequential-order-numbers-pro\",\"id\":18688},{\"title\":\"WooCommerce Order Status Manager\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2015\\/02\\/Thumbnail-Order-Status-Manager-updated.png\",\"excerpt\":\"Create, edit, and delete completely custom order statuses and integrate them seamlessly into your order management flow.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-order-status-manager\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"51fd9ab45394b4cad5a0ebf58d012342\",\"slug\":\"woocommerce-order-status-manager\",\"id\":588398},{\"title\":\"WooCommerce Checkout Add-Ons\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/07\\/Thumbnail-Checkout-Add-Ons-updated.png\",\"excerpt\":\"Highlight relevant products, offers like free shipping and other up-sells during checkout.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-checkout-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"8fdca00b4000b7a8cc26371d0e470a8f\",\"slug\":\"woocommerce-checkout-add-ons\",\"id\":466854},{\"title\":\"WooCommerce Google Analytics Pro\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2016\\/01\\/Thumbnail-GAPro-updated.png\",\"excerpt\":\"Add advanced event tracking and enhanced eCommerce tracking to your WooCommerce site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-google-analytics-pro\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"d8aed8b7306b509eec1589e59abe319f\",\"slug\":\"woocommerce-google-analytics-pro\",\"id\":1312497},{\"title\":\"WooCommerce One Page Checkout\",\"image\":\"\",\"excerpt\":\"Create special pages where customers can choose products, checkout &amp; pay all on the one page.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-one-page-checkout\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"c9ba8f8352cd71b5508af5161268619a\",\"slug\":\"woocommerce-one-page-checkout\",\"id\":527886},{\"title\":\"WooCommerce Product Search\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2014\\/10\\/woocommerce-product-search-product-image-1870x960-1-jvsljj.png\",\"excerpt\":\"The perfect search engine helps customers to find and buy products quickly \\u2013 essential for every WooCommerce store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-product-search\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/demo.itthinx.com\\/wps\\/\",\"price\":\"&#36;49.00\",\"hash\":\"c84cc8ca16ddac3408e6b6c5871133a8\",\"slug\":\"woocommerce-product-search\",\"id\":512174},{\"title\":\"Coupon Shortcodes\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2013\\/09\\/woocommerce-coupon-shortcodes-product-image-1870x960-1-vc5gux.png\",\"excerpt\":\"Show coupon discount info using shortcodes. Allows to render coupon information and content conditionally, based on the validity of coupons.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/coupon-shortcodes\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"ac5d9d51-70b2-4d8f-8b89-24200eea1394\",\"slug\":\"woocommerce-coupon-shortcodes\",\"id\":244762},{\"title\":\"First Data\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/02\\/Thumbnail-FirstData-updated.png\",\"excerpt\":\"FirstData gateway for WooCommerce\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/firstdata\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"eb3e32663ec0810592eaf0d097796230\",\"slug\":\"woocommerce-gateway-firstdata\",\"id\":18645},{\"title\":\"Jilt\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2017\\/12\\/Thumbnail-Jilt-updated.png\",\"excerpt\":\"All-in-one email marketing platform built for WooCommerce stores. Send newsletters, abandoned cart reminders, win-backs, welcome automations, and more.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/jilt\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"b53aafb64dca33835e41ee06de7e9816\",\"slug\":\"jilt-for-woocommerce\",\"id\":2754876},{\"title\":\"WooSlider\",\"image\":\"\",\"excerpt\":\"WooSlider is the ultimate responsive slideshow WordPress slider plugin\\r\\n\\r\\n\\u00a0\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/wooslider\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"http:\\/\\/www.wooslider.com\\/\",\"price\":\"&#36;49.00\",\"hash\":\"209d98f3ccde6cc3de7e8732a2b20b6a\",\"slug\":\"wooslider\",\"id\":46506},{\"title\":\"WooCommerce Social Login\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/08\\/Thumbnail-Social-Login-updated.png\",\"excerpt\":\"Enable Social Login for seamless checkout and account creation.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-social-login\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"http:\\/\\/demos.skyverge.com\\/woocommerce-social-login\\/\",\"price\":\"&#36;79.00\",\"hash\":\"b231cd6367a79cc8a53b7d992d77525d\",\"slug\":\"woocommerce-social-login\",\"id\":473617},{\"title\":\"WooCommerce Order Status Control\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/06\\/Thumbnail-Order-Status-Control-updated.png\",\"excerpt\":\"Use this extension to automatically change the order status to \\\"completed\\\" after successful payment.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-order-status-control\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"32400e509c7c36dcc1cd368e8267d981\",\"slug\":\"woocommerce-order-status-control\",\"id\":439037},{\"title\":\"Variation Swatches and Photos\",\"image\":\"\",\"excerpt\":\"Show color and image swatches instead of dropdowns for variable products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/variation-swatches-and-photos\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/www.elementstark.com\\/woocommerce-extension-demos\\/product-category\\/swatches-and-photos\\/\",\"price\":\"&#36;99.00\",\"hash\":\"37bea8d549df279c8278878d081b062f\",\"slug\":\"woocommerce-variation-swatches-and-photos\",\"id\":18697},{\"title\":\"Opayo Payment Suite\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2011\\/10\\/Opayo_logo_RGB.png\",\"excerpt\":\"Take payments on your WooCommerce store via Opayo (formally SagePay).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/sage-pay-form\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"6bc0cca47d0274d8ef9b164f6fbec1cc\",\"slug\":\"woocommerce-gateway-sagepay-form\",\"id\":18599},{\"title\":\"EU VAT Number\",\"image\":\"\",\"excerpt\":\"Collect VAT numbers at checkout and remove the VAT charge for eligible EU businesses.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/eu-vat-number\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"d2720c4b4bb8d6908e530355b7a2d734\",\"slug\":\"woocommerce-eu-vat-number\",\"id\":18592},{\"title\":\"Customer\\/Order\\/Coupon CSV Import Suite\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/07\\/Thumbnail-Customer-Order-Coupon-CSV-Import-Suite-updated.png\",\"excerpt\":\"Import both customers and orders into WooCommerce from a CSV file.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/customerorder-csv-import-suite\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"eb00ca8317a0f64dbe185c995e5ea3df\",\"slug\":\"woocommerce-customer-order-csv-import\",\"id\":18709}]}\";s:8:\"response\";a:2:{s:4:\"code\";i:200;s:7:\"message\";s:2:\"OK\";}s:7:\"cookies\";a:0:{}s:8:\"filename\";N;s:13:\"http_response\";O:25:\"WP_HTTP_Requests_Response\":5:{s:11:\"\0*\0response\";O:17:\"Requests_Response\":10:{s:4:\"body\";s:48319:\"{\"products\":[{\"title\":\"WooCommerce Google Analytics\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/GA-Dark.png\",\"excerpt\":\"Understand your customers and increase revenue with world\\u2019s leading analytics platform - integrated with WooCommerce for free.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-google-analytics\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"2d21f7de14dfb8e9885a4622be701ddf\",\"slug\":\"woocommerce-google-analytics-integration\",\"id\":1442927},{\"title\":\"WooCommerce Tax\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Tax-Dark.png\",\"excerpt\":\"Automatically calculate how much sales tax should be collected for WooCommerce orders - by city, country, or state - at checkout.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/tax\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"f31b3b9273cce188cc2b27f7849d02dd\",\"slug\":\"woocommerce-services\",\"id\":3220291},{\"title\":\"Stripe\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Stripe-Dark-1.png\",\"excerpt\":\"Accept all major debit and credit cards as well as local payment methods with Stripe.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/stripe\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"50bb7a985c691bb943a9da4d2c8b5efd\",\"slug\":\"woocommerce-gateway-stripe\",\"id\":18627},{\"title\":\"Jetpack\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Jetpack-Dark.png\",\"excerpt\":\"Power up and protect your store with Jetpack\\r\\n\\r\\nFor free security, insights and monitoring, connect to Jetpack. It\'s everything you need for a strong, secure start.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/jetpack\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"d5bfef9700b62b2b132c74c74c3193eb\",\"slug\":\"jetpack\",\"id\":2725249},{\"title\":\"Facebook for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Facebook-Dark.png\",\"excerpt\":\"Get the Official Facebook for WooCommerce plugin for three powerful ways to help grow your business.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/facebook\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"0ea4fe4c2d7ca6338f8a322fb3e4e187\",\"slug\":\"facebook-for-woocommerce\",\"id\":2127297},{\"title\":\"Amazon Pay\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Amazon-Pay-Dark.png\",\"excerpt\":\"Amazon Pay is embedded in your WooCommerce store. Transactions take place via\\u00a0Amazon widgets, so the buyer never leaves your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/pay-with-amazon\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"9865e043bbbe4f8c9735af31cb509b53\",\"slug\":\"woocommerce-gateway-amazon-payments-advanced\",\"id\":238816},{\"title\":\"Square for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Square-Dark.png\",\"excerpt\":\"Accepting payments is easy with Square. Clear rates, fast deposits (1-2 business days). Sell online and in person, and sync all payments, items and inventory.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/square\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"e907be8b86d7df0c8f8e0d0020b52638\",\"slug\":\"woocommerce-square\",\"id\":1770503},{\"title\":\"WooCommerce Shipping\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Ship-Dark-1.png\",\"excerpt\":\"Print USPS and DHL labels right from your WooCommerce dashboard and instantly save up to 90%. WooCommerce Shipping is free to use and saves you time and money.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipping\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"f31b3b9273cce188cc2b27f7849d02dd\",\"slug\":\"woocommerce-services\",\"id\":2165910},{\"title\":\"WooCommerce Payments\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Pay-Dark.png\",\"excerpt\":\"Securely accept payments, track cash flow, and manage recurring revenue from your dashboard \\u2014 all without setup costs or monthly fees.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-payments\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"8c6319ca-8f41-4e69-be63-6b15ee37773b\",\"slug\":\"woocommerce-payments\",\"id\":5278104},{\"title\":\"Mailchimp for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/09\\/logo-mailchimp-dark-v2.png\",\"excerpt\":\"Increase traffic, drive repeat purchases, and personalize your marketing when you connect to Mailchimp.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/mailchimp-for-woocommerce\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"b4481616ebece8b1ff68fc59b90c1a91\",\"slug\":\"mailchimp-for-woocommerce\",\"id\":2545166},{\"title\":\"WooCommerce Subscriptions\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Subscriptions-Dark.png\",\"excerpt\":\"Let customers subscribe to your products or services and pay on a weekly, monthly or annual basis.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-subscriptions\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;199.00\",\"hash\":\"6115e6d7e297b623a169fdcf5728b224\",\"slug\":\"woocommerce-subscriptions\",\"id\":27147},{\"title\":\"PayPal Checkout\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Paypal-Dark.png\",\"excerpt\":\"PayPal Checkout now with Smart Payment Buttons\\u2122, dynamically displays, PayPal, Venmo, PayPal Credit, or other local payment options in a single stack giving customers the choice to pay with their preferred option.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gateway-paypal-checkout\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"69e6cba62ac4021df9e117cc3f716d07\",\"slug\":\"woocommerce-gateway-paypal-express-checkout\",\"id\":1597922},{\"title\":\"ShipStation Integration\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Shipstation-Dark.png\",\"excerpt\":\"Fulfill all your Woo orders (and wherever else you sell) quickly and easily using ShipStation. Try it free for 30 days today!\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipstation-integration\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"9de8640767ba64237808ed7f245a49bb\",\"slug\":\"woocommerce-shipstation-integration\",\"id\":18734},{\"title\":\"Product Add-Ons\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Product-Add-Ons-Dark.png\",\"excerpt\":\"Offer add-ons like gift wrapping, special messages or other special options for your products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"147d0077e591e16db9d0d67daeb8c484\",\"slug\":\"woocommerce-product-addons\",\"id\":18618},{\"title\":\"PayFast Payment Gateway\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Payfast-Dark-1.png\",\"excerpt\":\"Take payments on your WooCommerce store via PayFast (redirect method).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/payfast-payment-gateway\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"557bf07293ad916f20c207c6c9cd15ff\",\"slug\":\"woocommerce-payfast-gateway\",\"id\":18596},{\"title\":\"Google Ads &amp; Marketing by Kliken\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2019\\/02\\/GA-for-Woo-Logo-374x192px-qu3duk.png\",\"excerpt\":\"Get in front of shoppers and drive traffic to your store so you can grow your business with Smart Shopping Campaigns and free listings.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/google-ads-and-marketing\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"bf66e173-a220-4da7-9512-b5728c20fc16\",\"slug\":\"kliken-marketing-for-google\",\"id\":3866145},{\"title\":\"USPS Shipping Method\",\"image\":\"\",\"excerpt\":\"Get shipping rates from the USPS API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/usps-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"83d1524e8f5f1913e58889f83d442c32\",\"slug\":\"woocommerce-shipping-usps\",\"id\":18657},{\"title\":\"UPS Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/UPS-Shipping-Method-Dark.png\",\"excerpt\":\"Get shipping rates from the UPS API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/ups-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"8dae58502913bac0fbcdcaba515ea998\",\"slug\":\"woocommerce-shipping-ups\",\"id\":18665},{\"title\":\"Shipment Tracking\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Ship-Tracking-Dark-1.png\",\"excerpt\":\"Add shipment tracking information to your orders.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipment-tracking\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"1968e199038a8a001c9f9966fd06bf88\",\"slug\":\"woocommerce-shipment-tracking\",\"id\":18693},{\"title\":\"Table Rate Shipping\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Product-Table-Rate-Shipping-Dark.png\",\"excerpt\":\"Advanced, flexible shipping. Define multiple shipping rates based on location, price, weight, shipping class or item count.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/table-rate-shipping\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"3034ed8aff427b0f635fe4c86bbf008a\",\"slug\":\"woocommerce-table-rate-shipping\",\"id\":18718},{\"title\":\"Checkout Field Editor\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Checkout-Field-Editor-Dark.png\",\"excerpt\":\"Optimize your checkout process by adding, removing or editing fields to suit your needs.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-checkout-field-editor\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"2b8029f0d7cdd1118f4d843eb3ab43ff\",\"slug\":\"woocommerce-checkout-field-editor\",\"id\":184594},{\"title\":\"Braintree for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2016\\/02\\/braintree-black-copy.png\",\"excerpt\":\"Accept PayPal, credit cards and debit cards with a single payment gateway solution \\u2014 PayPal Powered by Braintree.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gateway-paypal-powered-by-braintree\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"27f010c8e34ca65b205ddec88ad14536\",\"slug\":\"woocommerce-gateway-paypal-powered-by-braintree\",\"id\":1489837},{\"title\":\"WooCommerce Bookings\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Bookings-Dark.png\",\"excerpt\":\"Allow customers to book appointments, make reservations or rent equipment without leaving your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-bookings\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/themes.woocommerce.com\\/hotel\\/\",\"price\":\"&#36;249.00\",\"hash\":\"911c438934af094c2b38d5560b9f50f3\",\"slug\":\"WooCommerce Bookings\",\"id\":390890},{\"title\":\"WooCommerce Memberships\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2015\\/06\\/Thumbnail-Memberships-updated.png\",\"excerpt\":\"Give members access to restricted content or products, for a fee or for free.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-memberships\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;199.00\",\"hash\":\"9288e7609ad0b487b81ef6232efa5cfc\",\"slug\":\"woocommerce-memberships\",\"id\":958589},{\"title\":\"Product Bundles\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/07\\/Logo-PB.png?v=1\",\"excerpt\":\"Offer personalized product bundles, bulk discount packages, and assembled\\u00a0products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-bundles\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"aa2518b5-ab19-4b75-bde9-60ca51e20f28\",\"slug\":\"woocommerce-product-bundles\",\"id\":18716},{\"title\":\"Multichannel for WooCommerce: Google, Amazon, eBay &amp; Walmart Integration\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2018\\/10\\/Woo-Extension-Store-Logo-v2.png\",\"excerpt\":\"Get the official Google, Amazon, eBay and Walmart extension and create, sync and manage multichannel listings directly from WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/amazon-ebay-integration\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"e4000666-9275-4c71-8619-be61fb41c9f9\",\"slug\":\"woocommerce-amazon-ebay-integration\",\"id\":3545890},{\"title\":\"Min\\/Max Quantities\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Min-Max-Qua-Dark.png\",\"excerpt\":\"Specify minimum and maximum allowed product quantities for orders to be completed.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/minmax-quantities\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"2b5188d90baecfb781a5aa2d6abb900a\",\"slug\":\"woocommerce-min-max-quantities\",\"id\":18616},{\"title\":\"FedEx Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2013\\/01\\/FedEx_Logo_Wallpaper.jpeg\",\"excerpt\":\"Get shipping rates from the FedEx API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/fedex-shipping-module\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"1a48b598b47a81559baadef15e320f64\",\"slug\":\"woocommerce-shipping-fedex\",\"id\":18620},{\"title\":\"LiveChat for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2015\\/11\\/LC_woo_regular-zmiaym.png\",\"excerpt\":\"Live Chat and messaging platform for sales and support -- increase average order value and overall sales through live conversations.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/livechat\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/www.livechat.com\\/livechat-for-ecommerce\\/?a=woocommerce&amp;utm_source=woocommerce.com&amp;utm_medium=integration&amp;utm_campaign=woocommerce.com\",\"price\":\"&#36;0.00\",\"hash\":\"5344cc1f-ed4a-4d00-beff-9d67f6d372f3\",\"slug\":\"livechat-woocommerce\",\"id\":1348888},{\"title\":\"Product CSV Import Suite\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Product-CSV-Import-Dark.png\",\"excerpt\":\"Import, merge, and export products and variations to and from WooCommerce using a CSV file.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-csv-import-suite\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"7ac9b00a1fe980fb61d28ab54d167d0d\",\"slug\":\"woocommerce-product-csv-import-suite\",\"id\":18680},{\"title\":\"Follow-Ups\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Follow-Ups-Dark.png\",\"excerpt\":\"Automatically contact customers after purchase - be it everyone, your most loyal or your biggest spenders - and keep your store top-of-mind.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/follow-up-emails\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"05ece68fe94558e65278fe54d9ec84d2\",\"slug\":\"woocommerce-follow-up-emails\",\"id\":18686},{\"title\":\"Authorize.Net\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2013\\/04\\/Thumbnail-Authorize.net-updated.png\",\"excerpt\":\"Authorize.Net gateway with support for pre-orders and subscriptions.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/authorize-net\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"8b61524fe53add7fdd1a8d1b00b9327d\",\"slug\":\"woocommerce-gateway-authorize-net-cim\",\"id\":178481},{\"title\":\"Australia Post Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/09\\/australia-post.gif\",\"excerpt\":\"Get shipping rates for your WooCommerce store from the Australia Post API, which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/australia-post-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"1dbd4dc6bd91a9cda1bd6b9e7a5e4f43\",\"slug\":\"woocommerce-shipping-australia-post\",\"id\":18622},{\"title\":\"Canada Post Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/09\\/canada-post.png\",\"excerpt\":\"Get shipping rates from the Canada Post Ratings API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/canada-post-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"ac029cdf3daba20b20c7b9be7dc00e0e\",\"slug\":\"woocommerce-shipping-canada-post\",\"id\":18623},{\"title\":\"WooCommerce Customer \\/ Order \\/ Coupon Export\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/02\\/Thumbnail-Customer-Order-Coupon-Export-updated.png\",\"excerpt\":\"Export customers, orders, and coupons from WooCommerce manually or on an automated schedule.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/ordercustomer-csv-export\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"914de15813a903c767b55445608bf290\",\"slug\":\"woocommerce-customer-order-csv-export\",\"id\":18652},{\"title\":\"Product Vendors\",\"image\":\"\",\"excerpt\":\"Turn your store into a multi-vendor marketplace\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-vendors\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"a97d99fccd651bbdd728f4d67d492c31\",\"slug\":\"woocommerce-product-vendors\",\"id\":219982},{\"title\":\"WooCommerce Accommodation Bookings\",\"image\":\"\",\"excerpt\":\"Book accommodation using WooCommerce and the WooCommerce Bookings extension.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-accommodation-bookings\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"99b2a7a4af90b6cefd2a733b3b1f78e7\",\"slug\":\"woocommerce-accommodation-bookings\",\"id\":1412069},{\"title\":\"Royal Mail\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2013\\/04\\/royalmail.png\",\"excerpt\":\"Offer Royal Mail shipping rates to your customers\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/royal-mail\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"03839cca1a16c4488fcb669aeb91a056\",\"slug\":\"woocommerce-shipping-royalmail\",\"id\":182719},{\"title\":\"WooCommerce Brands\",\"image\":\"\",\"excerpt\":\"Create, assign and list brands for products, and allow customers to view by brand.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/brands\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"8a88c7cbd2f1e73636c331c7a86f818c\",\"slug\":\"woocommerce-brands\",\"id\":18737},{\"title\":\"Xero\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2012\\/08\\/xero2.png\",\"excerpt\":\"Save time with automated sync between WooCommerce and your Xero account.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/xero\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"f0dd29d338d3c67cf6cee88eddf6869b\",\"slug\":\"woocommerce-xero\",\"id\":18733},{\"title\":\"Smart Coupons\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/10\\/wc-product-smart-coupons.png\",\"excerpt\":\"Everything you need for discounts, coupons, credits, gift cards, product giveaways, offers, and promotions. Most popular and complete coupons plugin for WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/smart-coupons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"http:\\/\\/demo.storeapps.org\\/?demo=sc\",\"price\":\"&#36;99.00\",\"hash\":\"05c45f2aa466106a466de4402fff9dde\",\"slug\":\"woocommerce-smart-coupons\",\"id\":18729},{\"title\":\"AutomateWoo\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-AutomateWoo-Dark-1.png\",\"excerpt\":\"Powerful marketing automation for WooCommerce. AutomateWoo has the tools you need to grow your store and make more money.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/automatewoo\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"ba9299b8-1dba-4aa0-a313-28bc1755cb88\",\"slug\":\"automatewoo\",\"id\":4652610},{\"title\":\"Advanced Notifications\",\"image\":\"\",\"excerpt\":\"Easily setup \\\"new order\\\" and stock email notifications for multiple recipients of your choosing.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/advanced-notifications\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"112372c44b002fea2640bd6bfafbca27\",\"slug\":\"woocommerce-advanced-notifications\",\"id\":18740},{\"title\":\"WooCommerce Points and Rewards\",\"image\":\"\",\"excerpt\":\"Reward your customers for purchases and other actions with points which can be redeemed for discounts.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-points-and-rewards\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"1649b6cca5da8b923b01ca56b5cdd246\",\"slug\":\"woocommerce-points-and-rewards\",\"id\":210259},{\"title\":\"WooCommerce Zapier\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/woocommerce-zapier-logo.png\",\"excerpt\":\"Integrate with 3000+ cloud apps and services today.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-zapier\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;59.00\",\"hash\":\"0782bdbe932c00f4978850268c6cfe40\",\"slug\":\"woocommerce-zapier\",\"id\":243589},{\"title\":\"Dynamic Pricing\",\"image\":\"\",\"excerpt\":\"Bulk discounts, role-based pricing and much more\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/dynamic-pricing\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"9a41775bb33843f52c93c922b0053986\",\"slug\":\"woocommerce-dynamic-pricing\",\"id\":18643},{\"title\":\"WooCommerce Pre-Orders\",\"image\":\"\",\"excerpt\":\"Allow customers to order products before they are available.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-pre-orders\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"b2dc75e7d55e6f5bbfaccb59830f66b7\",\"slug\":\"woocommerce-pre-orders\",\"id\":178477},{\"title\":\"WooCommerce Subscription Downloads\",\"image\":\"\",\"excerpt\":\"Offer additional downloads to your subscribers, via downloadable products listed in your store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-subscription-downloads\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"5be9e21c13953253e4406d2a700382ec\",\"slug\":\"woocommerce-subscription-downloads\",\"id\":420458},{\"title\":\"Name Your Price\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2012\\/09\\/nyp-icon-dark-v83owf.png\",\"excerpt\":\"Allow customers to define the product price. Also useful for accepting user-set donations.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/name-your-price\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"31b4e11696cd99a3c0572975a84f1c08\",\"slug\":\"woocommerce-name-your-price\",\"id\":18738},{\"title\":\"WooCommerce Additional Variation Images\",\"image\":\"\",\"excerpt\":\"Add gallery images per variation on variable products within WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-additional-variation-images\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/themes.woocommerce.com\\/storefront\\/product\\/woo-single-1\\/\",\"price\":\"&#36;49.00\",\"hash\":\"c61dd6de57dcecb32bd7358866de4539\",\"slug\":\"woocommerce-additional-variation-images\",\"id\":477384},{\"title\":\"WooCommerce Print Invoices &amp; Packing lists\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/03\\/Thumbnail-Print-Invoices-Packing-lists-updated.png\",\"excerpt\":\"Generate invoices, packing slips, and pick lists for your WooCommerce orders.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/print-invoices-packing-lists\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"465de1126817cdfb42d97ebca7eea717\",\"slug\":\"woocommerce-pip\",\"id\":18666},{\"title\":\"WooCommerce Deposits\",\"image\":\"\",\"excerpt\":\"Enable customers to pay for products using a deposit or a payment plan.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-deposits\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;179.00\",\"hash\":\"de192a6cf12c4fd803248da5db700762\",\"slug\":\"woocommerce-deposits\",\"id\":977087},{\"title\":\"Amazon S3 Storage\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/09\\/amazon.png\",\"excerpt\":\"Serve digital products via Amazon S3\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/amazon-s3-storage\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"473bf6f221b865eff165c97881b473bb\",\"slug\":\"woocommerce-amazon-s3-storage\",\"id\":18663},{\"title\":\"Cart Add-ons\",\"image\":\"\",\"excerpt\":\"A powerful tool for driving incremental and impulse purchases by customers once they are in the shopping cart\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/cart-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"3a8ef25334396206f5da4cf208adeda3\",\"slug\":\"woocommerce-cart-add-ons\",\"id\":18717},{\"title\":\"Google Product Feed\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2011\\/11\\/logo-regular-lscryp.png\",\"excerpt\":\"Feed product data to Google Merchant Center for setting up Google product listings &amp; product ads.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/google-product-feed\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"d55b4f852872025741312839f142447e\",\"slug\":\"woocommerce-product-feeds\",\"id\":18619},{\"title\":\"Shipping Multiple Addresses\",\"image\":\"\",\"excerpt\":\"Allow your customers to ship individual items in a single order to multiple addresses.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipping-multiple-addresses\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"aa0eb6f777846d329952d5b891d6f8cc\",\"slug\":\"woocommerce-shipping-multiple-addresses\",\"id\":18741},{\"title\":\"WooCommerce AvaTax\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2016\\/01\\/Thumbnail-Avalara-updated.png\",\"excerpt\":\"Get 100% accurate sales tax calculations and on time tax return filing. No more tracking sales tax rates, rules, or jurisdictional boundaries.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-avatax\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"57077a4b28ba71cacf692bcf4a1a7f60\",\"slug\":\"woocommerce-avatax\",\"id\":1389326},{\"title\":\"Klarna Checkout\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2018\\/01\\/Partner_marketing_Klarna_Checkout_Black-1.png\",\"excerpt\":\"Klarna Checkout is a full checkout experience embedded on your site that includes all popular payment methods (Pay Now, Pay Later, Financing, Installments).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/klarna-checkout\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/demo.krokedil.se\\/klarnacheckout\\/\",\"price\":\"&#36;0.00\",\"hash\":\"90f8ce584e785fcd8c2d739fd4f40d78\",\"slug\":\"klarna-checkout-for-woocommerce\",\"id\":2754152},{\"title\":\"TaxJar\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/10\\/taxjar-logotype.png\",\"excerpt\":\"Save hours every month by putting your sales tax on autopilot. Automated, multi-state sales tax calculation, reporting, and filing for your WooCommerce store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/taxjar\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"12072d8e-e933-4561-97b1-9db3c7eeed91\",\"slug\":\"taxjar-simplified-taxes-for-woocommerce\",\"id\":514914},{\"title\":\"Bulk Stock Management\",\"image\":\"\",\"excerpt\":\"Edit product and variation stock levels in bulk via this handy interface\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/bulk-stock-management\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"02f4328d52f324ebe06a78eaaae7934f\",\"slug\":\"woocommerce-bulk-stock-management\",\"id\":18670},{\"title\":\"WooCommerce Email Customizer\",\"image\":\"\",\"excerpt\":\"Connect with your customers with each email you send by visually modifying your email templates via the WordPress Customizer.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-email-customizer\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"bd909fa97874d431f203b5336c7e8873\",\"slug\":\"woocommerce-email-customizer\",\"id\":853277},{\"title\":\"Force Sells\",\"image\":\"\",\"excerpt\":\"Force products to be added to the cart\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/force-sells\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"3ebddfc491ca168a4ea4800b893302b0\",\"slug\":\"woocommerce-force-sells\",\"id\":18678},{\"title\":\"WooCommerce Quick View\",\"image\":\"\",\"excerpt\":\"Show a quick-view button to view product details and add to cart via lightbox popup\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-quick-view\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"619c6e57ce72c49c4b57e15b06eddb65\",\"slug\":\"woocommerce-quick-view\",\"id\":187509},{\"title\":\"WooCommerce Purchase Order Gateway\",\"image\":\"\",\"excerpt\":\"Receive purchase orders via your WooCommerce-powered online store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gateway-purchase-order\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"573a92318244ece5facb449d63e74874\",\"slug\":\"woocommerce-gateway-purchase-order\",\"id\":478542},{\"title\":\"PayPal Payments Pro\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Paypal-Payments-Pro-Dark.png\",\"excerpt\":\"Take credit card payments directly on your checkout using PayPal Pro.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/paypal-pro\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"6d23ba7f0e0198937c0029f9e865b40e\",\"slug\":\"woocommerce-gateway-paypal-pro\",\"id\":18594},{\"title\":\"Returns and Warranty Requests\",\"image\":\"\",\"excerpt\":\"Manage the RMA process, add warranties to products &amp; let customers request &amp; manage returns \\/ exchanges from their account.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/warranty-requests\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"9b4c41102e6b61ea5f558e16f9b63e25\",\"slug\":\"woocommerce-warranty\",\"id\":228315},{\"title\":\"Gravity Forms Product Add-ons\",\"image\":\"\",\"excerpt\":\"Powerful product add-ons, Gravity style\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/gravity-forms-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/www.elementstark.com\\/woocommerce-extension-demos\\/product-category\\/gravity-forms\\/\",\"price\":\"&#36;99.00\",\"hash\":\"a6ac0ab1a1536e3a357ccf24c0650ed0\",\"slug\":\"woocommerce-gravityforms-product-addons\",\"id\":18633},{\"title\":\"Product Enquiry Form\",\"image\":\"\",\"excerpt\":\"Allow visitors to contact you directly from the product details page via a reCAPTCHA protected form to enquire about a product.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-enquiry-form\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"5a0f5d72519a8ffcc86669f042296937\",\"slug\":\"woocommerce-product-enquiry-form\",\"id\":18601},{\"title\":\"WooCommerce Box Office\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-BO-Dark.png\",\"excerpt\":\"Sell tickets for your next event, concert, function, fundraiser or conference directly on your own site\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-box-office\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"e704c9160de318216a8fa657404b9131\",\"slug\":\"woocommerce-box-office\",\"id\":1628717},{\"title\":\"Composite Products\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/07\\/Logo-CP.png?v=1\",\"excerpt\":\"Create product kit builders and custom product configurators using existing products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/composite-products\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"0343e0115bbcb97ccd98442b8326a0af\",\"slug\":\"woocommerce-composite-products\",\"id\":216836},{\"title\":\"WooCommerce Order Barcodes\",\"image\":\"\",\"excerpt\":\"Generates a unique barcode for each order on your site - perfect for e-tickets, packing slips, reservations and a variety of other uses.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-order-barcodes\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"889835bb29ee3400923653e1e44a3779\",\"slug\":\"woocommerce-order-barcodes\",\"id\":391708},{\"title\":\"WooCommerce 360\\u00ba Image\",\"image\":\"\",\"excerpt\":\"An easy way to add a dynamic, controllable 360\\u00ba image rotation to your WooCommerce site, by adding a group of images to a product\\u2019s gallery.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-360-image\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"24eb2cfa3738a66bf3b2587876668cd2\",\"slug\":\"woocommerce-360-image\",\"id\":512186},{\"title\":\"WooCommerce Photography\",\"image\":\"\",\"excerpt\":\"Sell photos in the blink of an eye using this simple as dragging &amp; dropping interface.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-photography\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"ee76e8b9daf1d97ca4d3874cc9e35687\",\"slug\":\"woocommerce-photography\",\"id\":583602},{\"title\":\"WooCommerce Bookings Availability\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Bookings-Aval-Dark.png\",\"excerpt\":\"Sell more bookings by presenting a calendar or schedule of available slots in a page or post.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/bookings-availability\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"30770d2a-e392-4e82-baaa-76cfc7d02ae3\",\"slug\":\"woocommerce-bookings-availability\",\"id\":4228225},{\"title\":\"Software Add-on\",\"image\":\"\",\"excerpt\":\"Sell License Keys for Software\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/software-add-on\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"79f6dbfe1f1d3a56a86f0509b6d6b04b\",\"slug\":\"woocommerce-software-add-on\",\"id\":18683},{\"title\":\"WooCommerce Products Compare\",\"image\":\"\",\"excerpt\":\"WooCommerce Products Compare will allow your potential customers to easily compare products within your store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-products-compare\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"c3ba0a4a3199a0cc7a6112eb24414548\",\"slug\":\"woocommerce-products-compare\",\"id\":853117},{\"title\":\"WooCommerce Store Catalog PDF Download\",\"image\":\"\",\"excerpt\":\"Offer your customers a PDF download of your product catalog, generated by WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-store-catalog-pdf-download\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"79ca7aadafe706364e2d738b7c1090c4\",\"slug\":\"woocommerce-store-catalog-pdf-download\",\"id\":675790},{\"title\":\"WooCommerce Paid Courses\",\"image\":\"\",\"excerpt\":\"Sell your online courses using the most popular eCommerce platform on the web \\u2013 WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-paid-courses\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"bad2a02a063555b7e2bee59924690763\",\"slug\":\"woothemes-sensei\",\"id\":152116},{\"title\":\"eWAY\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2011\\/10\\/eway-logo-3000-2000.jpg\",\"excerpt\":\"Take credit card payments securely via eWay (SG, MY, HK, AU, and NZ) keeping customers on your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/eway\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"2c497769d98d025e0d340cd0b5ea5da1\",\"slug\":\"woocommerce-gateway-eway\",\"id\":18604},{\"title\":\"PayPal\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2020\\/10\\/PPCP-Tile-PayPal-Logo-and-Cart-Art-2x-2-uozwz8.jpg\",\"excerpt\":\"PayPal\\u2019s latest, most complete payment processing solution. Accept PayPal exclusives, credit\\/debit cards and local payment methods. Turn on only PayPal options or process a full suite of payment methods. Enable global transactions with extensive currency and country coverage. Built and supported by WooCommerce and PayPal.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-paypal-payments\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"934115ab-e3f3-4435-9580-345b1ce21899\",\"slug\":\"woocommerce-paypal-payments\",\"id\":6410731},{\"title\":\"Catalog Visibility Options\",\"image\":\"\",\"excerpt\":\"Transform WooCommerce into an online catalog by removing eCommerce functionality\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/catalog-visibility-options\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"12e791110365fdbb5865c8658907967e\",\"slug\":\"woocommerce-catalog-visibility-options\",\"id\":18648},{\"title\":\"QuickBooks Sync for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2019\\/04\\/woocommerce-com-logo-1-hyhzbh.png\",\"excerpt\":\"Automatic two-way sync for orders, customers, products, inventory and more between WooCommerce and QuickBooks (Online, Desktop, or POS).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/quickbooks-sync-for-woocommerce\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"c5e32e20-7c1f-4585-8b15-d930c2d842ac\",\"slug\":\"myworks-woo-sync-for-quickbooks-online\",\"id\":4065824},{\"title\":\"WooCommerce Blocks\",\"image\":\"\",\"excerpt\":\"WooCommerce Blocks offers a range of Gutenberg blocks you can use to build and customise your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gutenberg-products-block\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"c2e9f13a-f90c-4ffe-a8a5-b432399ec263\",\"slug\":\"woo-gutenberg-products-block\",\"id\":3076677},{\"title\":\"Conditional Shipping and Payments\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/07\\/Logo-CSP.png?v=1\",\"excerpt\":\"Use conditional logic to restrict the shipping and payment options available on your store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/conditional-shipping-and-payments\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"1f56ff002fa830b77017b0107505211a\",\"slug\":\"woocommerce-conditional-shipping-and-payments\",\"id\":680253},{\"title\":\"Sequential Order Numbers Pro\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/05\\/Thumbnail-Sequential-Order-Numbers-Pro-updated.png\",\"excerpt\":\"Tame your order numbers! Advanced &amp; sequential order numbers with optional prefixes \\/ suffixes\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/sequential-order-numbers-pro\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"0b18a2816e016ba9988b93b1cd8fe766\",\"slug\":\"woocommerce-sequential-order-numbers-pro\",\"id\":18688},{\"title\":\"WooCommerce Order Status Manager\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2015\\/02\\/Thumbnail-Order-Status-Manager-updated.png\",\"excerpt\":\"Create, edit, and delete completely custom order statuses and integrate them seamlessly into your order management flow.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-order-status-manager\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"51fd9ab45394b4cad5a0ebf58d012342\",\"slug\":\"woocommerce-order-status-manager\",\"id\":588398},{\"title\":\"WooCommerce Checkout Add-Ons\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/07\\/Thumbnail-Checkout-Add-Ons-updated.png\",\"excerpt\":\"Highlight relevant products, offers like free shipping and other up-sells during checkout.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-checkout-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"8fdca00b4000b7a8cc26371d0e470a8f\",\"slug\":\"woocommerce-checkout-add-ons\",\"id\":466854},{\"title\":\"WooCommerce Google Analytics Pro\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2016\\/01\\/Thumbnail-GAPro-updated.png\",\"excerpt\":\"Add advanced event tracking and enhanced eCommerce tracking to your WooCommerce site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-google-analytics-pro\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"d8aed8b7306b509eec1589e59abe319f\",\"slug\":\"woocommerce-google-analytics-pro\",\"id\":1312497},{\"title\":\"WooCommerce One Page Checkout\",\"image\":\"\",\"excerpt\":\"Create special pages where customers can choose products, checkout &amp; pay all on the one page.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-one-page-checkout\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"c9ba8f8352cd71b5508af5161268619a\",\"slug\":\"woocommerce-one-page-checkout\",\"id\":527886},{\"title\":\"WooCommerce Product Search\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2014\\/10\\/woocommerce-product-search-product-image-1870x960-1-jvsljj.png\",\"excerpt\":\"The perfect search engine helps customers to find and buy products quickly \\u2013 essential for every WooCommerce store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-product-search\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/demo.itthinx.com\\/wps\\/\",\"price\":\"&#36;49.00\",\"hash\":\"c84cc8ca16ddac3408e6b6c5871133a8\",\"slug\":\"woocommerce-product-search\",\"id\":512174},{\"title\":\"Coupon Shortcodes\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2013\\/09\\/woocommerce-coupon-shortcodes-product-image-1870x960-1-vc5gux.png\",\"excerpt\":\"Show coupon discount info using shortcodes. Allows to render coupon information and content conditionally, based on the validity of coupons.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/coupon-shortcodes\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"ac5d9d51-70b2-4d8f-8b89-24200eea1394\",\"slug\":\"woocommerce-coupon-shortcodes\",\"id\":244762},{\"title\":\"First Data\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/02\\/Thumbnail-FirstData-updated.png\",\"excerpt\":\"FirstData gateway for WooCommerce\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/firstdata\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"eb3e32663ec0810592eaf0d097796230\",\"slug\":\"woocommerce-gateway-firstdata\",\"id\":18645},{\"title\":\"Jilt\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2017\\/12\\/Thumbnail-Jilt-updated.png\",\"excerpt\":\"All-in-one email marketing platform built for WooCommerce stores. Send newsletters, abandoned cart reminders, win-backs, welcome automations, and more.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/jilt\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"b53aafb64dca33835e41ee06de7e9816\",\"slug\":\"jilt-for-woocommerce\",\"id\":2754876},{\"title\":\"WooSlider\",\"image\":\"\",\"excerpt\":\"WooSlider is the ultimate responsive slideshow WordPress slider plugin\\r\\n\\r\\n\\u00a0\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/wooslider\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"http:\\/\\/www.wooslider.com\\/\",\"price\":\"&#36;49.00\",\"hash\":\"209d98f3ccde6cc3de7e8732a2b20b6a\",\"slug\":\"wooslider\",\"id\":46506},{\"title\":\"WooCommerce Social Login\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/08\\/Thumbnail-Social-Login-updated.png\",\"excerpt\":\"Enable Social Login for seamless checkout and account creation.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-social-login\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"http:\\/\\/demos.skyverge.com\\/woocommerce-social-login\\/\",\"price\":\"&#36;79.00\",\"hash\":\"b231cd6367a79cc8a53b7d992d77525d\",\"slug\":\"woocommerce-social-login\",\"id\":473617},{\"title\":\"WooCommerce Order Status Control\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/06\\/Thumbnail-Order-Status-Control-updated.png\",\"excerpt\":\"Use this extension to automatically change the order status to \\\"completed\\\" after successful payment.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-order-status-control\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"32400e509c7c36dcc1cd368e8267d981\",\"slug\":\"woocommerce-order-status-control\",\"id\":439037},{\"title\":\"Variation Swatches and Photos\",\"image\":\"\",\"excerpt\":\"Show color and image swatches instead of dropdowns for variable products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/variation-swatches-and-photos\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/www.elementstark.com\\/woocommerce-extension-demos\\/product-category\\/swatches-and-photos\\/\",\"price\":\"&#36;99.00\",\"hash\":\"37bea8d549df279c8278878d081b062f\",\"slug\":\"woocommerce-variation-swatches-and-photos\",\"id\":18697},{\"title\":\"Opayo Payment Suite\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2011\\/10\\/Opayo_logo_RGB.png\",\"excerpt\":\"Take payments on your WooCommerce store via Opayo (formally SagePay).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/sage-pay-form\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"6bc0cca47d0274d8ef9b164f6fbec1cc\",\"slug\":\"woocommerce-gateway-sagepay-form\",\"id\":18599},{\"title\":\"EU VAT Number\",\"image\":\"\",\"excerpt\":\"Collect VAT numbers at checkout and remove the VAT charge for eligible EU businesses.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/eu-vat-number\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"d2720c4b4bb8d6908e530355b7a2d734\",\"slug\":\"woocommerce-eu-vat-number\",\"id\":18592},{\"title\":\"Customer\\/Order\\/Coupon CSV Import Suite\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/07\\/Thumbnail-Customer-Order-Coupon-CSV-Import-Suite-updated.png\",\"excerpt\":\"Import both customers and orders into WooCommerce from a CSV file.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/customerorder-csv-import-suite\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"eb00ca8317a0f64dbe185c995e5ea3df\",\"slug\":\"woocommerce-customer-order-csv-import\",\"id\":18709}]}\";s:3:\"raw\";s:48957:\"HTTP/1.1 200 OK\r\nServer: nginx\r\nDate: Tue, 29 Jun 2021 11:58:01 GMT\r\nContent-Type: application/json; charset=UTF-8\r\nContent-Length: 11617\r\nConnection: close\r\nX-Robots-Tag: noindex\r\nLink: <https://woocommerce.com/wp-json/>; rel=\"https://api.w.org/\"\r\nX-Content-Type-Options: nosniff\r\nAccess-Control-Expose-Headers: X-WP-Total, X-WP-TotalPages, Link\r\nAccess-Control-Allow-Headers: Authorization, X-WP-Nonce, Content-Disposition, Content-MD5, Content-Type\r\nX-WCCOM-Cache: HIT\r\nCache-Control: max-age=60\r\nAllow: GET\r\nContent-Encoding: gzip\r\nX-rq: hhn1 91 142 3184\r\nAge: 30\r\nX-Cache: hit\r\nVary: Accept-Encoding, Origin\r\nAccept-Ranges: bytes\r\n\r\n{\"products\":[{\"title\":\"WooCommerce Google Analytics\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/GA-Dark.png\",\"excerpt\":\"Understand your customers and increase revenue with world\\u2019s leading analytics platform - integrated with WooCommerce for free.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-google-analytics\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"2d21f7de14dfb8e9885a4622be701ddf\",\"slug\":\"woocommerce-google-analytics-integration\",\"id\":1442927},{\"title\":\"WooCommerce Tax\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Tax-Dark.png\",\"excerpt\":\"Automatically calculate how much sales tax should be collected for WooCommerce orders - by city, country, or state - at checkout.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/tax\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"f31b3b9273cce188cc2b27f7849d02dd\",\"slug\":\"woocommerce-services\",\"id\":3220291},{\"title\":\"Stripe\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Stripe-Dark-1.png\",\"excerpt\":\"Accept all major debit and credit cards as well as local payment methods with Stripe.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/stripe\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"50bb7a985c691bb943a9da4d2c8b5efd\",\"slug\":\"woocommerce-gateway-stripe\",\"id\":18627},{\"title\":\"Jetpack\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Jetpack-Dark.png\",\"excerpt\":\"Power up and protect your store with Jetpack\\r\\n\\r\\nFor free security, insights and monitoring, connect to Jetpack. It\'s everything you need for a strong, secure start.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/jetpack\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"d5bfef9700b62b2b132c74c74c3193eb\",\"slug\":\"jetpack\",\"id\":2725249},{\"title\":\"Facebook for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Facebook-Dark.png\",\"excerpt\":\"Get the Official Facebook for WooCommerce plugin for three powerful ways to help grow your business.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/facebook\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"0ea4fe4c2d7ca6338f8a322fb3e4e187\",\"slug\":\"facebook-for-woocommerce\",\"id\":2127297},{\"title\":\"Amazon Pay\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Amazon-Pay-Dark.png\",\"excerpt\":\"Amazon Pay is embedded in your WooCommerce store. Transactions take place via\\u00a0Amazon widgets, so the buyer never leaves your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/pay-with-amazon\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"9865e043bbbe4f8c9735af31cb509b53\",\"slug\":\"woocommerce-gateway-amazon-payments-advanced\",\"id\":238816},{\"title\":\"Square for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Square-Dark.png\",\"excerpt\":\"Accepting payments is easy with Square. Clear rates, fast deposits (1-2 business days). Sell online and in person, and sync all payments, items and inventory.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/square\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"e907be8b86d7df0c8f8e0d0020b52638\",\"slug\":\"woocommerce-square\",\"id\":1770503},{\"title\":\"WooCommerce Shipping\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Ship-Dark-1.png\",\"excerpt\":\"Print USPS and DHL labels right from your WooCommerce dashboard and instantly save up to 90%. WooCommerce Shipping is free to use and saves you time and money.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipping\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"f31b3b9273cce188cc2b27f7849d02dd\",\"slug\":\"woocommerce-services\",\"id\":2165910},{\"title\":\"WooCommerce Payments\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Pay-Dark.png\",\"excerpt\":\"Securely accept payments, track cash flow, and manage recurring revenue from your dashboard \\u2014 all without setup costs or monthly fees.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-payments\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"8c6319ca-8f41-4e69-be63-6b15ee37773b\",\"slug\":\"woocommerce-payments\",\"id\":5278104},{\"title\":\"Mailchimp for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/09\\/logo-mailchimp-dark-v2.png\",\"excerpt\":\"Increase traffic, drive repeat purchases, and personalize your marketing when you connect to Mailchimp.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/mailchimp-for-woocommerce\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"b4481616ebece8b1ff68fc59b90c1a91\",\"slug\":\"mailchimp-for-woocommerce\",\"id\":2545166},{\"title\":\"WooCommerce Subscriptions\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Subscriptions-Dark.png\",\"excerpt\":\"Let customers subscribe to your products or services and pay on a weekly, monthly or annual basis.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-subscriptions\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;199.00\",\"hash\":\"6115e6d7e297b623a169fdcf5728b224\",\"slug\":\"woocommerce-subscriptions\",\"id\":27147},{\"title\":\"PayPal Checkout\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Paypal-Dark.png\",\"excerpt\":\"PayPal Checkout now with Smart Payment Buttons\\u2122, dynamically displays, PayPal, Venmo, PayPal Credit, or other local payment options in a single stack giving customers the choice to pay with their preferred option.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gateway-paypal-checkout\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"69e6cba62ac4021df9e117cc3f716d07\",\"slug\":\"woocommerce-gateway-paypal-express-checkout\",\"id\":1597922},{\"title\":\"ShipStation Integration\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Shipstation-Dark.png\",\"excerpt\":\"Fulfill all your Woo orders (and wherever else you sell) quickly and easily using ShipStation. Try it free for 30 days today!\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipstation-integration\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"9de8640767ba64237808ed7f245a49bb\",\"slug\":\"woocommerce-shipstation-integration\",\"id\":18734},{\"title\":\"Product Add-Ons\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Product-Add-Ons-Dark.png\",\"excerpt\":\"Offer add-ons like gift wrapping, special messages or other special options for your products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"147d0077e591e16db9d0d67daeb8c484\",\"slug\":\"woocommerce-product-addons\",\"id\":18618},{\"title\":\"PayFast Payment Gateway\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Payfast-Dark-1.png\",\"excerpt\":\"Take payments on your WooCommerce store via PayFast (redirect method).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/payfast-payment-gateway\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"557bf07293ad916f20c207c6c9cd15ff\",\"slug\":\"woocommerce-payfast-gateway\",\"id\":18596},{\"title\":\"Google Ads &amp; Marketing by Kliken\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2019\\/02\\/GA-for-Woo-Logo-374x192px-qu3duk.png\",\"excerpt\":\"Get in front of shoppers and drive traffic to your store so you can grow your business with Smart Shopping Campaigns and free listings.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/google-ads-and-marketing\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"bf66e173-a220-4da7-9512-b5728c20fc16\",\"slug\":\"kliken-marketing-for-google\",\"id\":3866145},{\"title\":\"USPS Shipping Method\",\"image\":\"\",\"excerpt\":\"Get shipping rates from the USPS API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/usps-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"83d1524e8f5f1913e58889f83d442c32\",\"slug\":\"woocommerce-shipping-usps\",\"id\":18657},{\"title\":\"UPS Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/UPS-Shipping-Method-Dark.png\",\"excerpt\":\"Get shipping rates from the UPS API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/ups-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"8dae58502913bac0fbcdcaba515ea998\",\"slug\":\"woocommerce-shipping-ups\",\"id\":18665},{\"title\":\"Shipment Tracking\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Ship-Tracking-Dark-1.png\",\"excerpt\":\"Add shipment tracking information to your orders.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipment-tracking\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"1968e199038a8a001c9f9966fd06bf88\",\"slug\":\"woocommerce-shipment-tracking\",\"id\":18693},{\"title\":\"Table Rate Shipping\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Product-Table-Rate-Shipping-Dark.png\",\"excerpt\":\"Advanced, flexible shipping. Define multiple shipping rates based on location, price, weight, shipping class or item count.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/table-rate-shipping\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"3034ed8aff427b0f635fe4c86bbf008a\",\"slug\":\"woocommerce-table-rate-shipping\",\"id\":18718},{\"title\":\"Checkout Field Editor\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Checkout-Field-Editor-Dark.png\",\"excerpt\":\"Optimize your checkout process by adding, removing or editing fields to suit your needs.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-checkout-field-editor\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"2b8029f0d7cdd1118f4d843eb3ab43ff\",\"slug\":\"woocommerce-checkout-field-editor\",\"id\":184594},{\"title\":\"Braintree for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2016\\/02\\/braintree-black-copy.png\",\"excerpt\":\"Accept PayPal, credit cards and debit cards with a single payment gateway solution \\u2014 PayPal Powered by Braintree.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gateway-paypal-powered-by-braintree\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"27f010c8e34ca65b205ddec88ad14536\",\"slug\":\"woocommerce-gateway-paypal-powered-by-braintree\",\"id\":1489837},{\"title\":\"WooCommerce Bookings\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Bookings-Dark.png\",\"excerpt\":\"Allow customers to book appointments, make reservations or rent equipment without leaving your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-bookings\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/themes.woocommerce.com\\/hotel\\/\",\"price\":\"&#36;249.00\",\"hash\":\"911c438934af094c2b38d5560b9f50f3\",\"slug\":\"WooCommerce Bookings\",\"id\":390890},{\"title\":\"WooCommerce Memberships\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2015\\/06\\/Thumbnail-Memberships-updated.png\",\"excerpt\":\"Give members access to restricted content or products, for a fee or for free.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-memberships\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;199.00\",\"hash\":\"9288e7609ad0b487b81ef6232efa5cfc\",\"slug\":\"woocommerce-memberships\",\"id\":958589},{\"title\":\"Product Bundles\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/07\\/Logo-PB.png?v=1\",\"excerpt\":\"Offer personalized product bundles, bulk discount packages, and assembled\\u00a0products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-bundles\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"aa2518b5-ab19-4b75-bde9-60ca51e20f28\",\"slug\":\"woocommerce-product-bundles\",\"id\":18716},{\"title\":\"Multichannel for WooCommerce: Google, Amazon, eBay &amp; Walmart Integration\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2018\\/10\\/Woo-Extension-Store-Logo-v2.png\",\"excerpt\":\"Get the official Google, Amazon, eBay and Walmart extension and create, sync and manage multichannel listings directly from WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/amazon-ebay-integration\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"e4000666-9275-4c71-8619-be61fb41c9f9\",\"slug\":\"woocommerce-amazon-ebay-integration\",\"id\":3545890},{\"title\":\"Min\\/Max Quantities\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Min-Max-Qua-Dark.png\",\"excerpt\":\"Specify minimum and maximum allowed product quantities for orders to be completed.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/minmax-quantities\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"2b5188d90baecfb781a5aa2d6abb900a\",\"slug\":\"woocommerce-min-max-quantities\",\"id\":18616},{\"title\":\"FedEx Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2013\\/01\\/FedEx_Logo_Wallpaper.jpeg\",\"excerpt\":\"Get shipping rates from the FedEx API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/fedex-shipping-module\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"1a48b598b47a81559baadef15e320f64\",\"slug\":\"woocommerce-shipping-fedex\",\"id\":18620},{\"title\":\"LiveChat for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2015\\/11\\/LC_woo_regular-zmiaym.png\",\"excerpt\":\"Live Chat and messaging platform for sales and support -- increase average order value and overall sales through live conversations.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/livechat\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/www.livechat.com\\/livechat-for-ecommerce\\/?a=woocommerce&amp;utm_source=woocommerce.com&amp;utm_medium=integration&amp;utm_campaign=woocommerce.com\",\"price\":\"&#36;0.00\",\"hash\":\"5344cc1f-ed4a-4d00-beff-9d67f6d372f3\",\"slug\":\"livechat-woocommerce\",\"id\":1348888},{\"title\":\"Product CSV Import Suite\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Product-CSV-Import-Dark.png\",\"excerpt\":\"Import, merge, and export products and variations to and from WooCommerce using a CSV file.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-csv-import-suite\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"7ac9b00a1fe980fb61d28ab54d167d0d\",\"slug\":\"woocommerce-product-csv-import-suite\",\"id\":18680},{\"title\":\"Follow-Ups\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Follow-Ups-Dark.png\",\"excerpt\":\"Automatically contact customers after purchase - be it everyone, your most loyal or your biggest spenders - and keep your store top-of-mind.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/follow-up-emails\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"05ece68fe94558e65278fe54d9ec84d2\",\"slug\":\"woocommerce-follow-up-emails\",\"id\":18686},{\"title\":\"Authorize.Net\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2013\\/04\\/Thumbnail-Authorize.net-updated.png\",\"excerpt\":\"Authorize.Net gateway with support for pre-orders and subscriptions.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/authorize-net\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"8b61524fe53add7fdd1a8d1b00b9327d\",\"slug\":\"woocommerce-gateway-authorize-net-cim\",\"id\":178481},{\"title\":\"Australia Post Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/09\\/australia-post.gif\",\"excerpt\":\"Get shipping rates for your WooCommerce store from the Australia Post API, which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/australia-post-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"1dbd4dc6bd91a9cda1bd6b9e7a5e4f43\",\"slug\":\"woocommerce-shipping-australia-post\",\"id\":18622},{\"title\":\"Canada Post Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/09\\/canada-post.png\",\"excerpt\":\"Get shipping rates from the Canada Post Ratings API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/canada-post-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"ac029cdf3daba20b20c7b9be7dc00e0e\",\"slug\":\"woocommerce-shipping-canada-post\",\"id\":18623},{\"title\":\"WooCommerce Customer \\/ Order \\/ Coupon Export\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/02\\/Thumbnail-Customer-Order-Coupon-Export-updated.png\",\"excerpt\":\"Export customers, orders, and coupons from WooCommerce manually or on an automated schedule.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/ordercustomer-csv-export\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"914de15813a903c767b55445608bf290\",\"slug\":\"woocommerce-customer-order-csv-export\",\"id\":18652},{\"title\":\"Product Vendors\",\"image\":\"\",\"excerpt\":\"Turn your store into a multi-vendor marketplace\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-vendors\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"a97d99fccd651bbdd728f4d67d492c31\",\"slug\":\"woocommerce-product-vendors\",\"id\":219982},{\"title\":\"WooCommerce Accommodation Bookings\",\"image\":\"\",\"excerpt\":\"Book accommodation using WooCommerce and the WooCommerce Bookings extension.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-accommodation-bookings\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"99b2a7a4af90b6cefd2a733b3b1f78e7\",\"slug\":\"woocommerce-accommodation-bookings\",\"id\":1412069},{\"title\":\"Royal Mail\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2013\\/04\\/royalmail.png\",\"excerpt\":\"Offer Royal Mail shipping rates to your customers\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/royal-mail\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"03839cca1a16c4488fcb669aeb91a056\",\"slug\":\"woocommerce-shipping-royalmail\",\"id\":182719},{\"title\":\"WooCommerce Brands\",\"image\":\"\",\"excerpt\":\"Create, assign and list brands for products, and allow customers to view by brand.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/brands\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"8a88c7cbd2f1e73636c331c7a86f818c\",\"slug\":\"woocommerce-brands\",\"id\":18737},{\"title\":\"Xero\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2012\\/08\\/xero2.png\",\"excerpt\":\"Save time with automated sync between WooCommerce and your Xero account.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/xero\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"f0dd29d338d3c67cf6cee88eddf6869b\",\"slug\":\"woocommerce-xero\",\"id\":18733},{\"title\":\"Smart Coupons\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/10\\/wc-product-smart-coupons.png\",\"excerpt\":\"Everything you need for discounts, coupons, credits, gift cards, product giveaways, offers, and promotions. Most popular and complete coupons plugin for WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/smart-coupons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"http:\\/\\/demo.storeapps.org\\/?demo=sc\",\"price\":\"&#36;99.00\",\"hash\":\"05c45f2aa466106a466de4402fff9dde\",\"slug\":\"woocommerce-smart-coupons\",\"id\":18729},{\"title\":\"AutomateWoo\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-AutomateWoo-Dark-1.png\",\"excerpt\":\"Powerful marketing automation for WooCommerce. AutomateWoo has the tools you need to grow your store and make more money.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/automatewoo\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"ba9299b8-1dba-4aa0-a313-28bc1755cb88\",\"slug\":\"automatewoo\",\"id\":4652610},{\"title\":\"Advanced Notifications\",\"image\":\"\",\"excerpt\":\"Easily setup \\\"new order\\\" and stock email notifications for multiple recipients of your choosing.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/advanced-notifications\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"112372c44b002fea2640bd6bfafbca27\",\"slug\":\"woocommerce-advanced-notifications\",\"id\":18740},{\"title\":\"WooCommerce Points and Rewards\",\"image\":\"\",\"excerpt\":\"Reward your customers for purchases and other actions with points which can be redeemed for discounts.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-points-and-rewards\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"1649b6cca5da8b923b01ca56b5cdd246\",\"slug\":\"woocommerce-points-and-rewards\",\"id\":210259},{\"title\":\"WooCommerce Zapier\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/woocommerce-zapier-logo.png\",\"excerpt\":\"Integrate with 3000+ cloud apps and services today.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-zapier\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;59.00\",\"hash\":\"0782bdbe932c00f4978850268c6cfe40\",\"slug\":\"woocommerce-zapier\",\"id\":243589},{\"title\":\"Dynamic Pricing\",\"image\":\"\",\"excerpt\":\"Bulk discounts, role-based pricing and much more\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/dynamic-pricing\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"9a41775bb33843f52c93c922b0053986\",\"slug\":\"woocommerce-dynamic-pricing\",\"id\":18643},{\"title\":\"WooCommerce Pre-Orders\",\"image\":\"\",\"excerpt\":\"Allow customers to order products before they are available.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-pre-orders\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"b2dc75e7d55e6f5bbfaccb59830f66b7\",\"slug\":\"woocommerce-pre-orders\",\"id\":178477},{\"title\":\"WooCommerce Subscription Downloads\",\"image\":\"\",\"excerpt\":\"Offer additional downloads to your subscribers, via downloadable products listed in your store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-subscription-downloads\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"5be9e21c13953253e4406d2a700382ec\",\"slug\":\"woocommerce-subscription-downloads\",\"id\":420458},{\"title\":\"Name Your Price\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2012\\/09\\/nyp-icon-dark-v83owf.png\",\"excerpt\":\"Allow customers to define the product price. Also useful for accepting user-set donations.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/name-your-price\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"31b4e11696cd99a3c0572975a84f1c08\",\"slug\":\"woocommerce-name-your-price\",\"id\":18738},{\"title\":\"WooCommerce Additional Variation Images\",\"image\":\"\",\"excerpt\":\"Add gallery images per variation on variable products within WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-additional-variation-images\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/themes.woocommerce.com\\/storefront\\/product\\/woo-single-1\\/\",\"price\":\"&#36;49.00\",\"hash\":\"c61dd6de57dcecb32bd7358866de4539\",\"slug\":\"woocommerce-additional-variation-images\",\"id\":477384},{\"title\":\"WooCommerce Print Invoices &amp; Packing lists\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/03\\/Thumbnail-Print-Invoices-Packing-lists-updated.png\",\"excerpt\":\"Generate invoices, packing slips, and pick lists for your WooCommerce orders.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/print-invoices-packing-lists\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"465de1126817cdfb42d97ebca7eea717\",\"slug\":\"woocommerce-pip\",\"id\":18666},{\"title\":\"WooCommerce Deposits\",\"image\":\"\",\"excerpt\":\"Enable customers to pay for products using a deposit or a payment plan.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-deposits\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;179.00\",\"hash\":\"de192a6cf12c4fd803248da5db700762\",\"slug\":\"woocommerce-deposits\",\"id\":977087},{\"title\":\"Amazon S3 Storage\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/09\\/amazon.png\",\"excerpt\":\"Serve digital products via Amazon S3\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/amazon-s3-storage\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"473bf6f221b865eff165c97881b473bb\",\"slug\":\"woocommerce-amazon-s3-storage\",\"id\":18663},{\"title\":\"Cart Add-ons\",\"image\":\"\",\"excerpt\":\"A powerful tool for driving incremental and impulse purchases by customers once they are in the shopping cart\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/cart-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"3a8ef25334396206f5da4cf208adeda3\",\"slug\":\"woocommerce-cart-add-ons\",\"id\":18717},{\"title\":\"Google Product Feed\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2011\\/11\\/logo-regular-lscryp.png\",\"excerpt\":\"Feed product data to Google Merchant Center for setting up Google product listings &amp; product ads.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/google-product-feed\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"d55b4f852872025741312839f142447e\",\"slug\":\"woocommerce-product-feeds\",\"id\":18619},{\"title\":\"Shipping Multiple Addresses\",\"image\":\"\",\"excerpt\":\"Allow your customers to ship individual items in a single order to multiple addresses.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipping-multiple-addresses\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"aa0eb6f777846d329952d5b891d6f8cc\",\"slug\":\"woocommerce-shipping-multiple-addresses\",\"id\":18741},{\"title\":\"WooCommerce AvaTax\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2016\\/01\\/Thumbnail-Avalara-updated.png\",\"excerpt\":\"Get 100% accurate sales tax calculations and on time tax return filing. No more tracking sales tax rates, rules, or jurisdictional boundaries.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-avatax\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"57077a4b28ba71cacf692bcf4a1a7f60\",\"slug\":\"woocommerce-avatax\",\"id\":1389326},{\"title\":\"Klarna Checkout\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2018\\/01\\/Partner_marketing_Klarna_Checkout_Black-1.png\",\"excerpt\":\"Klarna Checkout is a full checkout experience embedded on your site that includes all popular payment methods (Pay Now, Pay Later, Financing, Installments).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/klarna-checkout\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/demo.krokedil.se\\/klarnacheckout\\/\",\"price\":\"&#36;0.00\",\"hash\":\"90f8ce584e785fcd8c2d739fd4f40d78\",\"slug\":\"klarna-checkout-for-woocommerce\",\"id\":2754152},{\"title\":\"TaxJar\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/10\\/taxjar-logotype.png\",\"excerpt\":\"Save hours every month by putting your sales tax on autopilot. Automated, multi-state sales tax calculation, reporting, and filing for your WooCommerce store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/taxjar\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"12072d8e-e933-4561-97b1-9db3c7eeed91\",\"slug\":\"taxjar-simplified-taxes-for-woocommerce\",\"id\":514914},{\"title\":\"Bulk Stock Management\",\"image\":\"\",\"excerpt\":\"Edit product and variation stock levels in bulk via this handy interface\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/bulk-stock-management\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"02f4328d52f324ebe06a78eaaae7934f\",\"slug\":\"woocommerce-bulk-stock-management\",\"id\":18670},{\"title\":\"WooCommerce Email Customizer\",\"image\":\"\",\"excerpt\":\"Connect with your customers with each email you send by visually modifying your email templates via the WordPress Customizer.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-email-customizer\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"bd909fa97874d431f203b5336c7e8873\",\"slug\":\"woocommerce-email-customizer\",\"id\":853277},{\"title\":\"Force Sells\",\"image\":\"\",\"excerpt\":\"Force products to be added to the cart\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/force-sells\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"3ebddfc491ca168a4ea4800b893302b0\",\"slug\":\"woocommerce-force-sells\",\"id\":18678},{\"title\":\"WooCommerce Quick View\",\"image\":\"\",\"excerpt\":\"Show a quick-view button to view product details and add to cart via lightbox popup\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-quick-view\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"619c6e57ce72c49c4b57e15b06eddb65\",\"slug\":\"woocommerce-quick-view\",\"id\":187509},{\"title\":\"WooCommerce Purchase Order Gateway\",\"image\":\"\",\"excerpt\":\"Receive purchase orders via your WooCommerce-powered online store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gateway-purchase-order\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"573a92318244ece5facb449d63e74874\",\"slug\":\"woocommerce-gateway-purchase-order\",\"id\":478542},{\"title\":\"PayPal Payments Pro\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Paypal-Payments-Pro-Dark.png\",\"excerpt\":\"Take credit card payments directly on your checkout using PayPal Pro.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/paypal-pro\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"6d23ba7f0e0198937c0029f9e865b40e\",\"slug\":\"woocommerce-gateway-paypal-pro\",\"id\":18594},{\"title\":\"Returns and Warranty Requests\",\"image\":\"\",\"excerpt\":\"Manage the RMA process, add warranties to products &amp; let customers request &amp; manage returns \\/ exchanges from their account.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/warranty-requests\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"9b4c41102e6b61ea5f558e16f9b63e25\",\"slug\":\"woocommerce-warranty\",\"id\":228315},{\"title\":\"Gravity Forms Product Add-ons\",\"image\":\"\",\"excerpt\":\"Powerful product add-ons, Gravity style\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/gravity-forms-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/www.elementstark.com\\/woocommerce-extension-demos\\/product-category\\/gravity-forms\\/\",\"price\":\"&#36;99.00\",\"hash\":\"a6ac0ab1a1536e3a357ccf24c0650ed0\",\"slug\":\"woocommerce-gravityforms-product-addons\",\"id\":18633},{\"title\":\"Product Enquiry Form\",\"image\":\"\",\"excerpt\":\"Allow visitors to contact you directly from the product details page via a reCAPTCHA protected form to enquire about a product.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-enquiry-form\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"5a0f5d72519a8ffcc86669f042296937\",\"slug\":\"woocommerce-product-enquiry-form\",\"id\":18601},{\"title\":\"WooCommerce Box Office\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-BO-Dark.png\",\"excerpt\":\"Sell tickets for your next event, concert, function, fundraiser or conference directly on your own site\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-box-office\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"e704c9160de318216a8fa657404b9131\",\"slug\":\"woocommerce-box-office\",\"id\":1628717},{\"title\":\"Composite Products\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/07\\/Logo-CP.png?v=1\",\"excerpt\":\"Create product kit builders and custom product configurators using existing products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/composite-products\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"0343e0115bbcb97ccd98442b8326a0af\",\"slug\":\"woocommerce-composite-products\",\"id\":216836},{\"title\":\"WooCommerce Order Barcodes\",\"image\":\"\",\"excerpt\":\"Generates a unique barcode for each order on your site - perfect for e-tickets, packing slips, reservations and a variety of other uses.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-order-barcodes\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"889835bb29ee3400923653e1e44a3779\",\"slug\":\"woocommerce-order-barcodes\",\"id\":391708},{\"title\":\"WooCommerce 360\\u00ba Image\",\"image\":\"\",\"excerpt\":\"An easy way to add a dynamic, controllable 360\\u00ba image rotation to your WooCommerce site, by adding a group of images to a product\\u2019s gallery.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-360-image\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"24eb2cfa3738a66bf3b2587876668cd2\",\"slug\":\"woocommerce-360-image\",\"id\":512186},{\"title\":\"WooCommerce Photography\",\"image\":\"\",\"excerpt\":\"Sell photos in the blink of an eye using this simple as dragging &amp; dropping interface.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-photography\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"ee76e8b9daf1d97ca4d3874cc9e35687\",\"slug\":\"woocommerce-photography\",\"id\":583602},{\"title\":\"WooCommerce Bookings Availability\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Bookings-Aval-Dark.png\",\"excerpt\":\"Sell more bookings by presenting a calendar or schedule of available slots in a page or post.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/bookings-availability\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"30770d2a-e392-4e82-baaa-76cfc7d02ae3\",\"slug\":\"woocommerce-bookings-availability\",\"id\":4228225},{\"title\":\"Software Add-on\",\"image\":\"\",\"excerpt\":\"Sell License Keys for Software\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/software-add-on\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"79f6dbfe1f1d3a56a86f0509b6d6b04b\",\"slug\":\"woocommerce-software-add-on\",\"id\":18683},{\"title\":\"WooCommerce Products Compare\",\"image\":\"\",\"excerpt\":\"WooCommerce Products Compare will allow your potential customers to easily compare products within your store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-products-compare\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"c3ba0a4a3199a0cc7a6112eb24414548\",\"slug\":\"woocommerce-products-compare\",\"id\":853117},{\"title\":\"WooCommerce Store Catalog PDF Download\",\"image\":\"\",\"excerpt\":\"Offer your customers a PDF download of your product catalog, generated by WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-store-catalog-pdf-download\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"79ca7aadafe706364e2d738b7c1090c4\",\"slug\":\"woocommerce-store-catalog-pdf-download\",\"id\":675790},{\"title\":\"WooCommerce Paid Courses\",\"image\":\"\",\"excerpt\":\"Sell your online courses using the most popular eCommerce platform on the web \\u2013 WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-paid-courses\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"bad2a02a063555b7e2bee59924690763\",\"slug\":\"woothemes-sensei\",\"id\":152116},{\"title\":\"eWAY\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2011\\/10\\/eway-logo-3000-2000.jpg\",\"excerpt\":\"Take credit card payments securely via eWay (SG, MY, HK, AU, and NZ) keeping customers on your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/eway\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"2c497769d98d025e0d340cd0b5ea5da1\",\"slug\":\"woocommerce-gateway-eway\",\"id\":18604},{\"title\":\"PayPal\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2020\\/10\\/PPCP-Tile-PayPal-Logo-and-Cart-Art-2x-2-uozwz8.jpg\",\"excerpt\":\"PayPal\\u2019s latest, most complete payment processing solution. Accept PayPal exclusives, credit\\/debit cards and local payment methods. Turn on only PayPal options or process a full suite of payment methods. Enable global transactions with extensive currency and country coverage. Built and supported by WooCommerce and PayPal.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-paypal-payments\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"934115ab-e3f3-4435-9580-345b1ce21899\",\"slug\":\"woocommerce-paypal-payments\",\"id\":6410731},{\"title\":\"Catalog Visibility Options\",\"image\":\"\",\"excerpt\":\"Transform WooCommerce into an online catalog by removing eCommerce functionality\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/catalog-visibility-options\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"12e791110365fdbb5865c8658907967e\",\"slug\":\"woocommerce-catalog-visibility-options\",\"id\":18648},{\"title\":\"QuickBooks Sync for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2019\\/04\\/woocommerce-com-logo-1-hyhzbh.png\",\"excerpt\":\"Automatic two-way sync for orders, customers, products, inventory and more between WooCommerce and QuickBooks (Online, Desktop, or POS).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/quickbooks-sync-for-woocommerce\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"c5e32e20-7c1f-4585-8b15-d930c2d842ac\",\"slug\":\"myworks-woo-sync-for-quickbooks-online\",\"id\":4065824},{\"title\":\"WooCommerce Blocks\",\"image\":\"\",\"excerpt\":\"WooCommerce Blocks offers a range of Gutenberg blocks you can use to build and customise your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gutenberg-products-block\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"c2e9f13a-f90c-4ffe-a8a5-b432399ec263\",\"slug\":\"woo-gutenberg-products-block\",\"id\":3076677},{\"title\":\"Conditional Shipping and Payments\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/07\\/Logo-CSP.png?v=1\",\"excerpt\":\"Use conditional logic to restrict the shipping and payment options available on your store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/conditional-shipping-and-payments\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"1f56ff002fa830b77017b0107505211a\",\"slug\":\"woocommerce-conditional-shipping-and-payments\",\"id\":680253},{\"title\":\"Sequential Order Numbers Pro\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/05\\/Thumbnail-Sequential-Order-Numbers-Pro-updated.png\",\"excerpt\":\"Tame your order numbers! Advanced &amp; sequential order numbers with optional prefixes \\/ suffixes\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/sequential-order-numbers-pro\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"0b18a2816e016ba9988b93b1cd8fe766\",\"slug\":\"woocommerce-sequential-order-numbers-pro\",\"id\":18688},{\"title\":\"WooCommerce Order Status Manager\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2015\\/02\\/Thumbnail-Order-Status-Manager-updated.png\",\"excerpt\":\"Create, edit, and delete completely custom order statuses and integrate them seamlessly into your order management flow.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-order-status-manager\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"51fd9ab45394b4cad5a0ebf58d012342\",\"slug\":\"woocommerce-order-status-manager\",\"id\":588398},{\"title\":\"WooCommerce Checkout Add-Ons\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/07\\/Thumbnail-Checkout-Add-Ons-updated.png\",\"excerpt\":\"Highlight relevant products, offers like free shipping and other up-sells during checkout.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-checkout-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"8fdca00b4000b7a8cc26371d0e470a8f\",\"slug\":\"woocommerce-checkout-add-ons\",\"id\":466854},{\"title\":\"WooCommerce Google Analytics Pro\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2016\\/01\\/Thumbnail-GAPro-updated.png\",\"excerpt\":\"Add advanced event tracking and enhanced eCommerce tracking to your WooCommerce site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-google-analytics-pro\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"d8aed8b7306b509eec1589e59abe319f\",\"slug\":\"woocommerce-google-analytics-pro\",\"id\":1312497},{\"title\":\"WooCommerce One Page Checkout\",\"image\":\"\",\"excerpt\":\"Create special pages where customers can choose products, checkout &amp; pay all on the one page.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-one-page-checkout\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"c9ba8f8352cd71b5508af5161268619a\",\"slug\":\"woocommerce-one-page-checkout\",\"id\":527886},{\"title\":\"WooCommerce Product Search\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2014\\/10\\/woocommerce-product-search-product-image-1870x960-1-jvsljj.png\",\"excerpt\":\"The perfect search engine helps customers to find and buy products quickly \\u2013 essential for every WooCommerce store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-product-search\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/demo.itthinx.com\\/wps\\/\",\"price\":\"&#36;49.00\",\"hash\":\"c84cc8ca16ddac3408e6b6c5871133a8\",\"slug\":\"woocommerce-product-search\",\"id\":512174},{\"title\":\"Coupon Shortcodes\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2013\\/09\\/woocommerce-coupon-shortcodes-product-image-1870x960-1-vc5gux.png\",\"excerpt\":\"Show coupon discount info using shortcodes. Allows to render coupon information and content conditionally, based on the validity of coupons.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/coupon-shortcodes\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"ac5d9d51-70b2-4d8f-8b89-24200eea1394\",\"slug\":\"woocommerce-coupon-shortcodes\",\"id\":244762},{\"title\":\"First Data\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/02\\/Thumbnail-FirstData-updated.png\",\"excerpt\":\"FirstData gateway for WooCommerce\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/firstdata\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"eb3e32663ec0810592eaf0d097796230\",\"slug\":\"woocommerce-gateway-firstdata\",\"id\":18645},{\"title\":\"Jilt\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2017\\/12\\/Thumbnail-Jilt-updated.png\",\"excerpt\":\"All-in-one email marketing platform built for WooCommerce stores. Send newsletters, abandoned cart reminders, win-backs, welcome automations, and more.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/jilt\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"b53aafb64dca33835e41ee06de7e9816\",\"slug\":\"jilt-for-woocommerce\",\"id\":2754876},{\"title\":\"WooSlider\",\"image\":\"\",\"excerpt\":\"WooSlider is the ultimate responsive slideshow WordPress slider plugin\\r\\n\\r\\n\\u00a0\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/wooslider\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"http:\\/\\/www.wooslider.com\\/\",\"price\":\"&#36;49.00\",\"hash\":\"209d98f3ccde6cc3de7e8732a2b20b6a\",\"slug\":\"wooslider\",\"id\":46506},{\"title\":\"WooCommerce Social Login\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/08\\/Thumbnail-Social-Login-updated.png\",\"excerpt\":\"Enable Social Login for seamless checkout and account creation.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-social-login\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"http:\\/\\/demos.skyverge.com\\/woocommerce-social-login\\/\",\"price\":\"&#36;79.00\",\"hash\":\"b231cd6367a79cc8a53b7d992d77525d\",\"slug\":\"woocommerce-social-login\",\"id\":473617},{\"title\":\"WooCommerce Order Status Control\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/06\\/Thumbnail-Order-Status-Control-updated.png\",\"excerpt\":\"Use this extension to automatically change the order status to \\\"completed\\\" after successful payment.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-order-status-control\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"32400e509c7c36dcc1cd368e8267d981\",\"slug\":\"woocommerce-order-status-control\",\"id\":439037},{\"title\":\"Variation Swatches and Photos\",\"image\":\"\",\"excerpt\":\"Show color and image swatches instead of dropdowns for variable products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/variation-swatches-and-photos\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/www.elementstark.com\\/woocommerce-extension-demos\\/product-category\\/swatches-and-photos\\/\",\"price\":\"&#36;99.00\",\"hash\":\"37bea8d549df279c8278878d081b062f\",\"slug\":\"woocommerce-variation-swatches-and-photos\",\"id\":18697},{\"title\":\"Opayo Payment Suite\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2011\\/10\\/Opayo_logo_RGB.png\",\"excerpt\":\"Take payments on your WooCommerce store via Opayo (formally SagePay).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/sage-pay-form\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"6bc0cca47d0274d8ef9b164f6fbec1cc\",\"slug\":\"woocommerce-gateway-sagepay-form\",\"id\":18599},{\"title\":\"EU VAT Number\",\"image\":\"\",\"excerpt\":\"Collect VAT numbers at checkout and remove the VAT charge for eligible EU businesses.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/eu-vat-number\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"d2720c4b4bb8d6908e530355b7a2d734\",\"slug\":\"woocommerce-eu-vat-number\",\"id\":18592},{\"title\":\"Customer\\/Order\\/Coupon CSV Import Suite\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/07\\/Thumbnail-Customer-Order-Coupon-CSV-Import-Suite-updated.png\",\"excerpt\":\"Import both customers and orders into WooCommerce from a CSV file.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/customerorder-csv-import-suite\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"eb00ca8317a0f64dbe185c995e5ea3df\",\"slug\":\"woocommerce-customer-order-csv-import\",\"id\":18709}]}\";s:7:\"headers\";O:25:\"Requests_Response_Headers\":1:{s:7:\"\0*\0data\";a:18:{s:6:\"server\";a:1:{i:0;s:5:\"nginx\";}s:4:\"date\";a:1:{i:0;s:29:\"Tue, 29 Jun 2021 11:58:01 GMT\";}s:12:\"content-type\";a:1:{i:0;s:31:\"application/json; charset=UTF-8\";}s:14:\"content-length\";a:1:{i:0;s:5:\"11617\";}s:12:\"x-robots-tag\";a:1:{i:0;s:7:\"noindex\";}s:4:\"link\";a:1:{i:0;s:60:\"<https://woocommerce.com/wp-json/>; rel=\"https://api.w.org/\"\";}s:22:\"x-content-type-options\";a:1:{i:0;s:7:\"nosniff\";}s:29:\"access-control-expose-headers\";a:1:{i:0;s:33:\"X-WP-Total, X-WP-TotalPages, Link\";}s:28:\"access-control-allow-headers\";a:1:{i:0;s:73:\"Authorization, X-WP-Nonce, Content-Disposition, Content-MD5, Content-Type\";}s:13:\"x-wccom-cache\";a:1:{i:0;s:3:\"HIT\";}s:13:\"cache-control\";a:1:{i:0;s:10:\"max-age=60\";}s:5:\"allow\";a:1:{i:0;s:3:\"GET\";}s:16:\"content-encoding\";a:1:{i:0;s:4:\"gzip\";}s:4:\"x-rq\";a:1:{i:0;s:16:\"hhn1 91 142 3184\";}s:3:\"age\";a:1:{i:0;s:2:\"30\";}s:7:\"x-cache\";a:1:{i:0;s:3:\"hit\";}s:4:\"vary\";a:1:{i:0;s:23:\"Accept-Encoding, Origin\";}s:13:\"accept-ranges\";a:1:{i:0;s:5:\"bytes\";}}}s:11:\"status_code\";i:200;s:16:\"protocol_version\";d:1.100000000000000088817841970012523233890533447265625;s:7:\"success\";b:1;s:9:\"redirects\";i:0;s:3:\"url\";s:59:\"https://woocommerce.com/wp-json/wccom-extensions/1.0/search\";s:7:\"history\";a:0:{}s:7:\"cookies\";O:19:\"Requests_Cookie_Jar\":1:{s:10:\"\0*\0cookies\";a:0:{}}}s:11:\"\0*\0filename\";N;s:4:\"data\";N;s:7:\"headers\";N;s:6:\"status\";N;}}', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(6905, '_transient_timeout_wc_related_139', '1625104968', 'no'),
(6906, '_transient_wc_related_139', 'a:1:{s:51:\"limit=4&exclude_ids%5B0%5D=0&exclude_ids%5B1%5D=139\";a:17:{i:0;s:3:\"135\";i:1;s:3:\"137\";i:2;s:3:\"141\";i:3;s:3:\"143\";i:4;s:3:\"145\";i:5;s:3:\"148\";i:6;s:3:\"150\";i:7;s:3:\"152\";i:8;s:3:\"154\";i:9;s:3:\"156\";i:10;s:3:\"158\";i:11;s:3:\"160\";i:12;s:3:\"162\";i:13;s:3:\"164\";i:14;s:3:\"166\";i:15;s:3:\"168\";i:16;s:3:\"170\";}}', 'no'),
(6952, '_site_transient_update_themes', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1625082011;s:7:\"checked\";a:2:{s:12:\"manufacturer\";s:0:\"\";s:13:\"twentyfifteen\";s:0:\"\";}s:8:\"response\";a:1:{s:13:\"twentyfifteen\";a:6:{s:5:\"theme\";s:13:\"twentyfifteen\";s:11:\"new_version\";s:3:\"2.9\";s:3:\"url\";s:43:\"https://wordpress.org/themes/twentyfifteen/\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/theme/twentyfifteen.2.9.zip\";s:8:\"requires\";b:0;s:12:\"requires_php\";s:5:\"5.2.4\";}}s:9:\"no_update\";a:0:{}s:12:\"translations\";a:0:{}}', 'no'),
(6953, '_site_transient_update_plugins', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1625081991;s:7:\"checked\";a:6:{s:19:\"akismet/akismet.php\";s:5:\"4.1.9\";s:56:\"woo-checkout-field-editor-pro/checkout-form-designer.php\";s:5:\"1.4.8\";s:9:\"hello.php\";s:5:\"1.7.2\";s:47:\"really-simple-ssl/rlrsssl-really-simple-ssl.php\";s:6:\"4.0.15\";s:23:\"cyrlitera/cyrlitera.php\";s:5:\"1.1.2\";s:27:\"woocommerce/woocommerce.php\";s:5:\"5.3.0\";}s:8:\"response\";a:1:{s:27:\"woocommerce/woocommerce.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:25:\"w.org/plugins/woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:6:\"plugin\";s:27:\"woocommerce/woocommerce.php\";s:11:\"new_version\";s:5:\"5.4.1\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/woocommerce/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/woocommerce.5.4.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-256x256.png?rev=2366418\";s:2:\"1x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-128x128.png?rev=2366418\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/woocommerce/assets/banner-1544x500.png?rev=2366418\";s:2:\"1x\";s:66:\"https://ps.w.org/woocommerce/assets/banner-772x250.png?rev=2366418\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.7.2\";s:12:\"requires_php\";s:3:\"7.0\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:5:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:5:\"4.1.9\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/akismet.4.1.9.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}}s:56:\"woo-checkout-field-editor-pro/checkout-form-designer.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:43:\"w.org/plugins/woo-checkout-field-editor-pro\";s:4:\"slug\";s:29:\"woo-checkout-field-editor-pro\";s:6:\"plugin\";s:56:\"woo-checkout-field-editor-pro/checkout-form-designer.php\";s:11:\"new_version\";s:5:\"1.4.8\";s:3:\"url\";s:60:\"https://wordpress.org/plugins/woo-checkout-field-editor-pro/\";s:7:\"package\";s:72:\"https://downloads.wordpress.org/plugin/woo-checkout-field-editor-pro.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:82:\"https://ps.w.org/woo-checkout-field-editor-pro/assets/icon-256x256.png?rev=1821155\";s:2:\"1x\";s:82:\"https://ps.w.org/woo-checkout-field-editor-pro/assets/icon-128x128.png?rev=1821155\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:85:\"https://ps.w.org/woo-checkout-field-editor-pro/assets/banner-1544x500.png?rev=1975484\";s:2:\"1x\";s:84:\"https://ps.w.org/woo-checkout-field-editor-pro/assets/banner-772x250.png?rev=1975484\";}s:11:\"banners_rtl\";a:0:{}}s:9:\"hello.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/hello-dolly\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:5:\"1.7.2\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/hello-dolly.1.7.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=2052855\";s:2:\"1x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=2052855\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:66:\"https://ps.w.org/hello-dolly/assets/banner-772x250.jpg?rev=2052855\";}s:11:\"banners_rtl\";a:0:{}}s:47:\"really-simple-ssl/rlrsssl-really-simple-ssl.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:31:\"w.org/plugins/really-simple-ssl\";s:4:\"slug\";s:17:\"really-simple-ssl\";s:6:\"plugin\";s:47:\"really-simple-ssl/rlrsssl-really-simple-ssl.php\";s:11:\"new_version\";s:6:\"4.0.15\";s:3:\"url\";s:48:\"https://wordpress.org/plugins/really-simple-ssl/\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/plugin/really-simple-ssl.4.0.15.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:70:\"https://ps.w.org/really-simple-ssl/assets/icon-128x128.png?rev=1782452\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/really-simple-ssl/assets/banner-1544x500.png?rev=2320223\";s:2:\"1x\";s:72:\"https://ps.w.org/really-simple-ssl/assets/banner-772x250.png?rev=2320228\";}s:11:\"banners_rtl\";a:0:{}}s:23:\"cyrlitera/cyrlitera.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:23:\"w.org/plugins/cyrlitera\";s:4:\"slug\";s:9:\"cyrlitera\";s:6:\"plugin\";s:23:\"cyrlitera/cyrlitera.php\";s:11:\"new_version\";s:5:\"1.1.2\";s:3:\"url\";s:40:\"https://wordpress.org/plugins/cyrlitera/\";s:7:\"package\";s:52:\"https://downloads.wordpress.org/plugin/cyrlitera.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:62:\"https://ps.w.org/cyrlitera/assets/icon-256x256.png?rev=1844189\";s:2:\"1x\";s:62:\"https://ps.w.org/cyrlitera/assets/icon-128x128.png?rev=1844189\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:65:\"https://ps.w.org/cyrlitera/assets/banner-1544x500.jpg?rev=1844250\";s:2:\"1x\";s:64:\"https://ps.w.org/cyrlitera/assets/banner-772x250.jpg?rev=1844250\";}s:11:\"banners_rtl\";a:0:{}}}}', 'no'),
(6964, '_transient_timeout_wc_related_166', '1625131168', 'no'),
(6965, '_transient_wc_related_166', 'a:1:{s:51:\"limit=4&exclude_ids%5B0%5D=0&exclude_ids%5B1%5D=166\";a:17:{i:0;s:3:\"135\";i:1;s:3:\"137\";i:2;s:3:\"139\";i:3;s:3:\"141\";i:4;s:3:\"143\";i:5;s:3:\"145\";i:6;s:3:\"148\";i:7;s:3:\"150\";i:8;s:3:\"152\";i:9;s:3:\"154\";i:10;s:3:\"156\";i:11;s:3:\"158\";i:12;s:3:\"160\";i:13;s:3:\"162\";i:14;s:3:\"164\";i:15;s:3:\"168\";i:16;s:3:\"170\";}}', 'no'),
(7004, '_transient_timeout_wc_related_154', '1625154931', 'no'),
(7005, '_transient_wc_related_154', 'a:1:{s:51:\"limit=4&exclude_ids%5B0%5D=0&exclude_ids%5B1%5D=154\";a:17:{i:0;s:3:\"135\";i:1;s:3:\"137\";i:2;s:3:\"139\";i:3;s:3:\"141\";i:4;s:3:\"143\";i:5;s:3:\"145\";i:6;s:3:\"148\";i:7;s:3:\"150\";i:8;s:3:\"152\";i:9;s:3:\"156\";i:10;s:3:\"158\";i:11;s:3:\"160\";i:12;s:3:\"162\";i:13;s:3:\"164\";i:14;s:3:\"166\";i:15;s:3:\"168\";i:16;s:3:\"170\";}}', 'no'),
(7017, '_transient_timeout_wc_related_79', '1625160052', 'no'),
(7018, '_transient_wc_related_79', 'a:1:{s:50:\"limit=4&exclude_ids%5B0%5D=0&exclude_ids%5B1%5D=79\";a:23:{i:0;s:2:\"10\";i:1;s:2:\"53\";i:2;s:2:\"57\";i:3;s:2:\"59\";i:4;s:2:\"61\";i:5;s:2:\"63\";i:6;s:2:\"65\";i:7;s:2:\"67\";i:8;s:2:\"69\";i:9;s:2:\"71\";i:10;s:2:\"73\";i:11;s:2:\"75\";i:12;s:2:\"77\";i:13;s:2:\"81\";i:14;s:2:\"83\";i:15;s:2:\"85\";i:16;s:2:\"88\";i:17;s:2:\"90\";i:18;s:2:\"92\";i:19;s:2:\"94\";i:20;s:2:\"96\";i:21;s:2:\"98\";i:22;s:3:\"100\";}}', 'no'),
(7019, '_transient_timeout_wc_related_156', '1625160053', 'no'),
(7020, '_transient_wc_related_156', 'a:1:{s:51:\"limit=4&exclude_ids%5B0%5D=0&exclude_ids%5B1%5D=156\";a:17:{i:0;s:3:\"135\";i:1;s:3:\"137\";i:2;s:3:\"139\";i:3;s:3:\"141\";i:4;s:3:\"143\";i:5;s:3:\"145\";i:6;s:3:\"148\";i:7;s:3:\"150\";i:8;s:3:\"152\";i:9;s:3:\"154\";i:10;s:3:\"158\";i:11;s:3:\"160\";i:12;s:3:\"162\";i:13;s:3:\"164\";i:14;s:3:\"166\";i:15;s:3:\"168\";i:16;s:3:\"170\";}}', 'no'),
(7021, '_transient_timeout_wc_related_81', '1625160053', 'no'),
(7022, '_transient_wc_related_81', 'a:1:{s:50:\"limit=4&exclude_ids%5B0%5D=0&exclude_ids%5B1%5D=81\";a:23:{i:0;s:2:\"10\";i:1;s:2:\"53\";i:2;s:2:\"57\";i:3;s:2:\"59\";i:4;s:2:\"61\";i:5;s:2:\"63\";i:6;s:2:\"65\";i:7;s:2:\"67\";i:8;s:2:\"69\";i:9;s:2:\"71\";i:10;s:2:\"73\";i:11;s:2:\"75\";i:12;s:2:\"77\";i:13;s:2:\"79\";i:14;s:2:\"83\";i:15;s:2:\"85\";i:16;s:2:\"88\";i:17;s:2:\"90\";i:18;s:2:\"92\";i:19;s:2:\"94\";i:20;s:2:\"96\";i:21;s:2:\"98\";i:22;s:3:\"100\";}}', 'no'),
(7023, '_transient_timeout_wc_related_88', '1625160054', 'no'),
(7024, '_transient_wc_related_88', 'a:1:{s:50:\"limit=4&exclude_ids%5B0%5D=0&exclude_ids%5B1%5D=88\";a:23:{i:0;s:2:\"10\";i:1;s:2:\"53\";i:2;s:2:\"57\";i:3;s:2:\"59\";i:4;s:2:\"61\";i:5;s:2:\"63\";i:6;s:2:\"65\";i:7;s:2:\"67\";i:8;s:2:\"69\";i:9;s:2:\"71\";i:10;s:2:\"73\";i:11;s:2:\"75\";i:12;s:2:\"77\";i:13;s:2:\"79\";i:14;s:2:\"81\";i:15;s:2:\"83\";i:16;s:2:\"85\";i:17;s:2:\"90\";i:18;s:2:\"92\";i:19;s:2:\"94\";i:20;s:2:\"96\";i:21;s:2:\"98\";i:22;s:3:\"100\";}}', 'no'),
(7025, '_transient_timeout_wc_related_63', '1625160054', 'no'),
(7026, '_transient_wc_related_63', 'a:1:{s:50:\"limit=4&exclude_ids%5B0%5D=0&exclude_ids%5B1%5D=63\";a:23:{i:0;s:2:\"10\";i:1;s:2:\"53\";i:2;s:2:\"57\";i:3;s:2:\"59\";i:4;s:2:\"61\";i:5;s:2:\"65\";i:6;s:2:\"67\";i:7;s:2:\"69\";i:8;s:2:\"71\";i:9;s:2:\"73\";i:10;s:2:\"75\";i:11;s:2:\"77\";i:12;s:2:\"79\";i:13;s:2:\"81\";i:14;s:2:\"83\";i:15;s:2:\"85\";i:16;s:2:\"88\";i:17;s:2:\"90\";i:18;s:2:\"92\";i:19;s:2:\"94\";i:20;s:2:\"96\";i:21;s:2:\"98\";i:22;s:3:\"100\";}}', 'no'),
(7027, '_transient_timeout_wc_related_98', '1625160055', 'no'),
(7028, '_transient_wc_related_98', 'a:1:{s:50:\"limit=4&exclude_ids%5B0%5D=0&exclude_ids%5B1%5D=98\";a:23:{i:0;s:2:\"10\";i:1;s:2:\"53\";i:2;s:2:\"57\";i:3;s:2:\"59\";i:4;s:2:\"61\";i:5;s:2:\"63\";i:6;s:2:\"65\";i:7;s:2:\"67\";i:8;s:2:\"69\";i:9;s:2:\"71\";i:10;s:2:\"73\";i:11;s:2:\"75\";i:12;s:2:\"77\";i:13;s:2:\"79\";i:14;s:2:\"81\";i:15;s:2:\"83\";i:16;s:2:\"85\";i:17;s:2:\"88\";i:18;s:2:\"90\";i:19;s:2:\"92\";i:20;s:2:\"94\";i:21;s:2:\"96\";i:22;s:3:\"100\";}}', 'no'),
(7029, '_transient_timeout_wc_related_174', '1625160055', 'no'),
(7030, '_transient_wc_related_174', 'a:1:{s:51:\"limit=4&exclude_ids%5B0%5D=0&exclude_ids%5B1%5D=174\";a:9:{i:0;s:3:\"172\";i:1;s:3:\"178\";i:2;s:3:\"180\";i:3;s:3:\"183\";i:4;s:3:\"185\";i:5;s:3:\"188\";i:6;s:3:\"190\";i:7;s:3:\"192\";i:8;s:3:\"194\";}}', 'no'),
(7031, '_transient_timeout_wc_related_69', '1625160057', 'no'),
(7032, '_transient_wc_related_69', 'a:1:{s:50:\"limit=4&exclude_ids%5B0%5D=0&exclude_ids%5B1%5D=69\";a:23:{i:0;s:2:\"10\";i:1;s:2:\"53\";i:2;s:2:\"57\";i:3;s:2:\"59\";i:4;s:2:\"61\";i:5;s:2:\"63\";i:6;s:2:\"65\";i:7;s:2:\"67\";i:8;s:2:\"71\";i:9;s:2:\"73\";i:10;s:2:\"75\";i:11;s:2:\"77\";i:12;s:2:\"79\";i:13;s:2:\"81\";i:14;s:2:\"83\";i:15;s:2:\"85\";i:16;s:2:\"88\";i:17;s:2:\"90\";i:18;s:2:\"92\";i:19;s:2:\"94\";i:20;s:2:\"96\";i:21;s:2:\"98\";i:22;s:3:\"100\";}}', 'no'),
(7034, '_transient_timeout_wc_related_194', '1625160060', 'no'),
(7035, '_transient_wc_related_194', 'a:1:{s:51:\"limit=4&exclude_ids%5B0%5D=0&exclude_ids%5B1%5D=194\";a:9:{i:0;s:3:\"172\";i:1;s:3:\"174\";i:2;s:3:\"178\";i:3;s:3:\"180\";i:4;s:3:\"183\";i:5;s:3:\"185\";i:6;s:3:\"188\";i:7;s:3:\"190\";i:8;s:3:\"192\";}}', 'no'),
(7036, '_transient_timeout_wc_related_143', '1625160061', 'no'),
(7037, '_transient_wc_related_143', 'a:1:{s:51:\"limit=4&exclude_ids%5B0%5D=0&exclude_ids%5B1%5D=143\";a:17:{i:0;s:3:\"135\";i:1;s:3:\"137\";i:2;s:3:\"139\";i:3;s:3:\"141\";i:4;s:3:\"145\";i:5;s:3:\"148\";i:6;s:3:\"150\";i:7;s:3:\"152\";i:8;s:3:\"154\";i:9;s:3:\"156\";i:10;s:3:\"158\";i:11;s:3:\"160\";i:12;s:3:\"162\";i:13;s:3:\"164\";i:14;s:3:\"166\";i:15;s:3:\"168\";i:16;s:3:\"170\";}}', 'no'),
(7059, '_transient_timeout__woocommerce_helper_subscriptions', '1625082891', 'no'),
(7060, '_transient__woocommerce_helper_subscriptions', 'a:0:{}', 'no'),
(7061, '_site_transient_timeout_theme_roots', '1625083791', 'no'),
(7062, '_site_transient_theme_roots', 'a:2:{s:12:\"manufacturer\";s:7:\"/themes\";s:13:\"twentyfifteen\";s:7:\"/themes\";}', 'no'),
(7063, '_transient_timeout__woocommerce_helper_updates', '1625125191', 'no'),
(7064, '_transient__woocommerce_helper_updates', 'a:4:{s:4:\"hash\";s:32:\"d751713988987e9331980363e24189ce\";s:7:\"updated\";i:1625081991;s:8:\"products\";a:0:{}s:6:\"errors\";a:1:{i:0;s:10:\"http-error\";}}', 'no'),
(7121, '_transient_timeout_wc_related_53', '1625199367', 'no'),
(7122, '_transient_wc_related_53', 'a:1:{s:50:\"limit=4&exclude_ids%5B0%5D=0&exclude_ids%5B1%5D=53\";a:23:{i:0;s:2:\"10\";i:1;s:2:\"57\";i:2;s:2:\"59\";i:3;s:2:\"61\";i:4;s:2:\"63\";i:5;s:2:\"65\";i:6;s:2:\"67\";i:7;s:2:\"69\";i:8;s:2:\"71\";i:9;s:2:\"73\";i:10;s:2:\"75\";i:11;s:2:\"77\";i:12;s:2:\"79\";i:13;s:2:\"81\";i:14;s:2:\"83\";i:15;s:2:\"85\";i:16;s:2:\"88\";i:17;s:2:\"90\";i:18;s:2:\"92\";i:19;s:2:\"94\";i:20;s:2:\"96\";i:21;s:2:\"98\";i:22;s:3:\"100\";}}', 'no'),
(7124, '_transient_timeout_wc_related_83', '1625199705', 'no'),
(7125, '_transient_wc_related_83', 'a:1:{s:50:\"limit=4&exclude_ids%5B0%5D=0&exclude_ids%5B1%5D=83\";a:23:{i:0;s:2:\"10\";i:1;s:2:\"53\";i:2;s:2:\"57\";i:3;s:2:\"59\";i:4;s:2:\"61\";i:5;s:2:\"63\";i:6;s:2:\"65\";i:7;s:2:\"67\";i:8;s:2:\"69\";i:9;s:2:\"71\";i:10;s:2:\"73\";i:11;s:2:\"75\";i:12;s:2:\"77\";i:13;s:2:\"79\";i:14;s:2:\"81\";i:15;s:2:\"85\";i:16;s:2:\"88\";i:17;s:2:\"90\";i:18;s:2:\"92\";i:19;s:2:\"94\";i:20;s:2:\"96\";i:21;s:2:\"98\";i:22;s:3:\"100\";}}', 'no');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_postmeta`
--
-- Создание: Июн 01 2021 г., 08:28
--

DROP TABLE IF EXISTS `wp_postmeta`;
CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 1, 'wbcr_wp_old_slug', '%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80'),
(4, 5, '_wp_attached_file', 'woocommerce-placeholder.png'),
(5, 5, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:27:\"woocommerce-placeholder.png\";s:5:\"sizes\";a:8:{s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:35:\"woocommerce-placeholder-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-600x600.png\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:37:\"woocommerce-placeholder-1024x1024.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-825x510.png\";s:5:\"width\";i:825;s:6:\"height\";i:510;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(6, 10, '_edit_last', '1'),
(7, 10, '_edit_lock', '1622634897:1'),
(8, 11, '_wp_attached_file', '2021/06/image2.png'),
(9, 11, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:330;s:6:\"height\";i:490;s:4:\"file\";s:18:\"2021/06/image2.png\";s:5:\"sizes\";a:6:{s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:18:\"image2-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:18:\"image2-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"image2-202x300.png\";s:5:\"width\";i:202;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"image2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:18:\"image2-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:0;}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:18:\"image2-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(10, 10, '_thumbnail_id', '11'),
(11, 10, '_regular_price', '1790'),
(12, 10, 'total_sales', '13'),
(13, 10, '_tax_status', 'taxable'),
(14, 10, '_tax_class', ''),
(15, 10, '_manage_stock', 'no'),
(16, 10, '_backorders', 'no'),
(17, 10, '_sold_individually', 'no'),
(18, 10, '_virtual', 'no'),
(19, 10, '_downloadable', 'no'),
(20, 10, '_download_limit', '-1'),
(21, 10, '_download_expiry', '-1'),
(23, 10, '_stock_status', 'instock'),
(24, 10, '_wc_average_rating', '0'),
(25, 10, '_wc_review_count', '0'),
(26, 10, '_product_version', '5.3.0'),
(27, 10, '_price', '1790'),
(28, 12, '_edit_lock', '1622547090:1'),
(45, 12, '_wp_trash_meta_status', 'publish'),
(46, 12, '_wp_trash_meta_time', '1622547105'),
(101, 22, '_order_key', 'wc_order_GqSCGG4IVQM6d'),
(102, 22, '_customer_user', '1'),
(103, 22, '_payment_method', 'cod'),
(104, 22, '_payment_method_title', 'Оплата при доставке'),
(105, 22, '_customer_ip_address', '46.61.99.57'),
(106, 22, '_customer_user_agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.72 YaBrowser/21.5.1.330 Yowser/2.5 Safari/537.36'),
(107, 22, '_created_via', 'checkout'),
(108, 22, '_cart_hash', '98fbb6b1ad093989e38606ac18a37ec3'),
(109, 22, '_billing_first_name', '123'),
(110, 22, '_billing_last_name', '123'),
(111, 22, '_billing_company', '123'),
(112, 22, '_billing_address_1', '123'),
(113, 22, '_billing_address_2', '123'),
(114, 22, '_billing_city', '123'),
(115, 22, '_billing_state', '123'),
(116, 22, '_billing_postcode', '123'),
(117, 22, '_billing_country', 'RU'),
(118, 22, '_billing_email', 'gartonot62@gmail.com'),
(119, 22, '_billing_phone', '123'),
(120, 22, '_order_currency', 'RUB'),
(121, 22, '_cart_discount', '0'),
(122, 22, '_cart_discount_tax', '0'),
(123, 22, '_order_shipping', '0'),
(124, 22, '_order_shipping_tax', '0'),
(125, 22, '_order_tax', '0'),
(126, 22, '_order_total', '23270'),
(127, 22, '_order_version', '5.3.0'),
(128, 22, '_prices_include_tax', 'no'),
(129, 22, '_billing_address_index', '123 123 123 123 123 123 123 123 RU gartonot62@gmail.com 123'),
(130, 22, '_shipping_address_index', '        '),
(131, 22, 'is_vat_exempt', 'no'),
(132, 22, '_download_permissions_granted', 'yes'),
(133, 22, '_recorded_sales', 'yes'),
(134, 22, '_recorded_coupon_usage_counts', 'yes'),
(135, 22, '_order_stock_reduced', 'yes'),
(136, 22, '_new_order_email_sent', 'true'),
(170, 23, '_wp_trash_meta_status', 'publish'),
(171, 23, '_wp_trash_meta_time', '1622634560'),
(172, 29, '_edit_last', '1'),
(173, 29, '_edit_lock', '1622716231:1'),
(174, 30, '_wp_attached_file', '2021/06/gdr020836-1-01-300wx300h.jpg'),
(175, 30, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/gdr020836-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"gdr020836-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"gdr020836-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:36:\"gdr020836-1-01-300wx300h-350x445.jpg\";s:5:\"width\";i:350;s:6:\"height\";i:445;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"gdr020836-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"gdr020836-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:36:\"gdr020836-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"gdr020836-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(176, 29, '_thumbnail_id', '30'),
(177, 29, '_regular_price', '1990'),
(178, 29, 'total_sales', '0'),
(179, 29, '_tax_status', 'taxable'),
(180, 29, '_tax_class', ''),
(181, 29, '_manage_stock', 'no'),
(182, 29, '_backorders', 'no'),
(183, 29, '_sold_individually', 'no'),
(184, 29, '_virtual', 'no'),
(185, 29, '_downloadable', 'no'),
(186, 29, '_download_limit', '-1'),
(187, 29, '_download_expiry', '-1'),
(188, 29, '_stock', NULL),
(189, 29, '_stock_status', 'instock'),
(190, 29, '_wc_average_rating', '0'),
(191, 29, '_wc_review_count', '0'),
(192, 29, '_product_version', '5.3.0'),
(193, 29, '_price', '1990'),
(195, 7, '_edit_lock', '1622715775:1'),
(196, 31, '_menu_item_type', 'custom'),
(197, 31, '_menu_item_menu_item_parent', '0'),
(198, 31, '_menu_item_object_id', '31'),
(199, 31, '_menu_item_object', 'custom'),
(200, 31, '_menu_item_target', ''),
(201, 31, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(202, 31, '_menu_item_xfn', ''),
(203, 31, '_menu_item_url', '/'),
(210, 32, '_edit_lock', '1622754763:1'),
(212, 35, '_edit_lock', '1622755077:1'),
(213, 37, '_edit_lock', '1622755951:1'),
(214, 39, '_menu_item_type', 'post_type'),
(215, 39, '_menu_item_menu_item_parent', '0'),
(216, 39, '_menu_item_object_id', '37'),
(217, 39, '_menu_item_object', 'page'),
(218, 39, '_menu_item_target', ''),
(219, 39, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(220, 39, '_menu_item_xfn', ''),
(221, 39, '_menu_item_url', ''),
(223, 40, '_menu_item_type', 'post_type'),
(224, 40, '_menu_item_menu_item_parent', '0'),
(225, 40, '_menu_item_object_id', '35'),
(226, 40, '_menu_item_object', 'page'),
(227, 40, '_menu_item_target', ''),
(228, 40, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(229, 40, '_menu_item_xfn', ''),
(230, 40, '_menu_item_url', ''),
(232, 41, '_menu_item_type', 'post_type'),
(233, 41, '_menu_item_menu_item_parent', '0'),
(234, 41, '_menu_item_object_id', '32'),
(235, 41, '_menu_item_object', 'page'),
(236, 41, '_menu_item_target', ''),
(237, 41, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(238, 41, '_menu_item_xfn', ''),
(239, 41, '_menu_item_url', ''),
(241, 42, '_menu_item_type', 'post_type'),
(242, 42, '_menu_item_menu_item_parent', '0'),
(243, 42, '_menu_item_object_id', '6'),
(244, 42, '_menu_item_object', 'page'),
(245, 42, '_menu_item_target', ''),
(246, 42, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(247, 42, '_menu_item_xfn', ''),
(248, 42, '_menu_item_url', ''),
(251, 6, '_edit_lock', '1622728860:1'),
(261, 45, '_menu_item_type', 'taxonomy'),
(262, 45, '_menu_item_menu_item_parent', '0'),
(263, 45, '_menu_item_object_id', '16'),
(264, 45, '_menu_item_object', 'product_cat'),
(265, 45, '_menu_item_target', ''),
(266, 45, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(267, 45, '_menu_item_xfn', ''),
(268, 45, '_menu_item_url', ''),
(269, 46, '_menu_item_type', 'taxonomy'),
(270, 46, '_menu_item_menu_item_parent', '0'),
(271, 46, '_menu_item_object_id', '20'),
(272, 46, '_menu_item_object', 'product_cat'),
(273, 46, '_menu_item_target', ''),
(274, 46, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(275, 46, '_menu_item_xfn', ''),
(276, 46, '_menu_item_url', ''),
(277, 47, '_menu_item_type', 'taxonomy'),
(278, 47, '_menu_item_menu_item_parent', '0'),
(279, 47, '_menu_item_object_id', '21'),
(280, 47, '_menu_item_object', 'product_cat'),
(281, 47, '_menu_item_target', ''),
(282, 47, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(283, 47, '_menu_item_xfn', ''),
(284, 47, '_menu_item_url', ''),
(285, 48, '_menu_item_type', 'taxonomy'),
(286, 48, '_menu_item_menu_item_parent', '0'),
(287, 48, '_menu_item_object_id', '22'),
(288, 48, '_menu_item_object', 'product_cat'),
(289, 48, '_menu_item_target', ''),
(290, 48, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(291, 48, '_menu_item_xfn', ''),
(292, 48, '_menu_item_url', ''),
(293, 44, '_wp_trash_meta_status', 'publish'),
(294, 44, '_wp_trash_meta_time', '1622731464'),
(295, 50, '_menu_item_type', 'custom'),
(296, 50, '_menu_item_menu_item_parent', '0'),
(297, 50, '_menu_item_object_id', '50'),
(298, 50, '_menu_item_object', 'custom'),
(299, 50, '_menu_item_target', ''),
(300, 50, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(301, 50, '_menu_item_xfn', ''),
(302, 50, '_menu_item_url', '/'),
(303, 49, '_wp_trash_meta_status', 'publish'),
(304, 49, '_wp_trash_meta_time', '1622731497'),
(305, 51, '_edit_last', '1'),
(306, 51, '_edit_lock', '1622734493:1'),
(307, 52, '_wp_attached_file', '2021/06/gdr021496-1-01-300wx300h.jpg'),
(308, 52, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/gdr021496-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"gdr021496-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"gdr021496-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"gdr021496-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"gdr021496-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"gdr021496-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"gdr021496-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"gdr021496-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(309, 51, '_thumbnail_id', '52'),
(310, 51, '_regular_price', '1999'),
(311, 51, 'total_sales', '0'),
(312, 51, '_tax_status', 'taxable'),
(313, 51, '_tax_class', ''),
(314, 51, '_manage_stock', 'no'),
(315, 51, '_backorders', 'no'),
(316, 51, '_sold_individually', 'no'),
(317, 51, '_virtual', 'no'),
(318, 51, '_downloadable', 'no'),
(319, 51, '_download_limit', '-1'),
(320, 51, '_download_expiry', '-1'),
(321, 51, '_stock', NULL),
(322, 51, '_stock_status', 'instock'),
(323, 51, '_wc_average_rating', '0'),
(324, 51, '_wc_review_count', '0'),
(325, 51, '_product_version', '5.3.0'),
(326, 51, '_price', '1999'),
(327, 55, '_menu_item_type', 'taxonomy'),
(328, 55, '_menu_item_menu_item_parent', '0'),
(329, 55, '_menu_item_object_id', '23'),
(330, 55, '_menu_item_object', 'product_cat'),
(331, 55, '_menu_item_target', ''),
(332, 55, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(333, 55, '_menu_item_xfn', ''),
(334, 55, '_menu_item_url', ''),
(335, 54, '_wp_trash_meta_status', 'publish'),
(336, 54, '_wp_trash_meta_time', '1622733388'),
(337, 56, '_wp_attached_file', '2021/06/bsh005135-2-01-300wx300h.jpg'),
(338, 56, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bsh005135-2-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bsh005135-2-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bsh005135-2-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bsh005135-2-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bsh005135-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bsh005135-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bsh005135-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bsh005135-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(339, 53, '_edit_last', '1'),
(340, 53, '_edit_lock', '1622733298:1'),
(341, 53, '_thumbnail_id', '56'),
(342, 53, '_regular_price', '1599'),
(343, 53, 'total_sales', '0'),
(344, 53, '_tax_status', 'taxable'),
(345, 53, '_tax_class', ''),
(346, 53, '_manage_stock', 'no'),
(347, 53, '_backorders', 'no'),
(348, 53, '_sold_individually', 'no'),
(349, 53, '_virtual', 'no'),
(350, 53, '_downloadable', 'no'),
(351, 53, '_download_limit', '-1'),
(352, 53, '_download_expiry', '-1'),
(353, 53, '_stock', NULL),
(354, 53, '_stock_status', 'instock'),
(355, 53, '_wc_average_rating', '0'),
(356, 53, '_wc_review_count', '0'),
(357, 53, '_product_version', '5.3.0'),
(358, 53, '_price', '1599'),
(359, 58, '_wp_attached_file', '2021/06/bsh004865-2-01-300wx300h.jpg'),
(360, 58, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bsh004865-2-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bsh004865-2-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bsh004865-2-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bsh004865-2-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bsh004865-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bsh004865-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bsh004865-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bsh004865-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(361, 57, '_edit_last', '1'),
(362, 57, '_edit_lock', '1622733402:1'),
(363, 57, '_thumbnail_id', '58'),
(364, 57, 'total_sales', '0'),
(365, 57, '_tax_status', 'taxable'),
(366, 57, '_tax_class', ''),
(367, 57, '_manage_stock', 'no'),
(368, 57, '_backorders', 'no'),
(369, 57, '_sold_individually', 'no'),
(370, 57, '_virtual', 'no'),
(371, 57, '_downloadable', 'no'),
(372, 57, '_download_limit', '-1'),
(373, 57, '_download_expiry', '-1'),
(374, 57, '_stock', NULL),
(375, 57, '_stock_status', 'instock'),
(376, 57, '_wc_average_rating', '0'),
(377, 57, '_wc_review_count', '0'),
(378, 57, '_product_version', '5.3.0'),
(379, 59, '_edit_last', '1'),
(380, 59, '_edit_lock', '1622733385:1'),
(381, 60, '_wp_attached_file', '2021/06/bkt008801-1-04-300wx300h.jpg'),
(382, 60, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bkt008801-1-04-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bkt008801-1-04-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bkt008801-1-04-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bkt008801-1-04-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bkt008801-1-04-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bkt008801-1-04-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bkt008801-1-04-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bkt008801-1-04-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(383, 59, '_thumbnail_id', '60'),
(384, 59, '_regular_price', '699'),
(385, 59, 'total_sales', '0'),
(386, 59, '_tax_status', 'taxable'),
(387, 59, '_tax_class', ''),
(388, 59, '_manage_stock', 'no'),
(389, 59, '_backorders', 'no'),
(390, 59, '_sold_individually', 'no'),
(391, 59, '_virtual', 'no'),
(392, 59, '_downloadable', 'no'),
(393, 59, '_download_limit', '-1'),
(394, 59, '_download_expiry', '-1'),
(395, 59, '_stock', NULL),
(396, 59, '_stock_status', 'instock'),
(397, 59, '_wc_average_rating', '0'),
(398, 59, '_wc_review_count', '0'),
(399, 59, '_product_version', '5.3.0'),
(400, 59, '_price', '699'),
(401, 57, '_regular_price', '999'),
(402, 57, '_price', '999'),
(403, 61, '_edit_last', '1'),
(404, 61, '_edit_lock', '1622733482:1'),
(405, 62, '_wp_attached_file', '2021/06/bac008702-1-01-300wx300h.jpg'),
(406, 62, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bac008702-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bac008702-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008702-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008702-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bac008702-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008702-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bac008702-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008702-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(407, 61, '_thumbnail_id', '62'),
(408, 61, '_regular_price', '2499'),
(409, 61, 'total_sales', '0'),
(410, 61, '_tax_status', 'taxable'),
(411, 61, '_tax_class', ''),
(412, 61, '_manage_stock', 'no'),
(413, 61, '_backorders', 'no'),
(414, 61, '_sold_individually', 'no'),
(415, 61, '_virtual', 'no'),
(416, 61, '_downloadable', 'no'),
(417, 61, '_download_limit', '-1'),
(418, 61, '_download_expiry', '-1'),
(419, 61, '_stock', NULL),
(420, 61, '_stock_status', 'instock'),
(421, 61, '_wc_average_rating', '0'),
(422, 61, '_wc_review_count', '0'),
(423, 61, '_product_version', '5.3.0'),
(424, 61, '_price', '2499'),
(425, 64, '_wp_attached_file', '2021/06/bac008655-1-01-300wx300h.jpg'),
(426, 64, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bac008655-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bac008655-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008655-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008655-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bac008655-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008655-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bac008655-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008655-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(427, 63, '_edit_last', '1'),
(428, 63, '_edit_lock', '1622733521:1'),
(429, 63, '_thumbnail_id', '64'),
(430, 63, '_regular_price', '1699'),
(431, 63, 'total_sales', '0'),
(432, 63, '_tax_status', 'taxable'),
(433, 63, '_tax_class', ''),
(434, 63, '_manage_stock', 'no'),
(435, 63, '_backorders', 'no'),
(436, 63, '_sold_individually', 'no'),
(437, 63, '_virtual', 'no'),
(438, 63, '_downloadable', 'no'),
(439, 63, '_download_limit', '-1'),
(440, 63, '_download_expiry', '-1'),
(441, 63, '_stock', NULL),
(442, 63, '_stock_status', 'instock'),
(443, 63, '_wc_average_rating', '0'),
(444, 63, '_wc_review_count', '0'),
(445, 63, '_product_version', '5.3.0'),
(446, 63, '_price', '1699'),
(447, 65, '_edit_last', '1'),
(448, 65, '_edit_lock', '1622733588:1'),
(449, 66, '_wp_attached_file', '2021/06/bow001276-1-01-300wx300h.jpg'),
(450, 66, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bow001276-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bow001276-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bow001276-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bow001276-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bow001276-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bow001276-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bow001276-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bow001276-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(451, 65, '_thumbnail_id', '66'),
(452, 65, '_regular_price', '2999'),
(453, 65, 'total_sales', '0'),
(454, 65, '_tax_status', 'taxable'),
(455, 65, '_tax_class', ''),
(456, 65, '_manage_stock', 'no'),
(457, 65, '_backorders', 'no'),
(458, 65, '_sold_individually', 'no'),
(459, 65, '_virtual', 'no'),
(460, 65, '_downloadable', 'no'),
(461, 65, '_download_limit', '-1'),
(462, 65, '_download_expiry', '-1'),
(463, 65, '_stock', NULL),
(464, 65, '_stock_status', 'instock'),
(465, 65, '_wc_average_rating', '0'),
(466, 65, '_wc_review_count', '0'),
(467, 65, '_product_version', '5.3.0'),
(468, 65, '_price', '2999'),
(469, 68, '_wp_attached_file', '2021/06/bjc001658-1-01-300wx300h.jpg'),
(470, 68, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bjc001658-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bjc001658-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bjc001658-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bjc001658-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bjc001658-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bjc001658-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bjc001658-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bjc001658-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(471, 67, '_edit_last', '1'),
(472, 67, '_edit_lock', '1622733659:1'),
(473, 67, '_thumbnail_id', '68'),
(474, 67, '_regular_price', '2999'),
(475, 67, 'total_sales', '0'),
(476, 67, '_tax_status', 'taxable'),
(477, 67, '_tax_class', ''),
(478, 67, '_manage_stock', 'no'),
(479, 67, '_backorders', 'no'),
(480, 67, '_sold_individually', 'no'),
(481, 67, '_virtual', 'no'),
(482, 67, '_downloadable', 'no'),
(483, 67, '_download_limit', '-1'),
(484, 67, '_download_expiry', '-1'),
(485, 67, '_stock', NULL),
(486, 67, '_stock_status', 'instock'),
(487, 67, '_wc_average_rating', '0'),
(488, 67, '_wc_review_count', '0'),
(489, 67, '_product_version', '5.3.0'),
(490, 67, '_price', '2999'),
(491, 70, '_wp_attached_file', '2021/06/bjc001658-2-01-300wx300h.jpg'),
(492, 70, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bjc001658-2-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bjc001658-2-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bjc001658-2-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bjc001658-2-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bjc001658-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bjc001658-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bjc001658-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bjc001658-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(493, 69, '_edit_last', '1'),
(494, 69, '_edit_lock', '1622733729:1'),
(495, 69, '_thumbnail_id', '70'),
(496, 69, '_regular_price', '2999'),
(497, 69, 'total_sales', '0'),
(498, 69, '_tax_status', 'taxable'),
(499, 69, '_tax_class', ''),
(500, 69, '_manage_stock', 'no'),
(501, 69, '_backorders', 'no'),
(502, 69, '_sold_individually', 'no'),
(503, 69, '_virtual', 'no'),
(504, 69, '_downloadable', 'no'),
(505, 69, '_download_limit', '-1'),
(506, 69, '_download_expiry', '-1'),
(507, 69, '_stock', NULL),
(508, 69, '_stock_status', 'instock'),
(509, 69, '_wc_average_rating', '0'),
(510, 69, '_wc_review_count', '0'),
(511, 69, '_product_version', '5.3.0'),
(512, 69, '_price', '2999'),
(513, 72, '_wp_attached_file', '2021/06/bpt002709-2-01-300wx300h.jpg'),
(514, 72, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bpt002709-2-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bpt002709-2-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bpt002709-2-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bpt002709-2-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bpt002709-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bpt002709-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bpt002709-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bpt002709-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(515, 71, '_edit_last', '1'),
(516, 71, '_thumbnail_id', '72'),
(517, 71, '_regular_price', '1999'),
(518, 71, 'total_sales', '0'),
(519, 71, '_tax_status', 'taxable'),
(520, 71, '_tax_class', ''),
(521, 71, '_manage_stock', 'no'),
(522, 71, '_backorders', 'no'),
(523, 71, '_sold_individually', 'no'),
(524, 71, '_virtual', 'no'),
(525, 71, '_downloadable', 'no'),
(526, 71, '_download_limit', '-1'),
(527, 71, '_download_expiry', '-1'),
(528, 71, '_stock', NULL),
(529, 71, '_stock_status', 'instock'),
(530, 71, '_wc_average_rating', '0'),
(531, 71, '_wc_review_count', '0'),
(532, 71, '_product_version', '5.3.0'),
(533, 71, '_price', '1999'),
(534, 71, '_edit_lock', '1622733791:1'),
(535, 73, '_edit_last', '1'),
(536, 73, '_edit_lock', '1622733908:1'),
(537, 74, '_wp_attached_file', '2021/06/bkt007967-2-01-300wx300h.jpg'),
(538, 74, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bkt007967-2-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bkt007967-2-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bkt007967-2-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bkt007967-2-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bkt007967-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bkt007967-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bkt007967-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bkt007967-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(539, 73, '_thumbnail_id', '74'),
(540, 73, '_regular_price', '899'),
(541, 73, 'total_sales', '0'),
(542, 73, '_tax_status', 'taxable'),
(543, 73, '_tax_class', ''),
(544, 73, '_manage_stock', 'no'),
(545, 73, '_backorders', 'no'),
(546, 73, '_sold_individually', 'no'),
(547, 73, '_virtual', 'no'),
(548, 73, '_downloadable', 'no'),
(549, 73, '_download_limit', '-1'),
(550, 73, '_download_expiry', '-1'),
(551, 73, '_stock', NULL),
(552, 73, '_stock_status', 'instock'),
(553, 73, '_wc_average_rating', '0'),
(554, 73, '_wc_review_count', '0'),
(555, 73, '_product_version', '5.3.0'),
(556, 73, '_price', '899'),
(557, 75, '_edit_last', '1'),
(558, 75, '_edit_lock', '1622733962:1'),
(559, 76, '_wp_attached_file', '2021/06/bac008511-2-01-300wx300h.jpg'),
(560, 76, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bac008511-2-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bac008511-2-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008511-2-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008511-2-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bac008511-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008511-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bac008511-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008511-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(561, 75, '_thumbnail_id', '76'),
(562, 75, '_regular_price', '1799'),
(563, 75, 'total_sales', '0'),
(564, 75, '_tax_status', 'taxable'),
(565, 75, '_tax_class', ''),
(566, 75, '_manage_stock', 'no'),
(567, 75, '_backorders', 'no'),
(568, 75, '_sold_individually', 'no'),
(569, 75, '_virtual', 'no'),
(570, 75, '_downloadable', 'no'),
(571, 75, '_download_limit', '-1'),
(572, 75, '_download_expiry', '-1'),
(573, 75, '_stock', NULL),
(574, 75, '_stock_status', 'instock'),
(575, 75, '_wc_average_rating', '0'),
(576, 75, '_wc_review_count', '0'),
(577, 75, '_product_version', '5.3.0'),
(578, 75, '_price', '1799'),
(579, 77, '_edit_last', '1'),
(580, 77, '_edit_lock', '1622734025:1'),
(581, 78, '_wp_attached_file', '2021/06/bac008650-1-01-300wx300h.jpg'),
(582, 78, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bac008650-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bac008650-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008650-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008650-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bac008650-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008650-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bac008650-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008650-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(583, 77, '_thumbnail_id', '78'),
(584, 77, 'total_sales', '0'),
(585, 77, '_tax_status', 'taxable'),
(586, 77, '_tax_class', ''),
(587, 77, '_manage_stock', 'no'),
(588, 77, '_backorders', 'no'),
(589, 77, '_sold_individually', 'no'),
(590, 77, '_virtual', 'no'),
(591, 77, '_downloadable', 'no'),
(592, 77, '_download_limit', '-1'),
(593, 77, '_download_expiry', '-1'),
(594, 77, '_stock', NULL),
(595, 77, '_stock_status', 'instock'),
(596, 77, '_wc_average_rating', '0'),
(597, 77, '_wc_review_count', '0'),
(598, 77, '_product_version', '5.3.0'),
(599, 77, '_regular_price', '1999'),
(600, 77, '_price', '1999'),
(601, 79, '_edit_last', '1'),
(602, 79, '_edit_lock', '1622734079:1'),
(603, 80, '_wp_attached_file', '2021/06/bkt006911-5-01-300wx300h.jpg'),
(604, 80, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bkt006911-5-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bkt006911-5-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bkt006911-5-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bkt006911-5-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bkt006911-5-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bkt006911-5-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bkt006911-5-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bkt006911-5-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(605, 79, '_thumbnail_id', '80'),
(606, 79, '_regular_price', '999'),
(607, 79, 'total_sales', '0'),
(608, 79, '_tax_status', 'taxable'),
(609, 79, '_tax_class', ''),
(610, 79, '_manage_stock', 'no'),
(611, 79, '_backorders', 'no'),
(612, 79, '_sold_individually', 'no'),
(613, 79, '_virtual', 'no'),
(614, 79, '_downloadable', 'no'),
(615, 79, '_download_limit', '-1'),
(616, 79, '_download_expiry', '-1'),
(617, 79, '_stock', NULL),
(618, 79, '_stock_status', 'instock'),
(619, 79, '_wc_average_rating', '0'),
(620, 79, '_wc_review_count', '0'),
(621, 79, '_product_version', '5.3.0'),
(622, 79, '_price', '999'),
(623, 81, '_edit_last', '1'),
(624, 81, '_edit_lock', '1622734118:1'),
(625, 82, '_wp_attached_file', '2021/06/bkt007749-1-01-300wx300h.jpg'),
(626, 82, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bkt007749-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bkt007749-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bkt007749-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bkt007749-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bkt007749-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bkt007749-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bkt007749-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bkt007749-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(627, 81, '_thumbnail_id', '82'),
(628, 81, '_regular_price', '599'),
(629, 81, 'total_sales', '0'),
(630, 81, '_tax_status', 'taxable'),
(631, 81, '_tax_class', ''),
(632, 81, '_manage_stock', 'no'),
(633, 81, '_backorders', 'no'),
(634, 81, '_sold_individually', 'no'),
(635, 81, '_virtual', 'no'),
(636, 81, '_downloadable', 'no'),
(637, 81, '_download_limit', '-1'),
(638, 81, '_download_expiry', '-1'),
(639, 81, '_stock', NULL),
(640, 81, '_stock_status', 'instock'),
(641, 81, '_wc_average_rating', '0'),
(642, 81, '_wc_review_count', '0'),
(643, 81, '_product_version', '5.3.0'),
(644, 81, '_price', '599'),
(645, 84, '_wp_attached_file', '2021/06/bkt007966-2-01-300wx300h.jpg');
INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(646, 84, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bkt007966-2-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bkt007966-2-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bkt007966-2-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bkt007966-2-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bkt007966-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bkt007966-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bkt007966-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bkt007966-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(647, 83, '_edit_last', '1'),
(648, 83, '_edit_lock', '1622734215:1'),
(649, 83, '_thumbnail_id', '84'),
(650, 83, '_regular_price', '799'),
(651, 83, 'total_sales', '3'),
(652, 83, '_tax_status', 'taxable'),
(653, 83, '_tax_class', ''),
(654, 83, '_manage_stock', 'no'),
(655, 83, '_backorders', 'no'),
(656, 83, '_sold_individually', 'no'),
(657, 83, '_virtual', 'no'),
(658, 83, '_downloadable', 'no'),
(659, 83, '_download_limit', '-1'),
(660, 83, '_download_expiry', '-1'),
(661, 83, '_stock', NULL),
(662, 83, '_stock_status', 'instock'),
(663, 83, '_wc_average_rating', '0'),
(664, 83, '_wc_review_count', '0'),
(665, 83, '_product_version', '5.3.0'),
(666, 83, '_price', '799'),
(667, 86, '_wp_attached_file', '2021/06/bac008718-1-01-300wx300h.jpg'),
(668, 86, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bac008718-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bac008718-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008718-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008718-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bac008718-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008718-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bac008718-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008718-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(669, 85, '_edit_last', '1'),
(670, 85, '_edit_lock', '1622734248:1'),
(671, 85, '_thumbnail_id', '86'),
(672, 85, '_regular_price', '1799'),
(673, 85, 'total_sales', '0'),
(674, 85, '_tax_status', 'taxable'),
(675, 85, '_tax_class', ''),
(676, 85, '_manage_stock', 'no'),
(677, 85, '_backorders', 'no'),
(678, 85, '_sold_individually', 'no'),
(679, 85, '_virtual', 'no'),
(680, 85, '_downloadable', 'no'),
(681, 85, '_download_limit', '-1'),
(682, 85, '_download_expiry', '-1'),
(683, 85, '_stock', NULL),
(684, 85, '_stock_status', 'instock'),
(685, 85, '_wc_average_rating', '0'),
(686, 85, '_wc_review_count', '0'),
(687, 85, '_product_version', '5.3.0'),
(688, 85, '_price', '1799'),
(689, 88, '_edit_last', '1'),
(690, 88, '_edit_lock', '1622734424:1'),
(691, 89, '_wp_attached_file', '2021/06/bpt002671-1-01-300wx300h.jpg'),
(692, 89, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bpt002671-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bpt002671-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bpt002671-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bpt002671-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bpt002671-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bpt002671-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bpt002671-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bpt002671-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(693, 88, '_thumbnail_id', '89'),
(694, 88, '_regular_price', '1999'),
(695, 88, 'total_sales', '0'),
(696, 88, '_tax_status', 'taxable'),
(697, 88, '_tax_class', ''),
(698, 88, '_manage_stock', 'no'),
(699, 88, '_backorders', 'no'),
(700, 88, '_sold_individually', 'no'),
(701, 88, '_virtual', 'no'),
(702, 88, '_downloadable', 'no'),
(703, 88, '_download_limit', '-1'),
(704, 88, '_download_expiry', '-1'),
(705, 88, '_stock', NULL),
(706, 88, '_stock_status', 'instock'),
(707, 88, '_wc_average_rating', '0'),
(708, 88, '_wc_review_count', '0'),
(709, 88, '_product_version', '5.3.0'),
(710, 88, '_price', '1999'),
(711, 91, '_wp_attached_file', '2021/06/bpt002671-2-01-300wx300h.jpg'),
(712, 91, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bpt002671-2-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bpt002671-2-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bpt002671-2-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bpt002671-2-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bpt002671-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bpt002671-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bpt002671-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bpt002671-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(713, 90, '_edit_last', '1'),
(714, 90, '_thumbnail_id', '91'),
(715, 90, '_regular_price', '1999'),
(716, 90, 'total_sales', '0'),
(717, 90, '_tax_status', 'taxable'),
(718, 90, '_tax_class', ''),
(719, 90, '_manage_stock', 'no'),
(720, 90, '_backorders', 'no'),
(721, 90, '_sold_individually', 'no'),
(722, 90, '_virtual', 'no'),
(723, 90, '_downloadable', 'no'),
(724, 90, '_download_limit', '-1'),
(725, 90, '_download_expiry', '-1'),
(726, 90, '_stock', NULL),
(727, 90, '_stock_status', 'instock'),
(728, 90, '_wc_average_rating', '0'),
(729, 90, '_wc_review_count', '0'),
(730, 90, '_product_version', '5.3.0'),
(731, 90, '_price', '1999'),
(732, 90, '_edit_lock', '1622734500:1'),
(733, 92, '_edit_last', '1'),
(734, 92, '_edit_lock', '1622734540:1'),
(735, 93, '_wp_attached_file', '2021/06/bac008363-1-01-300wx300h.jpg'),
(736, 93, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bac008363-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bac008363-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008363-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008363-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bac008363-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008363-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bac008363-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008363-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(737, 92, '_thumbnail_id', '93'),
(738, 92, '_regular_price', '1999'),
(739, 92, 'total_sales', '0'),
(740, 92, '_tax_status', 'taxable'),
(741, 92, '_tax_class', ''),
(742, 92, '_manage_stock', 'no'),
(743, 92, '_backorders', 'no'),
(744, 92, '_sold_individually', 'no'),
(745, 92, '_virtual', 'no'),
(746, 92, '_downloadable', 'no'),
(747, 92, '_download_limit', '-1'),
(748, 92, '_download_expiry', '-1'),
(749, 92, '_stock', NULL),
(750, 92, '_stock_status', 'instock'),
(751, 92, '_wc_average_rating', '0'),
(752, 92, '_wc_review_count', '0'),
(753, 92, '_product_version', '5.3.0'),
(754, 92, '_price', '1999'),
(755, 95, '_wp_attached_file', '2021/06/bac008654-1-01-300wx300h.jpg'),
(756, 95, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bac008654-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bac008654-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008654-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008654-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bac008654-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008654-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bac008654-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008654-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(757, 94, '_edit_last', '1'),
(758, 94, '_thumbnail_id', '95'),
(759, 94, '_regular_price', '1799'),
(760, 94, 'total_sales', '0'),
(761, 94, '_tax_status', 'taxable'),
(762, 94, '_tax_class', ''),
(763, 94, '_manage_stock', 'no'),
(764, 94, '_backorders', 'no'),
(765, 94, '_sold_individually', 'no'),
(766, 94, '_virtual', 'no'),
(767, 94, '_downloadable', 'no'),
(768, 94, '_download_limit', '-1'),
(769, 94, '_download_expiry', '-1'),
(770, 94, '_stock', NULL),
(771, 94, '_stock_status', 'instock'),
(772, 94, '_wc_average_rating', '0'),
(773, 94, '_wc_review_count', '0'),
(774, 94, '_product_version', '5.3.0'),
(775, 94, '_price', '1799'),
(776, 94, '_edit_lock', '1622734579:1'),
(777, 96, '_edit_last', '1'),
(778, 96, '_edit_lock', '1622734705:1'),
(779, 97, '_wp_attached_file', '2021/06/bac009526-1-01-300wx300h.jpg'),
(780, 97, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bac009526-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bac009526-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bac009526-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bac009526-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bac009526-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac009526-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bac009526-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac009526-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(781, 96, '_thumbnail_id', '97'),
(782, 96, '_regular_price', '1799'),
(783, 96, 'total_sales', '0'),
(784, 96, '_tax_status', 'taxable'),
(785, 96, '_tax_class', ''),
(786, 96, '_manage_stock', 'no'),
(787, 96, '_backorders', 'no'),
(788, 96, '_sold_individually', 'no'),
(789, 96, '_virtual', 'no'),
(790, 96, '_downloadable', 'no'),
(791, 96, '_download_limit', '-1'),
(792, 96, '_download_expiry', '-1'),
(793, 96, '_stock', NULL),
(794, 96, '_stock_status', 'instock'),
(795, 96, '_wc_average_rating', '0'),
(796, 96, '_wc_review_count', '0'),
(797, 96, '_product_version', '5.3.0'),
(798, 96, '_price', '1799'),
(799, 98, '_edit_last', '1'),
(800, 98, '_edit_lock', '1622734738:1'),
(801, 99, '_wp_attached_file', '2021/06/bpt002851-1-01-300wx300h.jpg'),
(802, 99, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bpt002851-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bpt002851-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bpt002851-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bpt002851-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bpt002851-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bpt002851-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bpt002851-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bpt002851-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(803, 98, '_thumbnail_id', '99'),
(804, 98, '_regular_price', '2299'),
(805, 98, 'total_sales', '0'),
(806, 98, '_tax_status', 'taxable'),
(807, 98, '_tax_class', ''),
(808, 98, '_manage_stock', 'no'),
(809, 98, '_backorders', 'no'),
(810, 98, '_sold_individually', 'no'),
(811, 98, '_virtual', 'no'),
(812, 98, '_downloadable', 'no'),
(813, 98, '_download_limit', '-1'),
(814, 98, '_download_expiry', '-1'),
(815, 98, '_stock', NULL),
(816, 98, '_stock_status', 'instock'),
(817, 98, '_wc_average_rating', '0'),
(818, 98, '_wc_review_count', '0'),
(819, 98, '_product_version', '5.3.0'),
(820, 98, '_price', '2299'),
(821, 100, '_edit_last', '1'),
(822, 100, '_edit_lock', '1622734824:1'),
(823, 101, '_wp_attached_file', '2021/06/bpt002722-4-01-300wx300h.jpg'),
(824, 101, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bpt002722-4-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bpt002722-4-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bpt002722-4-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bpt002722-4-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bpt002722-4-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bpt002722-4-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bpt002722-4-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bpt002722-4-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(825, 100, '_thumbnail_id', '101'),
(826, 100, '_regular_price', '1999'),
(827, 100, 'total_sales', '0'),
(828, 100, '_tax_status', 'taxable'),
(829, 100, '_tax_class', ''),
(830, 100, '_manage_stock', 'no'),
(831, 100, '_backorders', 'no'),
(832, 100, '_sold_individually', 'no'),
(833, 100, '_virtual', 'no'),
(834, 100, '_downloadable', 'no'),
(835, 100, '_download_limit', '-1'),
(836, 100, '_download_expiry', '-1'),
(837, 100, '_stock', NULL),
(838, 100, '_stock_status', 'instock'),
(839, 100, '_wc_average_rating', '0'),
(840, 100, '_wc_review_count', '0'),
(841, 100, '_product_version', '5.3.0'),
(842, 100, '_price', '1999'),
(843, 102, '_edit_last', '1'),
(844, 102, '_edit_lock', '1622734922:1'),
(845, 103, '_wp_attached_file', '2021/06/gdr022837-2-01-300wx300h.jpg'),
(846, 103, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/gdr022837-2-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"gdr022837-2-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"gdr022837-2-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"gdr022837-2-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"gdr022837-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"gdr022837-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"gdr022837-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"gdr022837-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(847, 102, '_thumbnail_id', '103'),
(848, 102, '_regular_price', '2199'),
(849, 102, 'total_sales', '0'),
(850, 102, '_tax_status', 'taxable'),
(851, 102, '_tax_class', ''),
(852, 102, '_manage_stock', 'no'),
(853, 102, '_backorders', 'no'),
(854, 102, '_sold_individually', 'no'),
(855, 102, '_virtual', 'no'),
(856, 102, '_downloadable', 'no'),
(857, 102, '_download_limit', '-1'),
(858, 102, '_download_expiry', '-1'),
(859, 102, '_stock', NULL),
(860, 102, '_stock_status', 'instock'),
(861, 102, '_wc_average_rating', '0'),
(862, 102, '_wc_review_count', '0'),
(863, 102, '_product_version', '5.3.0'),
(864, 102, '_price', '2199'),
(865, 104, '_edit_last', '1'),
(866, 104, '_edit_lock', '1622735013:1'),
(867, 105, '_wp_attached_file', '2021/06/gdr023418-2-01-300wx300h.jpg'),
(868, 105, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/gdr023418-2-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"gdr023418-2-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"gdr023418-2-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"gdr023418-2-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"gdr023418-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"gdr023418-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"gdr023418-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"gdr023418-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(869, 104, '_thumbnail_id', '105'),
(870, 104, '_regular_price', '1799'),
(871, 104, 'total_sales', '0'),
(872, 104, '_tax_status', 'taxable'),
(873, 104, '_tax_class', ''),
(874, 104, '_manage_stock', 'no'),
(875, 104, '_backorders', 'no'),
(876, 104, '_sold_individually', 'no'),
(877, 104, '_virtual', 'no'),
(878, 104, '_downloadable', 'no'),
(879, 104, '_download_limit', '-1'),
(880, 104, '_download_expiry', '-1'),
(881, 104, '_stock', NULL),
(882, 104, '_stock_status', 'instock'),
(883, 104, '_wc_average_rating', '0'),
(884, 104, '_wc_review_count', '0'),
(885, 104, '_product_version', '5.3.0'),
(886, 104, '_price', '1799'),
(887, 106, '_edit_last', '1'),
(888, 106, '_edit_lock', '1622735048:1'),
(889, 107, '_wp_attached_file', '2021/06/gjn019872-1-01-300wx300h.jpg'),
(890, 107, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/gjn019872-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"gjn019872-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"gjn019872-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"gjn019872-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"gjn019872-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"gjn019872-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"gjn019872-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"gjn019872-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(891, 106, '_thumbnail_id', '107'),
(892, 106, '_regular_price', '2799'),
(893, 106, 'total_sales', '0'),
(894, 106, '_tax_status', 'taxable'),
(895, 106, '_tax_class', ''),
(896, 106, '_manage_stock', 'no'),
(897, 106, '_backorders', 'no'),
(898, 106, '_sold_individually', 'no'),
(899, 106, '_virtual', 'no'),
(900, 106, '_downloadable', 'no'),
(901, 106, '_download_limit', '-1'),
(902, 106, '_download_expiry', '-1'),
(903, 106, '_stock', NULL),
(904, 106, '_stock_status', 'instock'),
(905, 106, '_wc_average_rating', '0'),
(906, 106, '_wc_review_count', '0'),
(907, 106, '_product_version', '5.3.0'),
(908, 106, '_price', '2799'),
(909, 108, '_edit_last', '1'),
(910, 108, '_edit_lock', '1622735087:1'),
(911, 109, '_wp_attached_file', '2021/06/gdr023729-1-01-300wx300h.jpg'),
(912, 109, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/gdr023729-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"gdr023729-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"gdr023729-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"gdr023729-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"gdr023729-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"gdr023729-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"gdr023729-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"gdr023729-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(913, 108, '_thumbnail_id', '109'),
(914, 108, '_regular_price', '1999'),
(915, 108, 'total_sales', '0'),
(916, 108, '_tax_status', 'taxable'),
(917, 108, '_tax_class', ''),
(918, 108, '_manage_stock', 'no'),
(919, 108, '_backorders', 'no'),
(920, 108, '_sold_individually', 'no'),
(921, 108, '_virtual', 'no'),
(922, 108, '_downloadable', 'no'),
(923, 108, '_download_limit', '-1'),
(924, 108, '_download_expiry', '-1'),
(925, 108, '_stock', NULL),
(926, 108, '_stock_status', 'instock'),
(927, 108, '_wc_average_rating', '0'),
(928, 108, '_wc_review_count', '0'),
(929, 108, '_product_version', '5.3.0'),
(930, 108, '_price', '1999'),
(931, 110, '_edit_last', '1'),
(932, 110, '_edit_lock', '1622735121:1'),
(933, 111, '_wp_attached_file', '2021/06/gdr023802-2-01-300wx300h.jpg'),
(934, 111, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/gdr023802-2-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"gdr023802-2-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"gdr023802-2-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"gdr023802-2-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"gdr023802-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"gdr023802-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"gdr023802-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"gdr023802-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(935, 110, '_thumbnail_id', '111'),
(936, 110, '_regular_price', '1899'),
(937, 110, 'total_sales', '0'),
(938, 110, '_tax_status', 'taxable'),
(939, 110, '_tax_class', ''),
(940, 110, '_manage_stock', 'no'),
(941, 110, '_backorders', 'no'),
(942, 110, '_sold_individually', 'no'),
(943, 110, '_virtual', 'no'),
(944, 110, '_downloadable', 'no'),
(945, 110, '_download_limit', '-1'),
(946, 110, '_download_expiry', '-1'),
(947, 110, '_stock', NULL),
(948, 110, '_stock_status', 'instock'),
(949, 110, '_wc_average_rating', '0'),
(950, 110, '_wc_review_count', '0'),
(951, 110, '_product_version', '5.3.0'),
(952, 110, '_price', '1899'),
(953, 112, '_edit_last', '1'),
(954, 112, '_edit_lock', '1622735159:1'),
(955, 113, '_wp_attached_file', '2021/06/gsh007021-1-01-300wx300h.jpg'),
(956, 113, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/gsh007021-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"gsh007021-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"gsh007021-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"gsh007021-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"gsh007021-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"gsh007021-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"gsh007021-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"gsh007021-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(957, 112, '_thumbnail_id', '113'),
(958, 112, '_regular_price', '1299'),
(959, 112, 'total_sales', '0'),
(960, 112, '_tax_status', 'taxable'),
(961, 112, '_tax_class', ''),
(962, 112, '_manage_stock', 'no'),
(963, 112, '_backorders', 'no'),
(964, 112, '_sold_individually', 'no'),
(965, 112, '_virtual', 'no'),
(966, 112, '_downloadable', 'no'),
(967, 112, '_download_limit', '-1'),
(968, 112, '_download_expiry', '-1'),
(969, 112, '_stock', NULL),
(970, 112, '_stock_status', 'instock'),
(971, 112, '_wc_average_rating', '0'),
(972, 112, '_wc_review_count', '0'),
(973, 112, '_product_version', '5.3.0'),
(974, 112, '_price', '1299'),
(975, 114, '_edit_last', '1'),
(976, 114, '_edit_lock', '1622735234:1'),
(977, 115, '_wp_attached_file', '2021/06/gsh007021-2-01-300wx300h.jpg'),
(978, 115, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/gsh007021-2-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"gsh007021-2-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"gsh007021-2-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"gsh007021-2-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"gsh007021-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"gsh007021-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"gsh007021-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"gsh007021-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(979, 114, '_thumbnail_id', '115'),
(980, 114, '_regular_price', '1299'),
(981, 114, 'total_sales', '0'),
(982, 114, '_tax_status', 'taxable'),
(983, 114, '_tax_class', ''),
(984, 114, '_manage_stock', 'no'),
(985, 114, '_backorders', 'no'),
(986, 114, '_sold_individually', 'no'),
(987, 114, '_virtual', 'no'),
(988, 114, '_downloadable', 'no'),
(989, 114, '_download_limit', '-1'),
(990, 114, '_download_expiry', '-1'),
(991, 114, '_stock', NULL),
(992, 114, '_stock_status', 'instock'),
(993, 114, '_wc_average_rating', '0'),
(994, 114, '_wc_review_count', '0'),
(995, 114, '_product_version', '5.3.0'),
(996, 114, '_price', '1299'),
(997, 116, '_edit_last', '1'),
(998, 116, '_edit_lock', '1622735277:1'),
(999, 117, '_wp_attached_file', '2021/06/gdr022968-1-01-300wx300h.jpg'),
(1000, 117, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/gdr022968-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"gdr022968-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"gdr022968-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"gdr022968-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"gdr022968-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"gdr022968-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"gdr022968-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"gdr022968-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1001, 116, '_thumbnail_id', '117'),
(1002, 116, '_regular_price', '1599'),
(1003, 116, 'total_sales', '0'),
(1004, 116, '_tax_status', 'taxable'),
(1005, 116, '_tax_class', ''),
(1006, 116, '_manage_stock', 'no'),
(1007, 116, '_backorders', 'no'),
(1008, 116, '_sold_individually', 'no'),
(1009, 116, '_virtual', 'no'),
(1010, 116, '_downloadable', 'no'),
(1011, 116, '_download_limit', '-1'),
(1012, 116, '_download_expiry', '-1'),
(1013, 116, '_stock', NULL),
(1014, 116, '_stock_status', 'instock'),
(1015, 116, '_wc_average_rating', '0'),
(1016, 116, '_wc_review_count', '0'),
(1017, 116, '_product_version', '5.3.0'),
(1018, 116, '_price', '1599'),
(1019, 118, '_edit_last', '1'),
(1020, 118, '_edit_lock', '1622735315:1'),
(1021, 119, '_wp_attached_file', '2021/06/gac015272-2-01-300wx300h.jpg'),
(1022, 119, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/gac015272-2-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"gac015272-2-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"gac015272-2-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"gac015272-2-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"gac015272-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"gac015272-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"gac015272-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"gac015272-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1023, 118, '_thumbnail_id', '119'),
(1024, 118, '_regular_price', '2499'),
(1025, 118, 'total_sales', '0'),
(1026, 118, '_tax_status', 'taxable'),
(1027, 118, '_tax_class', ''),
(1028, 118, '_manage_stock', 'no'),
(1029, 118, '_backorders', 'no'),
(1030, 118, '_sold_individually', 'no'),
(1031, 118, '_virtual', 'no'),
(1032, 118, '_downloadable', 'no'),
(1033, 118, '_download_limit', '-1'),
(1034, 118, '_download_expiry', '-1'),
(1035, 118, '_stock', NULL),
(1036, 118, '_stock_status', 'instock'),
(1037, 118, '_wc_average_rating', '0'),
(1038, 118, '_wc_review_count', '0'),
(1039, 118, '_product_version', '5.3.0'),
(1040, 118, '_price', '2499'),
(1041, 120, '_edit_last', '1'),
(1042, 120, '_edit_lock', '1622735348:1'),
(1043, 121, '_wp_attached_file', '2021/06/gac015635-1-01-300wx300h.jpg'),
(1044, 121, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/gac015635-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"gac015635-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"gac015635-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"gac015635-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"gac015635-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"gac015635-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"gac015635-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"gac015635-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1045, 120, '_thumbnail_id', '121'),
(1046, 120, '_regular_price', '2499'),
(1047, 120, 'total_sales', '0'),
(1048, 120, '_tax_status', 'taxable'),
(1049, 120, '_tax_class', ''),
(1050, 120, '_manage_stock', 'no'),
(1051, 120, '_backorders', 'no'),
(1052, 120, '_sold_individually', 'no'),
(1053, 120, '_virtual', 'no'),
(1054, 120, '_downloadable', 'no'),
(1055, 120, '_download_limit', '-1'),
(1056, 120, '_download_expiry', '-1'),
(1057, 120, '_stock', NULL),
(1058, 120, '_stock_status', 'instock'),
(1059, 120, '_wc_average_rating', '0'),
(1060, 120, '_wc_review_count', '0'),
(1061, 120, '_product_version', '5.3.0'),
(1062, 120, '_price', '2499'),
(1063, 122, '_edit_last', '1'),
(1064, 122, '_edit_lock', '1622735419:1'),
(1065, 123, '_wp_attached_file', '2021/06/gac016108-1-01-300wx300h.jpg'),
(1066, 123, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/gac016108-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"gac016108-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016108-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016108-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"gac016108-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016108-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"gac016108-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016108-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1067, 122, '_thumbnail_id', '123'),
(1068, 122, '_regular_price', '1999'),
(1069, 122, 'total_sales', '0'),
(1070, 122, '_tax_status', 'taxable'),
(1071, 122, '_tax_class', ''),
(1072, 122, '_manage_stock', 'no'),
(1073, 122, '_backorders', 'no'),
(1074, 122, '_sold_individually', 'no'),
(1075, 122, '_virtual', 'no'),
(1076, 122, '_downloadable', 'no'),
(1077, 122, '_download_limit', '-1'),
(1078, 122, '_download_expiry', '-1'),
(1079, 122, '_stock', NULL),
(1080, 122, '_stock_status', 'instock'),
(1081, 122, '_wc_average_rating', '0'),
(1082, 122, '_wc_review_count', '0'),
(1083, 122, '_product_version', '5.3.0'),
(1084, 122, '_price', '1999'),
(1085, 124, '_edit_last', '1'),
(1086, 124, '_edit_lock', '1622735532:1'),
(1087, 125, '_wp_attached_file', '2021/06/gac016154-1-01-300wx300h.jpg');
INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1088, 125, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/gac016154-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"gac016154-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016154-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016154-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"gac016154-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016154-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"gac016154-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016154-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1089, 124, '_thumbnail_id', '125'),
(1090, 124, '_regular_price', '1999'),
(1091, 124, 'total_sales', '0'),
(1092, 124, '_tax_status', 'taxable'),
(1093, 124, '_tax_class', ''),
(1094, 124, '_manage_stock', 'no'),
(1095, 124, '_backorders', 'no'),
(1096, 124, '_sold_individually', 'no'),
(1097, 124, '_virtual', 'no'),
(1098, 124, '_downloadable', 'no'),
(1099, 124, '_download_limit', '-1'),
(1100, 124, '_download_expiry', '-1'),
(1101, 124, '_stock', NULL),
(1102, 124, '_stock_status', 'instock'),
(1103, 124, '_wc_average_rating', '0'),
(1104, 124, '_wc_review_count', '0'),
(1105, 124, '_product_version', '5.3.0'),
(1106, 124, '_price', '1999'),
(1107, 126, '_edit_last', '1'),
(1108, 126, '_edit_lock', '1622735573:1'),
(1109, 127, '_wp_attached_file', '2021/06/gac016646-1-01-300wx300h.jpg'),
(1110, 127, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/gac016646-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"gac016646-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016646-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016646-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"gac016646-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016646-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"gac016646-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016646-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1111, 126, '_thumbnail_id', '127'),
(1112, 126, '_regular_price', '1999'),
(1113, 126, 'total_sales', '0'),
(1114, 126, '_tax_status', 'taxable'),
(1115, 126, '_tax_class', ''),
(1116, 126, '_manage_stock', 'no'),
(1117, 126, '_backorders', 'no'),
(1118, 126, '_sold_individually', 'no'),
(1119, 126, '_virtual', 'no'),
(1120, 126, '_downloadable', 'no'),
(1121, 126, '_download_limit', '-1'),
(1122, 126, '_download_expiry', '-1'),
(1123, 126, '_stock', NULL),
(1124, 126, '_stock_status', 'instock'),
(1125, 126, '_wc_average_rating', '0'),
(1126, 126, '_wc_review_count', '0'),
(1127, 126, '_product_version', '5.3.0'),
(1128, 126, '_price', '1999'),
(1129, 128, '_edit_last', '1'),
(1130, 128, '_edit_lock', '1622735617:1'),
(1131, 129, '_wp_attached_file', '2021/06/ghs005814-1-01-300wx300h.jpg'),
(1132, 129, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/ghs005814-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"ghs005814-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"ghs005814-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"ghs005814-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"ghs005814-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"ghs005814-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"ghs005814-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"ghs005814-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1133, 128, '_thumbnail_id', '129'),
(1134, 128, '_regular_price', '699'),
(1135, 128, 'total_sales', '0'),
(1136, 128, '_tax_status', 'taxable'),
(1137, 128, '_tax_class', ''),
(1138, 128, '_manage_stock', 'no'),
(1139, 128, '_backorders', 'no'),
(1140, 128, '_sold_individually', 'no'),
(1141, 128, '_virtual', 'no'),
(1142, 128, '_downloadable', 'no'),
(1143, 128, '_download_limit', '-1'),
(1144, 128, '_download_expiry', '-1'),
(1145, 128, '_stock', NULL),
(1146, 128, '_stock_status', 'instock'),
(1147, 128, '_wc_average_rating', '0'),
(1148, 128, '_wc_review_count', '0'),
(1149, 128, '_product_version', '5.3.0'),
(1150, 128, '_price', '699'),
(1151, 130, '_edit_last', '1'),
(1152, 130, '_edit_lock', '1622735655:1'),
(1153, 131, '_wp_attached_file', '2021/06/gjn019134-2-01-300wx300h.jpg'),
(1154, 131, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/gjn019134-2-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"gjn019134-2-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"gjn019134-2-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"gjn019134-2-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"gjn019134-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"gjn019134-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"gjn019134-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"gjn019134-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1155, 130, '_thumbnail_id', '131'),
(1156, 130, '_regular_price', '2299'),
(1157, 130, 'total_sales', '0'),
(1158, 130, '_tax_status', 'taxable'),
(1159, 130, '_tax_class', ''),
(1160, 130, '_manage_stock', 'no'),
(1161, 130, '_backorders', 'no'),
(1162, 130, '_sold_individually', 'no'),
(1163, 130, '_virtual', 'no'),
(1164, 130, '_downloadable', 'no'),
(1165, 130, '_download_limit', '-1'),
(1166, 130, '_download_expiry', '-1'),
(1167, 130, '_stock', NULL),
(1168, 130, '_stock_status', 'instock'),
(1169, 130, '_wc_average_rating', '0'),
(1170, 130, '_wc_review_count', '0'),
(1171, 130, '_product_version', '5.3.0'),
(1172, 130, '_price', '2299'),
(1173, 132, '_edit_last', '1'),
(1174, 132, '_edit_lock', '1622735693:1'),
(1175, 133, '_wp_attached_file', '2021/06/gjn019502-1-01-300wx300h.jpg'),
(1176, 133, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/gjn019502-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"gjn019502-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"gjn019502-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"gjn019502-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"gjn019502-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"gjn019502-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"gjn019502-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"gjn019502-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1177, 132, '_thumbnail_id', '133'),
(1178, 132, '_regular_price', '2499'),
(1179, 132, 'total_sales', '0'),
(1180, 132, '_tax_status', 'taxable'),
(1181, 132, '_tax_class', ''),
(1182, 132, '_manage_stock', 'no'),
(1183, 132, '_backorders', 'no'),
(1184, 132, '_sold_individually', 'no'),
(1185, 132, '_virtual', 'no'),
(1186, 132, '_downloadable', 'no'),
(1187, 132, '_download_limit', '-1'),
(1188, 132, '_download_expiry', '-1'),
(1189, 132, '_stock', NULL),
(1190, 132, '_stock_status', 'instock'),
(1191, 132, '_wc_average_rating', '0'),
(1192, 132, '_wc_review_count', '0'),
(1193, 132, '_product_version', '5.3.0'),
(1194, 132, '_price', '2499'),
(1195, 135, '_edit_last', '1'),
(1196, 135, '_edit_lock', '1622735976:1'),
(1197, 136, '_wp_attached_file', '2021/06/bac008663-1-01-300wx300h.jpg'),
(1198, 136, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bac008663-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bac008663-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008663-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008663-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bac008663-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008663-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bac008663-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008663-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1199, 135, '_thumbnail_id', '136'),
(1200, 135, '_regular_price', '1299'),
(1201, 135, 'total_sales', '0'),
(1202, 135, '_tax_status', 'taxable'),
(1203, 135, '_tax_class', ''),
(1204, 135, '_manage_stock', 'no'),
(1205, 135, '_backorders', 'no'),
(1206, 135, '_sold_individually', 'no'),
(1207, 135, '_virtual', 'no'),
(1208, 135, '_downloadable', 'no'),
(1209, 135, '_download_limit', '-1'),
(1210, 135, '_download_expiry', '-1'),
(1211, 135, '_stock', NULL),
(1212, 135, '_stock_status', 'instock'),
(1213, 135, '_wc_average_rating', '0'),
(1214, 135, '_wc_review_count', '0'),
(1215, 135, '_product_version', '5.3.0'),
(1216, 135, '_price', '1299'),
(1217, 137, '_edit_last', '1'),
(1218, 137, '_edit_lock', '1622736012:1'),
(1219, 138, '_wp_attached_file', '2021/06/bac008678-1-01-300wx300h.jpg'),
(1220, 138, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bac008678-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bac008678-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008678-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008678-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bac008678-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008678-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bac008678-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008678-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1221, 137, '_thumbnail_id', '138'),
(1222, 137, '_regular_price', '1299'),
(1223, 137, 'total_sales', '0'),
(1224, 137, '_tax_status', 'taxable'),
(1225, 137, '_tax_class', ''),
(1226, 137, '_manage_stock', 'no'),
(1227, 137, '_backorders', 'no'),
(1228, 137, '_sold_individually', 'no'),
(1229, 137, '_virtual', 'no'),
(1230, 137, '_downloadable', 'no'),
(1231, 137, '_download_limit', '-1'),
(1232, 137, '_download_expiry', '-1'),
(1233, 137, '_stock', NULL),
(1234, 137, '_stock_status', 'instock'),
(1235, 137, '_wc_average_rating', '0'),
(1236, 137, '_wc_review_count', '0'),
(1237, 137, '_product_version', '5.3.0'),
(1238, 137, '_price', '1299'),
(1239, 139, '_edit_last', '1'),
(1240, 139, '_edit_lock', '1622736044:1'),
(1241, 140, '_wp_attached_file', '2021/06/bac008927-1-01-300wx300h.jpg'),
(1242, 140, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bac008927-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bac008927-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008927-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008927-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bac008927-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008927-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bac008927-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008927-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1243, 139, '_thumbnail_id', '140'),
(1244, 139, '_regular_price', '1299'),
(1245, 139, 'total_sales', '0'),
(1246, 139, '_tax_status', 'taxable'),
(1247, 139, '_tax_class', ''),
(1248, 139, '_manage_stock', 'no'),
(1249, 139, '_backorders', 'no'),
(1250, 139, '_sold_individually', 'no'),
(1251, 139, '_virtual', 'no'),
(1252, 139, '_downloadable', 'no'),
(1253, 139, '_download_limit', '-1'),
(1254, 139, '_download_expiry', '-1'),
(1255, 139, '_stock', NULL),
(1256, 139, '_stock_status', 'instock'),
(1257, 139, '_wc_average_rating', '0'),
(1258, 139, '_wc_review_count', '0'),
(1259, 139, '_product_version', '5.3.0'),
(1260, 139, '_price', '1299'),
(1261, 141, '_edit_last', '1'),
(1262, 141, '_edit_lock', '1622736087:1'),
(1263, 142, '_wp_attached_file', '2021/06/bac008974-2-01-300wx300h.jpg'),
(1264, 142, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bac008974-2-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bac008974-2-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008974-2-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008974-2-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bac008974-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008974-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bac008974-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008974-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1265, 141, '_thumbnail_id', '142'),
(1266, 141, '_regular_price', '1799'),
(1267, 141, 'total_sales', '0'),
(1268, 141, '_tax_status', 'taxable'),
(1269, 141, '_tax_class', ''),
(1270, 141, '_manage_stock', 'no'),
(1271, 141, '_backorders', 'no'),
(1272, 141, '_sold_individually', 'no'),
(1273, 141, '_virtual', 'no'),
(1274, 141, '_downloadable', 'no'),
(1275, 141, '_download_limit', '-1'),
(1276, 141, '_download_expiry', '-1'),
(1277, 141, '_stock', NULL),
(1278, 141, '_stock_status', 'instock'),
(1279, 141, '_wc_average_rating', '0'),
(1280, 141, '_wc_review_count', '0'),
(1281, 141, '_product_version', '5.3.0'),
(1282, 141, '_price', '1799'),
(1283, 143, '_edit_last', '1'),
(1284, 143, '_edit_lock', '1622736119:1'),
(1285, 144, '_wp_attached_file', '2021/06/bac009119-1-01-300wx300h.jpg'),
(1286, 144, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bac009119-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bac009119-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bac009119-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bac009119-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bac009119-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac009119-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bac009119-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac009119-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1287, 143, '_thumbnail_id', '144'),
(1288, 143, '_regular_price', '1999'),
(1289, 143, 'total_sales', '0'),
(1290, 143, '_tax_status', 'taxable'),
(1291, 143, '_tax_class', ''),
(1292, 143, '_manage_stock', 'no'),
(1293, 143, '_backorders', 'no'),
(1294, 143, '_sold_individually', 'no'),
(1295, 143, '_virtual', 'no'),
(1296, 143, '_downloadable', 'no'),
(1297, 143, '_download_limit', '-1'),
(1298, 143, '_download_expiry', '-1'),
(1299, 143, '_stock', NULL),
(1300, 143, '_stock_status', 'instock'),
(1301, 143, '_wc_average_rating', '0'),
(1302, 143, '_wc_review_count', '0'),
(1303, 143, '_product_version', '5.3.0'),
(1304, 143, '_price', '1999'),
(1305, 145, '_edit_last', '1'),
(1306, 145, '_edit_lock', '1622736154:1'),
(1307, 146, '_wp_attached_file', '2021/06/bac009203-1-01-300wx300h.jpg'),
(1308, 146, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bac009203-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bac009203-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bac009203-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bac009203-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bac009203-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac009203-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bac009203-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac009203-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1309, 145, '_thumbnail_id', '146'),
(1310, 145, '_regular_price', '1999'),
(1311, 145, 'total_sales', '0'),
(1312, 145, '_tax_status', 'taxable'),
(1313, 145, '_tax_class', ''),
(1314, 145, '_manage_stock', 'no'),
(1315, 145, '_backorders', 'no'),
(1316, 145, '_sold_individually', 'no'),
(1317, 145, '_virtual', 'no'),
(1318, 145, '_downloadable', 'no'),
(1319, 145, '_download_limit', '-1'),
(1320, 145, '_download_expiry', '-1'),
(1321, 145, '_stock', NULL),
(1322, 145, '_stock_status', 'instock'),
(1323, 145, '_wc_average_rating', '0'),
(1324, 145, '_wc_review_count', '0'),
(1325, 145, '_product_version', '5.3.0'),
(1326, 145, '_price', '1999'),
(1327, 148, '_edit_last', '1'),
(1328, 148, '_edit_lock', '1622736221:1'),
(1329, 149, '_wp_attached_file', '2021/06/bac009320-1-01-300wx300h.jpg'),
(1330, 149, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bac009320-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bac009320-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bac009320-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bac009320-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bac009320-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac009320-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bac009320-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac009320-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1331, 148, '_thumbnail_id', '149'),
(1332, 148, '_regular_price', '1999'),
(1333, 148, 'total_sales', '0'),
(1334, 148, '_tax_status', 'taxable'),
(1335, 148, '_tax_class', ''),
(1336, 148, '_manage_stock', 'no'),
(1337, 148, '_backorders', 'no'),
(1338, 148, '_sold_individually', 'no'),
(1339, 148, '_virtual', 'no'),
(1340, 148, '_downloadable', 'no'),
(1341, 148, '_download_limit', '-1'),
(1342, 148, '_download_expiry', '-1'),
(1343, 148, '_stock', NULL),
(1344, 148, '_stock_status', 'instock'),
(1345, 148, '_wc_average_rating', '0'),
(1346, 148, '_wc_review_count', '0'),
(1347, 148, '_product_version', '5.3.0'),
(1348, 148, '_price', '1999'),
(1349, 151, '_wp_attached_file', '2021/06/bac009329-1-01-300wx300h.jpg'),
(1350, 151, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bac009329-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bac009329-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bac009329-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bac009329-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bac009329-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac009329-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bac009329-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac009329-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1351, 150, '_edit_last', '1'),
(1352, 150, '_thumbnail_id', '151'),
(1353, 150, '_regular_price', '1999'),
(1354, 150, 'total_sales', '0'),
(1355, 150, '_tax_status', 'taxable'),
(1356, 150, '_tax_class', ''),
(1357, 150, '_manage_stock', 'no'),
(1358, 150, '_backorders', 'no'),
(1359, 150, '_sold_individually', 'no'),
(1360, 150, '_virtual', 'no'),
(1361, 150, '_downloadable', 'no'),
(1362, 150, '_download_limit', '-1'),
(1363, 150, '_download_expiry', '-1'),
(1364, 150, '_stock', NULL),
(1365, 150, '_stock_status', 'instock'),
(1366, 150, '_wc_average_rating', '0'),
(1367, 150, '_wc_review_count', '0'),
(1368, 150, '_product_version', '5.3.0'),
(1369, 150, '_price', '1999'),
(1370, 150, '_edit_lock', '1622736247:1'),
(1371, 152, '_edit_last', '1'),
(1372, 152, '_edit_lock', '1622736289:1'),
(1373, 153, '_wp_attached_file', '2021/06/bac009521-1-01-300wx300h.jpg'),
(1374, 153, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bac009521-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bac009521-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bac009521-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bac009521-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bac009521-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac009521-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bac009521-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac009521-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1375, 152, '_thumbnail_id', '153'),
(1376, 152, 'total_sales', '0'),
(1377, 152, '_tax_status', 'taxable'),
(1378, 152, '_tax_class', ''),
(1379, 152, '_manage_stock', 'no'),
(1380, 152, '_backorders', 'no'),
(1381, 152, '_sold_individually', 'no'),
(1382, 152, '_virtual', 'no'),
(1383, 152, '_downloadable', 'no'),
(1384, 152, '_download_limit', '-1'),
(1385, 152, '_download_expiry', '-1'),
(1386, 152, '_stock', NULL),
(1387, 152, '_stock_status', 'instock'),
(1388, 152, '_wc_average_rating', '0'),
(1389, 152, '_wc_review_count', '0'),
(1390, 152, '_product_version', '5.3.0'),
(1391, 152, '_regular_price', '1999'),
(1392, 152, '_price', '1999'),
(1393, 154, '_edit_last', '1'),
(1394, 154, '_edit_lock', '1622736344:1'),
(1395, 155, '_wp_attached_file', '2021/06/bac009523-1-01-300wx300h.jpg'),
(1396, 155, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bac009523-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bac009523-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bac009523-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bac009523-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bac009523-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac009523-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bac009523-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac009523-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1397, 154, '_thumbnail_id', '155'),
(1398, 154, '_regular_price', '1599'),
(1399, 154, 'total_sales', '0'),
(1400, 154, '_tax_status', 'taxable'),
(1401, 154, '_tax_class', ''),
(1402, 154, '_manage_stock', 'no'),
(1403, 154, '_backorders', 'no'),
(1404, 154, '_sold_individually', 'no'),
(1405, 154, '_virtual', 'no'),
(1406, 154, '_downloadable', 'no'),
(1407, 154, '_download_limit', '-1'),
(1408, 154, '_download_expiry', '-1'),
(1409, 154, '_stock', NULL),
(1410, 154, '_stock_status', 'instock'),
(1411, 154, '_wc_average_rating', '0'),
(1412, 154, '_wc_review_count', '0'),
(1413, 154, '_product_version', '5.3.0'),
(1414, 154, '_price', '1599'),
(1415, 156, '_edit_last', '1'),
(1416, 156, '_edit_lock', '1622736483:1'),
(1417, 157, '_wp_attached_file', '2021/06/bkt008522-1-01-300wx300h.jpg'),
(1418, 157, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bkt008522-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bkt008522-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bkt008522-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bkt008522-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bkt008522-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bkt008522-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bkt008522-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bkt008522-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1419, 156, '_thumbnail_id', '157'),
(1420, 156, '_regular_price', '899'),
(1421, 156, 'total_sales', '0'),
(1422, 156, '_tax_status', 'taxable'),
(1423, 156, '_tax_class', ''),
(1424, 156, '_manage_stock', 'no'),
(1425, 156, '_backorders', 'no'),
(1426, 156, '_sold_individually', 'no'),
(1427, 156, '_virtual', 'no'),
(1428, 156, '_downloadable', 'no'),
(1429, 156, '_download_limit', '-1'),
(1430, 156, '_download_expiry', '-1'),
(1431, 156, '_stock', NULL),
(1432, 156, '_stock_status', 'instock'),
(1433, 156, '_wc_average_rating', '0'),
(1434, 156, '_wc_review_count', '0'),
(1435, 156, '_product_version', '5.3.0'),
(1436, 156, '_price', '899'),
(1437, 158, '_edit_last', '1'),
(1438, 158, '_edit_lock', '1622736508:1'),
(1439, 159, '_wp_attached_file', '2021/06/bpt002772-1-01-300wx300h.jpg'),
(1440, 159, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bpt002772-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bpt002772-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bpt002772-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bpt002772-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bpt002772-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bpt002772-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bpt002772-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bpt002772-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1441, 158, '_thumbnail_id', '159'),
(1442, 158, '_regular_price', '1599'),
(1443, 158, 'total_sales', '0'),
(1444, 158, '_tax_status', 'taxable'),
(1445, 158, '_tax_class', ''),
(1446, 158, '_manage_stock', 'no'),
(1447, 158, '_backorders', 'no'),
(1448, 158, '_sold_individually', 'no'),
(1449, 158, '_virtual', 'no'),
(1450, 158, '_downloadable', 'no'),
(1451, 158, '_download_limit', '-1'),
(1452, 158, '_download_expiry', '-1'),
(1453, 158, '_stock', NULL),
(1454, 158, '_stock_status', 'instock'),
(1455, 158, '_wc_average_rating', '0'),
(1456, 158, '_wc_review_count', '0'),
(1457, 158, '_product_version', '5.3.0'),
(1458, 158, '_price', '1599'),
(1459, 160, '_edit_last', '1'),
(1460, 160, '_edit_lock', '1622736564:1'),
(1461, 161, '_wp_attached_file', '2021/06/gac016382-1-01-300wx300h.jpg'),
(1462, 161, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/gac016382-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"gac016382-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016382-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016382-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"gac016382-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016382-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"gac016382-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016382-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1463, 160, '_thumbnail_id', '161'),
(1464, 160, '_regular_price', '1599'),
(1465, 160, 'total_sales', '0'),
(1466, 160, '_tax_status', 'taxable'),
(1467, 160, '_tax_class', ''),
(1468, 160, '_manage_stock', 'no'),
(1469, 160, '_backorders', 'no'),
(1470, 160, '_sold_individually', 'no'),
(1471, 160, '_virtual', 'no'),
(1472, 160, '_downloadable', 'no'),
(1473, 160, '_download_limit', '-1'),
(1474, 160, '_download_expiry', '-1'),
(1475, 160, '_stock', NULL),
(1476, 160, '_stock_status', 'instock'),
(1477, 160, '_wc_average_rating', '0'),
(1478, 160, '_wc_review_count', '0'),
(1479, 160, '_product_version', '5.3.0'),
(1480, 160, '_price', '1599'),
(1481, 162, '_edit_last', '1'),
(1482, 162, '_edit_lock', '1622736600:1'),
(1483, 163, '_wp_attached_file', '2021/06/gac016395-1-01-300wx300h.jpg'),
(1484, 163, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/gac016395-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"gac016395-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016395-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016395-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"gac016395-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016395-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"gac016395-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016395-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1485, 162, '_thumbnail_id', '163'),
(1486, 162, '_regular_price', '1599'),
(1487, 162, 'total_sales', '0'),
(1488, 162, '_tax_status', 'taxable'),
(1489, 162, '_tax_class', ''),
(1490, 162, '_manage_stock', 'no'),
(1491, 162, '_backorders', 'no'),
(1492, 162, '_sold_individually', 'no'),
(1493, 162, '_virtual', 'no'),
(1494, 162, '_downloadable', 'no'),
(1495, 162, '_download_limit', '-1'),
(1496, 162, '_download_expiry', '-1'),
(1497, 162, '_stock', NULL),
(1498, 162, '_stock_status', 'instock'),
(1499, 162, '_wc_average_rating', '0'),
(1500, 162, '_wc_review_count', '0'),
(1501, 162, '_product_version', '5.3.0'),
(1502, 162, '_price', '1599'),
(1503, 164, '_edit_last', '1'),
(1504, 164, '_edit_lock', '1622736654:1'),
(1505, 165, '_wp_attached_file', '2021/06/gac016705-1-01-300wx300h.jpg'),
(1506, 165, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/gac016705-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"gac016705-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016705-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016705-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"gac016705-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016705-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"gac016705-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016705-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1507, 164, '_thumbnail_id', '165'),
(1508, 164, '_regular_price', '1899'),
(1509, 164, 'total_sales', '0'),
(1510, 164, '_tax_status', 'taxable'),
(1511, 164, '_tax_class', ''),
(1512, 164, '_manage_stock', 'no'),
(1513, 164, '_backorders', 'no'),
(1514, 164, '_sold_individually', 'no'),
(1515, 164, '_virtual', 'no'),
(1516, 164, '_downloadable', 'no'),
(1517, 164, '_download_limit', '-1'),
(1518, 164, '_download_expiry', '-1'),
(1519, 164, '_stock', NULL),
(1520, 164, '_stock_status', 'instock'),
(1521, 164, '_wc_average_rating', '0'),
(1522, 164, '_wc_review_count', '0'),
(1523, 164, '_product_version', '5.3.0'),
(1524, 164, '_price', '1899');
INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1525, 166, '_edit_last', '1'),
(1526, 166, '_edit_lock', '1622736690:1'),
(1527, 167, '_wp_attached_file', '2021/06/gac016876-1-01-300wx300h.jpg'),
(1528, 167, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/gac016876-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"gac016876-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016876-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016876-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"gac016876-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016876-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"gac016876-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016876-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1529, 166, '_thumbnail_id', '167'),
(1530, 166, '_regular_price', '1999'),
(1531, 166, 'total_sales', '0'),
(1532, 166, '_tax_status', 'taxable'),
(1533, 166, '_tax_class', ''),
(1534, 166, '_manage_stock', 'no'),
(1535, 166, '_backorders', 'no'),
(1536, 166, '_sold_individually', 'no'),
(1537, 166, '_virtual', 'no'),
(1538, 166, '_downloadable', 'no'),
(1539, 166, '_download_limit', '-1'),
(1540, 166, '_download_expiry', '-1'),
(1541, 166, '_stock', NULL),
(1542, 166, '_stock_status', 'instock'),
(1543, 166, '_wc_average_rating', '0'),
(1544, 166, '_wc_review_count', '0'),
(1545, 166, '_product_version', '5.3.0'),
(1546, 166, '_price', '1999'),
(1547, 168, '_edit_last', '1'),
(1548, 168, '_edit_lock', '1622736727:1'),
(1549, 169, '_wp_attached_file', '2021/06/gjn019075-1-01-300wx300h.jpg'),
(1550, 169, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/gjn019075-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"gjn019075-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"gjn019075-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"gjn019075-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"gjn019075-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"gjn019075-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"gjn019075-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"gjn019075-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1551, 168, '_thumbnail_id', '169'),
(1552, 168, '_regular_price', '1499'),
(1553, 168, 'total_sales', '0'),
(1554, 168, '_tax_status', 'taxable'),
(1555, 168, '_tax_class', ''),
(1556, 168, '_manage_stock', 'no'),
(1557, 168, '_backorders', 'no'),
(1558, 168, '_sold_individually', 'no'),
(1559, 168, '_virtual', 'no'),
(1560, 168, '_downloadable', 'no'),
(1561, 168, '_download_limit', '-1'),
(1562, 168, '_download_expiry', '-1'),
(1563, 168, '_stock', NULL),
(1564, 168, '_stock_status', 'instock'),
(1565, 168, '_wc_average_rating', '0'),
(1566, 168, '_wc_review_count', '0'),
(1567, 168, '_product_version', '5.3.0'),
(1568, 168, '_price', '1499'),
(1569, 170, '_edit_last', '1'),
(1570, 170, '_edit_lock', '1622736777:1'),
(1571, 171, '_wp_attached_file', '2021/06/gse000802-1-01-300wx300h.jpg'),
(1572, 171, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/gse000802-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"gse000802-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"gse000802-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"gse000802-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"gse000802-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"gse000802-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"gse000802-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"gse000802-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1573, 170, '_thumbnail_id', '171'),
(1574, 170, '_regular_price', '1599'),
(1575, 170, 'total_sales', '0'),
(1576, 170, '_tax_status', 'taxable'),
(1577, 170, '_tax_class', ''),
(1578, 170, '_manage_stock', 'no'),
(1579, 170, '_backorders', 'no'),
(1580, 170, '_sold_individually', 'no'),
(1581, 170, '_virtual', 'no'),
(1582, 170, '_downloadable', 'no'),
(1583, 170, '_download_limit', '-1'),
(1584, 170, '_download_expiry', '-1'),
(1585, 170, '_stock', NULL),
(1586, 170, '_stock_status', 'instock'),
(1587, 170, '_wc_average_rating', '0'),
(1588, 170, '_wc_review_count', '0'),
(1589, 170, '_product_version', '5.3.0'),
(1590, 170, '_price', '1599'),
(1591, 172, '_edit_last', '1'),
(1592, 172, '_edit_lock', '1622736912:1'),
(1593, 173, '_wp_attached_file', '2021/06/gac015220-1-01-300wx300h.jpg'),
(1594, 173, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/gac015220-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"gac015220-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"gac015220-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"gac015220-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"gac015220-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"gac015220-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"gac015220-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"gac015220-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1595, 172, '_thumbnail_id', '173'),
(1596, 172, '_regular_price', '699'),
(1597, 172, 'total_sales', '0'),
(1598, 172, '_tax_status', 'taxable'),
(1599, 172, '_tax_class', ''),
(1600, 172, '_manage_stock', 'no'),
(1601, 172, '_backorders', 'no'),
(1602, 172, '_sold_individually', 'no'),
(1603, 172, '_virtual', 'no'),
(1604, 172, '_downloadable', 'no'),
(1605, 172, '_download_limit', '-1'),
(1606, 172, '_download_expiry', '-1'),
(1607, 172, '_stock', NULL),
(1608, 172, '_stock_status', 'instock'),
(1609, 172, '_wc_average_rating', '0'),
(1610, 172, '_wc_review_count', '0'),
(1611, 172, '_product_version', '5.3.0'),
(1612, 172, '_price', '699'),
(1613, 174, '_edit_last', '1'),
(1614, 174, '_edit_lock', '1622736963:1'),
(1615, 175, '_wp_attached_file', '2021/06/bac008635-1-01-300wx300h.jpg'),
(1616, 175, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:400;s:6:\"height\";i:600;s:4:\"file\";s:36:\"2021/06/bac008635-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bac008635-1-01-300wx300h-200x300.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008635-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008635-1-01-300wx300h-400x510.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bac008635-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008635-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bac008635-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008635-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1617, 174, '_thumbnail_id', '175'),
(1618, 174, '_regular_price', '699'),
(1619, 174, 'total_sales', '0'),
(1620, 174, '_tax_status', 'taxable'),
(1621, 174, '_tax_class', ''),
(1622, 174, '_manage_stock', 'no'),
(1623, 174, '_backorders', 'no'),
(1624, 174, '_sold_individually', 'no'),
(1625, 174, '_virtual', 'no'),
(1626, 174, '_downloadable', 'no'),
(1627, 174, '_download_limit', '-1'),
(1628, 174, '_download_expiry', '-1'),
(1629, 174, '_stock', NULL),
(1630, 174, '_stock_status', 'instock'),
(1631, 174, '_wc_average_rating', '0'),
(1632, 174, '_wc_review_count', '0'),
(1633, 174, '_product_version', '5.3.0'),
(1634, 174, '_price', '699'),
(1635, 178, '_edit_last', '1'),
(1636, 178, '_edit_lock', '1622737015:1'),
(1637, 179, '_wp_attached_file', '2021/06/gac016893-1-01-300wx300h.jpg'),
(1638, 179, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/gac016893-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"gac016893-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016893-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016893-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"gac016893-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016893-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"gac016893-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"gac016893-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1639, 178, '_thumbnail_id', '179'),
(1640, 178, '_regular_price', '899'),
(1641, 178, 'total_sales', '0'),
(1642, 178, '_tax_status', 'taxable'),
(1643, 178, '_tax_class', ''),
(1644, 178, '_manage_stock', 'no'),
(1645, 178, '_backorders', 'no'),
(1646, 178, '_sold_individually', 'no'),
(1647, 178, '_virtual', 'no'),
(1648, 178, '_downloadable', 'no'),
(1649, 178, '_download_limit', '-1'),
(1650, 178, '_download_expiry', '-1'),
(1651, 178, '_stock', NULL),
(1652, 178, '_stock_status', 'instock'),
(1653, 178, '_wc_average_rating', '0'),
(1654, 178, '_wc_review_count', '0'),
(1655, 178, '_product_version', '5.3.0'),
(1656, 178, '_price', '899'),
(1657, 180, '_edit_last', '1'),
(1658, 180, '_edit_lock', '1622737059:1'),
(1659, 181, '_wp_attached_file', '2021/06/gdr023818-2-01-300wx300h.jpg'),
(1660, 181, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/gdr023818-2-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"gdr023818-2-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"gdr023818-2-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"gdr023818-2-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"gdr023818-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"gdr023818-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"gdr023818-2-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"gdr023818-2-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1661, 180, '_thumbnail_id', '181'),
(1662, 180, '_regular_price', '699'),
(1663, 180, 'total_sales', '0'),
(1664, 180, '_tax_status', 'taxable'),
(1665, 180, '_tax_class', ''),
(1666, 180, '_manage_stock', 'no'),
(1667, 180, '_backorders', 'no'),
(1668, 180, '_sold_individually', 'no'),
(1669, 180, '_virtual', 'no'),
(1670, 180, '_downloadable', 'no'),
(1671, 180, '_download_limit', '-1'),
(1672, 180, '_download_expiry', '-1'),
(1673, 180, '_stock', NULL),
(1674, 180, '_stock_status', 'instock'),
(1675, 180, '_wc_average_rating', '0'),
(1676, 180, '_wc_review_count', '0'),
(1677, 180, '_product_version', '5.3.0'),
(1678, 180, '_price', '699'),
(1679, 183, '_edit_last', '1'),
(1680, 183, '_edit_lock', '1622737136:1'),
(1681, 184, '_wp_attached_file', '2021/06/gjn019025-1-01-300wx300h.jpg'),
(1682, 184, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/gjn019025-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"gjn019025-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"gjn019025-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"gjn019025-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"gjn019025-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"gjn019025-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"gjn019025-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"gjn019025-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1683, 183, '_thumbnail_id', '184'),
(1684, 183, '_regular_price', '999'),
(1685, 183, 'total_sales', '0'),
(1686, 183, '_tax_status', 'taxable'),
(1687, 183, '_tax_class', ''),
(1688, 183, '_manage_stock', 'no'),
(1689, 183, '_backorders', 'no'),
(1690, 183, '_sold_individually', 'no'),
(1691, 183, '_virtual', 'no'),
(1692, 183, '_downloadable', 'no'),
(1693, 183, '_download_limit', '-1'),
(1694, 183, '_download_expiry', '-1'),
(1695, 183, '_stock', NULL),
(1696, 183, '_stock_status', 'instock'),
(1697, 183, '_wc_average_rating', '0'),
(1698, 183, '_wc_review_count', '0'),
(1699, 183, '_product_version', '5.3.0'),
(1700, 183, '_price', '999'),
(1701, 185, '_edit_last', '1'),
(1702, 185, '_edit_lock', '1622737173:1'),
(1703, 186, '_wp_attached_file', '2021/06/gkt014320-1-01-300wx300h.jpg'),
(1704, 186, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/gkt014320-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"gkt014320-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"gkt014320-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"gkt014320-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"gkt014320-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"gkt014320-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"gkt014320-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"gkt014320-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1705, 185, '_thumbnail_id', '186'),
(1706, 185, '_regular_price', '599'),
(1707, 185, 'total_sales', '0'),
(1708, 185, '_tax_status', 'taxable'),
(1709, 185, '_tax_class', ''),
(1710, 185, '_manage_stock', 'no'),
(1711, 185, '_backorders', 'no'),
(1712, 185, '_sold_individually', 'no'),
(1713, 185, '_virtual', 'no'),
(1714, 185, '_downloadable', 'no'),
(1715, 185, '_download_limit', '-1'),
(1716, 185, '_download_expiry', '-1'),
(1717, 185, '_stock', NULL),
(1718, 185, '_stock_status', 'instock'),
(1719, 185, '_wc_average_rating', '0'),
(1720, 185, '_wc_review_count', '0'),
(1721, 185, '_product_version', '5.3.0'),
(1722, 185, '_price', '599'),
(1723, 188, '_edit_last', '1'),
(1724, 188, '_edit_lock', '1622737268:1'),
(1725, 189, '_wp_attached_file', '2021/06/gsh008072-1-01-300wx300h.jpg'),
(1726, 189, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/gsh008072-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"gsh008072-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"gsh008072-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"gsh008072-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"gsh008072-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"gsh008072-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"gsh008072-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"gsh008072-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1727, 188, '_thumbnail_id', '189'),
(1728, 188, '_regular_price', '699'),
(1729, 188, 'total_sales', '0'),
(1730, 188, '_tax_status', 'taxable'),
(1731, 188, '_tax_class', ''),
(1732, 188, '_manage_stock', 'no'),
(1733, 188, '_backorders', 'no'),
(1734, 188, '_sold_individually', 'no'),
(1735, 188, '_virtual', 'no'),
(1736, 188, '_downloadable', 'no'),
(1737, 188, '_download_limit', '-1'),
(1738, 188, '_download_expiry', '-1'),
(1739, 188, '_stock', NULL),
(1740, 188, '_stock_status', 'instock'),
(1741, 188, '_wc_average_rating', '0'),
(1742, 188, '_wc_review_count', '0'),
(1743, 188, '_product_version', '5.3.0'),
(1744, 188, '_price', '699'),
(1745, 190, '_edit_last', '1'),
(1746, 190, '_edit_lock', '1622737315:1'),
(1747, 191, '_wp_attached_file', '2021/06/bac008612-1-01-300wx300h.jpg'),
(1748, 191, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bac008612-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bac008612-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008612-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008612-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bac008612-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008612-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bac008612-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008612-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1749, 190, '_thumbnail_id', '191'),
(1750, 190, '_regular_price', '599'),
(1751, 190, 'total_sales', '0'),
(1752, 190, '_tax_status', 'taxable'),
(1753, 190, '_tax_class', ''),
(1754, 190, '_manage_stock', 'no'),
(1755, 190, '_backorders', 'no'),
(1756, 190, '_sold_individually', 'no'),
(1757, 190, '_virtual', 'no'),
(1758, 190, '_downloadable', 'no'),
(1759, 190, '_download_limit', '-1'),
(1760, 190, '_download_expiry', '-1'),
(1761, 190, '_stock', NULL),
(1762, 190, '_stock_status', 'instock'),
(1763, 190, '_wc_average_rating', '0'),
(1764, 190, '_wc_review_count', '0'),
(1765, 190, '_product_version', '5.3.0'),
(1766, 190, '_price', '599'),
(1767, 192, '_edit_last', '1'),
(1768, 192, '_edit_lock', '1622737417:1'),
(1769, 193, '_wp_attached_file', '2021/06/bac008627-1-01-300wx300h.jpg'),
(1770, 193, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bac008627-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bac008627-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008627-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008627-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bac008627-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008627-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bac008627-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008627-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1771, 192, '_thumbnail_id', '193'),
(1772, 192, '_regular_price', '699'),
(1773, 192, 'total_sales', '0'),
(1774, 192, '_tax_status', 'taxable'),
(1775, 192, '_tax_class', ''),
(1776, 192, '_manage_stock', 'no'),
(1777, 192, '_backorders', 'no'),
(1778, 192, '_sold_individually', 'no'),
(1779, 192, '_virtual', 'no'),
(1780, 192, '_downloadable', 'no'),
(1781, 192, '_download_limit', '-1'),
(1782, 192, '_download_expiry', '-1'),
(1783, 192, '_stock', NULL),
(1784, 192, '_stock_status', 'instock'),
(1785, 192, '_wc_average_rating', '0'),
(1786, 192, '_wc_review_count', '0'),
(1787, 192, '_product_version', '5.3.0'),
(1788, 192, '_price', '699'),
(1789, 194, '_edit_last', '1'),
(1790, 194, '_edit_lock', '1622737447:1'),
(1791, 195, '_wp_attached_file', '2021/06/bac008712-1-01-300wx300h.jpg'),
(1792, 195, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bac008712-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bac008712-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008712-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008712-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bac008712-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008712-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bac008712-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bac008712-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1793, 194, '_thumbnail_id', '195'),
(1794, 194, '_regular_price', '899'),
(1795, 194, 'total_sales', '0'),
(1796, 194, '_tax_status', 'taxable'),
(1797, 194, '_tax_class', ''),
(1798, 194, '_manage_stock', 'no'),
(1799, 194, '_backorders', 'no'),
(1800, 194, '_sold_individually', 'no'),
(1801, 194, '_virtual', 'no'),
(1802, 194, '_downloadable', 'no'),
(1803, 194, '_download_limit', '-1'),
(1804, 194, '_download_expiry', '-1'),
(1805, 194, '_stock', NULL),
(1806, 194, '_stock_status', 'instock'),
(1807, 194, '_wc_average_rating', '0'),
(1808, 194, '_wc_review_count', '0'),
(1809, 194, '_product_version', '5.3.0'),
(1810, 194, '_price', '899'),
(1811, 199, '_edit_last', '1'),
(1812, 199, '_edit_lock', '1622737516:1'),
(1813, 200, '_wp_attached_file', '2021/06/gcv000269-1-01-300wx300h.jpg'),
(1814, 200, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/gcv000269-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"gcv000269-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"gcv000269-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"gcv000269-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"gcv000269-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"gcv000269-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"gcv000269-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"gcv000269-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1815, 199, '_thumbnail_id', '200'),
(1816, 199, '_regular_price', '599'),
(1817, 199, 'total_sales', '0'),
(1818, 199, '_tax_status', 'taxable'),
(1819, 199, '_tax_class', ''),
(1820, 199, '_manage_stock', 'no'),
(1821, 199, '_backorders', 'no'),
(1822, 199, '_sold_individually', 'no'),
(1823, 199, '_virtual', 'no'),
(1824, 199, '_downloadable', 'no'),
(1825, 199, '_download_limit', '-1'),
(1826, 199, '_download_expiry', '-1'),
(1827, 199, '_stock', NULL),
(1828, 199, '_stock_status', 'instock'),
(1829, 199, '_wc_average_rating', '0'),
(1830, 199, '_wc_review_count', '0'),
(1831, 199, '_product_version', '5.3.0'),
(1832, 199, '_price', '599'),
(1833, 201, '_edit_last', '1'),
(1834, 201, '_edit_lock', '1622737650:1'),
(1835, 202, '_wp_attached_file', '2021/06/bse000492-1-01-300wx300h.jpg'),
(1836, 202, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:471;s:6:\"height\";i:599;s:4:\"file\";s:36:\"2021/06/bse000492-1-01-300wx300h.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bse000492-1-01-300wx300h-236x300.jpg\";s:5:\"width\";i:236;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bse000492-1-01-300wx300h-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"bse000492-1-01-300wx300h-471x510.jpg\";s:5:\"width\";i:471;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"bse000492-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"bse000492-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"bse000492-1-01-300wx300h-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"bse000492-1-01-300wx300h-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:15:\"© Gloria Jeans\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1837, 201, '_thumbnail_id', '202'),
(1838, 201, '_regular_price', '849'),
(1839, 201, 'total_sales', '0'),
(1840, 201, '_tax_status', 'taxable'),
(1841, 201, '_tax_class', ''),
(1842, 201, '_manage_stock', 'no'),
(1843, 201, '_backorders', 'no'),
(1844, 201, '_sold_individually', 'no'),
(1845, 201, '_virtual', 'no'),
(1846, 201, '_downloadable', 'no'),
(1847, 201, '_download_limit', '-1'),
(1848, 201, '_download_expiry', '-1'),
(1849, 201, '_stock', NULL),
(1850, 201, '_stock_status', 'instock'),
(1851, 201, '_wc_average_rating', '0'),
(1852, 201, '_wc_review_count', '0'),
(1853, 201, '_product_version', '5.3.0'),
(1854, 201, '_price', '849'),
(1855, 203, '_menu_item_type', 'post_type'),
(1856, 203, '_menu_item_menu_item_parent', '0'),
(1857, 203, '_menu_item_object_id', '37'),
(1858, 203, '_menu_item_object', 'page'),
(1859, 203, '_menu_item_target', ''),
(1860, 203, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1861, 203, '_menu_item_xfn', ''),
(1862, 203, '_menu_item_url', ''),
(1864, 204, '_menu_item_type', 'post_type'),
(1865, 204, '_menu_item_menu_item_parent', '0'),
(1866, 204, '_menu_item_object_id', '35'),
(1867, 204, '_menu_item_object', 'page'),
(1868, 204, '_menu_item_target', ''),
(1869, 204, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1870, 204, '_menu_item_xfn', ''),
(1871, 204, '_menu_item_url', ''),
(1873, 205, '_menu_item_type', 'post_type'),
(1874, 205, '_menu_item_menu_item_parent', '0'),
(1875, 205, '_menu_item_object_id', '32'),
(1876, 205, '_menu_item_object', 'page'),
(1877, 205, '_menu_item_target', ''),
(1878, 205, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1879, 205, '_menu_item_xfn', ''),
(1880, 205, '_menu_item_url', ''),
(1882, 206, '_order_key', 'wc_order_kTyLuI2wujVpB'),
(1883, 206, '_customer_user', '1'),
(1884, 206, '_payment_method', 'cod'),
(1885, 206, '_payment_method_title', 'Оплата при доставке'),
(1886, 206, '_customer_ip_address', '46.61.99.57'),
(1887, 206, '_customer_user_agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.72 YaBrowser/21.5.1.330 Yowser/2.5 Safari/537.36'),
(1888, 206, '_created_via', 'checkout'),
(1889, 206, '_cart_hash', '5d79f87ed088d27ea1183cd7742470ca'),
(1890, 206, '_billing_first_name', 'Владимир'),
(1891, 206, '_billing_last_name', 'Ткачёв'),
(1892, 206, '_billing_address_1', 'Криворожская 61'),
(1893, 206, '_billing_address_2', 'кв 87, 4 этаж, 5 подъезд'),
(1894, 206, '_billing_city', 'Ростов-на-Дону'),
(1895, 206, '_billing_state', 'Ростовская область'),
(1896, 206, '_billing_postcode', '340000'),
(1897, 206, '_billing_country', 'RU'),
(1898, 206, '_billing_email', 'gartonot62@gmail.com'),
(1899, 206, '_billing_phone', '8(928) 442-02-67'),
(1900, 206, '_order_currency', 'RUB'),
(1901, 206, '_cart_discount', '0'),
(1902, 206, '_cart_discount_tax', '0'),
(1903, 206, '_order_shipping', '0'),
(1904, 206, '_order_shipping_tax', '0'),
(1905, 206, '_order_tax', '0'),
(1906, 206, '_order_total', '799'),
(1907, 206, '_order_version', '5.3.0'),
(1908, 206, '_prices_include_tax', 'no'),
(1909, 206, '_billing_address_index', 'Владимир Ткачёв  Криворожская 61 кв 87, 4 этаж, 5 подъезд Ростов-на-Дону Ростовская область 340000 RU gartonot62@gmail.com 8(928) 442-02-67'),
(1910, 206, '_shipping_address_index', '        '),
(1911, 206, 'is_vat_exempt', 'no'),
(1912, 206, '_download_permissions_granted', 'yes'),
(1913, 206, '_recorded_sales', 'yes'),
(1914, 206, '_recorded_coupon_usage_counts', 'yes'),
(1915, 206, '_order_stock_reduced', 'yes'),
(1916, 206, '_new_order_email_sent', 'true'),
(1917, 206, '_edit_lock', '1622752047:1'),
(1918, 206, '_edit_last', '1'),
(1919, 206, '_date_completed', '1622752190'),
(1920, 206, '_date_paid', '1622752190'),
(1921, 206, '_paid_date', '2021-06-03 23:29:50'),
(1922, 206, '_completed_date', '2021-06-03 23:29:50'),
(1925, 209, '_wp_attached_file', '2021/06/about-company.jpg'),
(1926, 209, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1510;s:6:\"height\";i:969;s:4:\"file\";s:25:\"2021/06/about-company.jpg\";s:5:\"sizes\";a:11:{s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"about-company-300x193.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:193;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:26:\"about-company-1024x657.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:657;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"about-company-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:25:\"about-company-768x493.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:493;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:25:\"about-company-825x510.jpg\";s:5:\"width\";i:825;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:25:\"about-company-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:25:\"about-company-600x385.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:385;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:25:\"about-company-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:25:\"about-company-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:25:\"about-company-600x385.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:385;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:25:\"about-company-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1927, 32, '_thumbnail_id', '209'),
(1928, 215, '_wp_attached_file', '2021/06/image.jpg'),
(1929, 215, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1511;s:6:\"height\";i:950;s:4:\"file\";s:17:\"2021/06/image.jpg\";s:5:\"sizes\";a:11:{s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"image-300x189.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:189;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:18:\"image-1024x644.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:644;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"image-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:17:\"image-768x483.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:483;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:17:\"image-825x510.jpg\";s:5:\"width\";i:825;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:17:\"image-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:17:\"image-600x377.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:377;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:17:\"image-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:17:\"image-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:17:\"image-600x377.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:377;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:17:\"image-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1930, 35, '_thumbnail_id', '215'),
(1931, 220, '_order_key', 'wc_order_mWZHeCpMvd4NR'),
(1932, 220, '_customer_user', '0'),
(1933, 220, '_payment_method', 'cod'),
(1934, 220, '_payment_method_title', 'Оплата при доставке'),
(1935, 220, '_customer_ip_address', '5.139.158.77'),
(1936, 220, '_customer_user_agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.101 Safari/537.36'),
(1937, 220, '_created_via', 'checkout'),
(1938, 220, '_cart_hash', '5d79f87ed088d27ea1183cd7742470ca'),
(1939, 220, '_billing_first_name', 'Илья'),
(1940, 220, '_billing_last_name', 'Гусев'),
(1941, 220, '_billing_address_1', '14'),
(1942, 220, '_billing_address_2', '88'),
(1943, 220, '_billing_city', 'Ркси'),
(1944, 220, '_billing_state', 'Ростовская'),
(1945, 220, '_billing_postcode', '345'),
(1946, 220, '_billing_country', 'RU'),
(1947, 220, '_billing_email', 'provero4ka@mail.ru'),
(1948, 220, '_billing_phone', '88005553535'),
(1949, 220, '_order_currency', 'RUB'),
(1950, 220, '_cart_discount', '0'),
(1951, 220, '_cart_discount_tax', '0'),
(1952, 220, '_order_shipping', '0'),
(1953, 220, '_order_shipping_tax', '0'),
(1954, 220, '_order_tax', '0'),
(1955, 220, '_order_total', '799'),
(1956, 220, '_order_version', '5.3.0'),
(1957, 220, '_prices_include_tax', 'no'),
(1958, 220, '_billing_address_index', 'Илья Гусев  14 88 Ркси Ростовская 345 RU provero4ka@mail.ru 88005553535'),
(1959, 220, '_shipping_address_index', '        '),
(1960, 220, 'is_vat_exempt', 'no'),
(1961, 220, '_download_permissions_granted', 'yes'),
(1962, 220, '_recorded_sales', 'yes'),
(1963, 220, '_recorded_coupon_usage_counts', 'yes'),
(1964, 220, '_order_stock_reduced', 'yes'),
(1965, 220, '_new_order_email_sent', 'true'),
(1966, 221, '_order_key', 'wc_order_iQOCPLlNzDZAK'),
(1967, 221, '_customer_user', '0'),
(1968, 221, '_payment_method', 'cod'),
(1969, 221, '_payment_method_title', 'Оплата при доставке'),
(1970, 221, '_customer_ip_address', '31.23.174.202'),
(1971, 221, '_customer_user_agent', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36'),
(1972, 221, '_created_via', 'checkout'),
(1973, 221, '_cart_hash', '5d79f87ed088d27ea1183cd7742470ca'),
(1974, 221, '_billing_first_name', 'ehr'),
(1975, 221, '_billing_last_name', 'sdg'),
(1976, 221, '_billing_address_1', 'e'),
(1977, 221, '_billing_address_2', 'ukgjb'),
(1978, 221, '_billing_city', 'khcm'),
(1979, 221, '_billing_state', 'df'),
(1980, 221, '_billing_postcode', '777'),
(1981, 221, '_billing_country', 'RU'),
(1982, 221, '_billing_email', 'sff@mail.ru'),
(1983, 221, '_billing_phone', '43434343'),
(1984, 221, '_order_currency', 'RUB'),
(1985, 221, '_cart_discount', '0'),
(1986, 221, '_cart_discount_tax', '0'),
(1987, 221, '_order_shipping', '0'),
(1988, 221, '_order_shipping_tax', '0'),
(1989, 221, '_order_tax', '0'),
(1990, 221, '_order_total', '799'),
(1991, 221, '_order_version', '5.3.0'),
(1992, 221, '_prices_include_tax', 'no'),
(1993, 221, '_billing_address_index', 'ehr sdg  e ukgjb khcm df 777 RU sff@mail.ru 43434343'),
(1994, 221, '_shipping_address_index', '        '),
(1995, 221, 'is_vat_exempt', 'no'),
(1996, 221, '_download_permissions_granted', 'yes'),
(1997, 221, '_recorded_sales', 'yes'),
(1998, 221, '_recorded_coupon_usage_counts', 'yes'),
(1999, 221, '_order_stock_reduced', 'yes'),
(2000, 221, '_new_order_email_sent', 'true'),
(2001, 221, '_edit_lock', '1623800683:1'),
(2002, 221, '_wp_trash_meta_status', 'wc-processing'),
(2003, 221, '_wp_trash_meta_time', '1623800827'),
(2004, 221, '_wp_desired_post_slug', 'zakaz-ndash-15-jun-2021-v-21-06'),
(2005, 221, '_wp_trash_meta_comments_status', 'a:1:{i:7;s:1:\"1\";}'),
(2006, 22, '_edit_lock', '1623800744:1'),
(2007, 22, '_wp_trash_meta_status', 'wc-processing'),
(2008, 22, '_wp_trash_meta_time', '1623800889'),
(2009, 22, '_wp_desired_post_slug', 'zakaz-ndash-01-jun-2021-v-19-08'),
(2010, 22, '_wp_trash_meta_comments_status', 'a:1:{i:2;s:1:\"1\";}'),
(2011, 22, '_wp_trash_meta_status', 'wc-processing'),
(2012, 22, '_wp_trash_meta_time', '1623800889'),
(2013, 22, '_wp_trash_meta_comments_status', 'a:1:{i:2;s:12:\"post-trashed\";}'),
(2014, 220, '_edit_lock', '1623800766:1'),
(2015, 220, '_wp_trash_meta_status', 'wc-processing'),
(2016, 220, '_wp_trash_meta_time', '1623800910'),
(2017, 220, '_wp_desired_post_slug', 'zakaz-ndash-15-jun-2021-v-15-32'),
(2018, 220, '_wp_trash_meta_comments_status', 'a:1:{i:6;s:1:\"1\";}');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_posts`
--
-- Создание: Июн 01 2021 г., 08:28
--

DROP TABLE IF EXISTS `wp_posts`;
CREATE TABLE `wp_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2021-04-08 10:30:00', '2021-04-08 07:30:00', '<!-- wp:paragraph -->\n<p>Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите ее, затем начинайте создавать!</p>\n<!-- /wp:paragraph -->', 'Привет, мир!', '', 'publish', 'open', 'open', '', 'privet-mir', '', '', '2021-04-08 10:30:00', '2021-04-08 07:30:00', '', 0, 'http://manufacturer-cloth.ru/?p=1', 0, 'post', '', 0),
(2, 1, '2021-04-08 10:30:00', '2021-04-08 07:30:00', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице &laquo;Детали&raquo; владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером &#8212; подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...или так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Компания &laquo;Штучки XYZ&raquo; была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href=\"http://manufacturer-cloth.ru/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Пример страницы', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2021-04-08 10:30:00', '2021-04-08 07:30:00', '', 0, 'http://manufacturer-cloth.ru/?page_id=2', 0, 'page', '', 0),
(3, 1, '2021-04-08 10:30:00', '2021-04-08 07:30:00', '<!-- wp:heading --><h2>Кто мы</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Наш адрес сайта: http://manufacturer-cloth.ru.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Комментарии</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Если посетитель оставляет комментарий на сайте, мы собираем данные указанные в форме комментария, а также IP адрес посетителя и данные user-agent браузера с целью определения спама.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Анонимизированная строка создаваемая из вашего адреса email (\"хеш\") может предоставляться сервису Gravatar, чтобы определить используете ли вы его. Политика конфиденциальности Gravatar доступна здесь: https://automattic.com/privacy/ . После одобрения комментария ваше изображение профиля будет видимым публично в контексте вашего комментария.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Медиафайлы</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Если вы зарегистрированный пользователь и загружаете фотографии на сайт, вам возможно следует избегать загрузки изображений с метаданными EXIF, так как они могут содержать данные вашего месторасположения по GPS. Посетители могут извлечь эту информацию скачав изображения с сайта.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куки</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Если вы оставляете комментарий на нашем сайте, вы можете включить сохранение вашего имени, адреса email и вебсайта в куки. Это делается для вашего удобства, чтобы не заполнять данные снова при повторном комментировании. Эти куки хранятся в течение одного года.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Если у вас есть учетная запись на сайте и вы войдете в неё, мы установим временный куки для определения поддержки куки вашим браузером, куки не содержит никакой личной информации и удаляется при закрытии вашего браузера.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При входе в учетную запись мы также устанавливаем несколько куки с данными входа и настройками экрана. Куки входа хранятся в течение двух дней, куки с настройками экрана - год. Если вы выберете возможность \"Запомнить меня\", данные о входе будут сохраняться в течение двух недель. При выходе из учетной записи куки входа будут удалены.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При редактировании или публикации статьи в браузере будет сохранен дополнительный куки, он не содержит персональных данных и содержит только ID записи отредактированной вами, истекает через 1 день.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Встраиваемое содержимое других вебсайтов</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Статьи на этом сайте могут включать встраиваемое содержимое (например видео, изображения, статьи и др.), подобное содержимое ведет себя так же, как если бы посетитель зашел на другой сайт.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Эти сайты могут собирать данные о вас, использовать куки, внедрять дополнительное отслеживание третьей стороной и следить за вашим взаимодействием с внедренным содержимым, включая отслеживание взаимодействия, если у вас есть учетная запись и вы авторизовались на том сайте.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>С кем мы делимся вашими данными</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Если вы запросите сброс пароля, ваш IP будет указан в email-сообщении о сбросе.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Как долго мы храним ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Если вы оставляете комментарий, то сам комментарий и его метаданные сохраняются неопределенно долго. Это делается для того, чтобы определять и одобрять последующие комментарии автоматически, вместо помещения их в очередь на одобрение.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Для пользователей с регистрацией на нашем сайте мы храним ту личную информацию, которую они указывают в своем профиле. Все пользователи могут видеть, редактировать или удалить свою информацию из профиля в любое время (кроме имени пользователя). Администрация вебсайта также может видеть и изменять эту информацию.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Какие у вас права на ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>При наличии учетной записи на сайте или если вы оставляли комментарии, то вы можете запросить файл экспорта персональных данных, которые мы сохранили о вас, включая предоставленные вами данные. Вы также можете запросить удаление этих данных, это не включает данные, которые мы обязаны хранить в административных целях, по закону или целях безопасности.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куда мы отправляем ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Комментарии пользователей могут проверяться автоматическим сервисом определения спама.</p><!-- /wp:paragraph -->', 'Политика конфиденциальности', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2021-04-08 10:30:00', '2021-04-08 07:30:00', '', 0, 'http://manufacturer-cloth.ru/?page_id=3', 0, 'page', '', 0),
(5, 1, '2021-06-01 14:16:00', '2021-06-01 11:16:00', '', 'woocommerce-placeholder', '', 'inherit', 'open', 'closed', '', 'woocommerce-placeholder', '', '', '2021-06-01 14:16:00', '2021-06-01 11:16:00', '', 0, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/woocommerce-placeholder.png', 0, 'attachment', 'image/png', 0),
(6, 1, '2021-06-01 14:16:00', '2021-06-01 11:16:00', '', 'Магазин', '', 'publish', 'closed', 'closed', '', 'shop', '', '', '2021-06-01 14:16:00', '2021-06-01 11:16:00', '', 0, 'https://manufacturer-cloth.ru/shop', 0, 'page', '', 0),
(7, 1, '2021-06-01 14:16:00', '2021-06-01 11:16:00', '<!-- wp:shortcode -->[woocommerce_cart]<!-- /wp:shortcode -->', 'Корзина', '', 'publish', 'closed', 'closed', '', 'cart', '', '', '2021-06-01 14:16:00', '2021-06-01 11:16:00', '', 0, 'https://manufacturer-cloth.ru/cart', 0, 'page', '', 0),
(8, 1, '2021-06-01 14:16:00', '2021-06-01 11:16:00', '<!-- wp:shortcode -->[woocommerce_checkout]<!-- /wp:shortcode -->', 'Оформление заказа', '', 'publish', 'closed', 'closed', '', 'checkout', '', '', '2021-06-01 14:16:00', '2021-06-01 11:16:00', '', 0, 'https://manufacturer-cloth.ru/checkout', 0, 'page', '', 0),
(9, 1, '2021-06-01 14:16:00', '2021-06-01 11:16:00', '<!-- wp:shortcode -->[woocommerce_my_account]<!-- /wp:shortcode -->', 'Мой аккаунт', '', 'publish', 'closed', 'closed', '', 'my-account', '', '', '2021-06-01 14:16:00', '2021-06-01 11:16:00', '', 0, 'https://manufacturer-cloth.ru/my-account', 0, 'page', '', 0),
(10, 1, '2021-06-01 14:24:06', '2021-06-01 11:24:06', 'Описание жилета', 'ЖИЛЕТ С КАПЮШОНОМ ДЛЯ МАЛЬЧИКОВ', 'Краткое Описание жилета', 'publish', 'open', 'closed', '', 'zhilet-s-kapjushonom-dlja-malchikov', '', '', '2021-06-01 14:24:06', '2021-06-01 11:24:06', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=10', 0, 'product', '', 0),
(11, 1, '2021-06-01 14:22:59', '2021-06-01 11:22:59', '', 'Image2', '', 'inherit', 'open', 'closed', '', 'image2', '', '', '2021-06-01 14:22:59', '2021-06-01 11:22:59', '', 10, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/image2.png', 0, 'attachment', 'image/png', 0),
(12, 1, '2021-06-01 14:31:44', '2021-06-01 11:31:44', '{\n    \"twentyfifteen::nav_menu_locations[primary]\": {\n        \"value\": -1725950241090584600,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-01 11:30:56\"\n    },\n    \"nav_menu[-1725950241090584600]\": {\n        \"value\": {\n            \"name\": \"\\u041e\\u0441\\u043d\\u043e\\u0432\\u043d\\u043e\\u0435\",\n            \"description\": \"\",\n            \"parent\": 0,\n            \"auto_add\": false\n        },\n        \"type\": \"nav_menu\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-01 11:30:56\"\n    },\n    \"nav_menu_item[-1902335046213054500]\": {\n        \"value\": {\n            \"object_id\": 16,\n            \"object\": \"product_cat\",\n            \"menu_item_parent\": 0,\n            \"position\": 1,\n            \"type\": \"taxonomy\",\n            \"title\": \"\\u041c\\u0443\\u0436\\u0441\\u043a\\u0438\\u0435\",\n            \"url\": \"https://manufacturer-cloth.ru/product-category/muzhskie\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"\\u041c\\u0443\\u0436\\u0441\\u043a\\u0438\\u0435\",\n            \"nav_menu_term_id\": -1725950241090584600,\n            \"_invalid\": false,\n            \"type_label\": \"\\u041a\\u0430\\u0442\\u0435\\u0433\\u043e\\u0440\\u0438\\u044f\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-01 11:31:12\"\n    },\n    \"nav_menu_item[-2030616747788621800]\": {\n        \"value\": {\n            \"object_id\": 10,\n            \"object\": \"product\",\n            \"menu_item_parent\": -1902335046213054500,\n            \"position\": 2,\n            \"type\": \"post_type\",\n            \"title\": \"\\u0416\\u0418\\u041b\\u0415\\u0422 \\u0421 \\u041a\\u0410\\u041f\\u042e\\u0428\\u041e\\u041d\\u041e\\u041c \\u0414\\u041b\\u042f \\u041c\\u0410\\u041b\\u042c\\u0427\\u0418\\u041a\\u041e\\u0412\",\n            \"url\": \"https://manufacturer-cloth.ru/product/zhilet-s-kapjushonom-dlja-malchikov\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"\\u0416\\u0418\\u041b\\u0415\\u0422 \\u0421 \\u041a\\u0410\\u041f\\u042e\\u0428\\u041e\\u041d\\u041e\\u041c \\u0414\\u041b\\u042f \\u041c\\u0410\\u041b\\u042c\\u0427\\u0418\\u041a\\u041e\\u0412\",\n            \"nav_menu_term_id\": -1725950241090584600,\n            \"_invalid\": false,\n            \"type_label\": \"\\u0422\\u043e\\u0432\\u0430\\u0440\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-01 11:31:30\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'e1cb24d6-a3df-427e-b517-415cf6878e25', '', '', '2021-06-01 14:31:44', '2021-06-01 11:31:44', '', 0, 'https://manufacturer-cloth.ru/?p=12', 0, 'customize_changeset', '', 0),
(22, 1, '2021-06-01 22:08:21', '2021-06-01 19:08:21', '', 'Order &ndash; 1 июня, 2021 @ 10:08 ПП', '', 'trash', 'open', 'closed', 'wc_order_GqSCGG4IVQM6d', 'zakaz-ndash-01-jun-2021-v-19-08__trashed', '', '', '2021-06-16 02:48:09', '2021-06-15 23:48:09', '', 0, 'https://manufacturer-cloth.ru/?post_type=shop_order&#038;p=22', 0, 'shop_order', '', 1),
(23, 1, '2021-06-02 14:49:20', '2021-06-02 11:49:20', '{\n    \"nav_menu_item[16]\": {\n        \"value\": false,\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-02 11:49:20\"\n    },\n    \"nav_menu_item[17]\": {\n        \"value\": false,\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-02 11:49:20\"\n    },\n    \"nav_menu_item[18]\": {\n        \"value\": false,\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-02 11:49:20\"\n    },\n    \"nav_menu_item[19]\": {\n        \"value\": false,\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-02 11:49:20\"\n    },\n    \"nav_menu_item[20]\": {\n        \"value\": {\n            \"menu_item_parent\": 0,\n            \"object_id\": 20,\n            \"object\": \"custom\",\n            \"type\": \"custom\",\n            \"type_label\": \"\\u041f\\u0440\\u043e\\u0438\\u0437\\u0432\\u043e\\u043b\\u044c\\u043d\\u0430\\u044f \\u0441\\u0441\\u044b\\u043b\\u043a\\u0430\",\n            \"title\": \"\\u0410\\u043a\\u0446\\u0438\\u0438\",\n            \"url\": \"#\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"nav_menu_term_id\": 18,\n            \"position\": 5,\n            \"status\": \"publish\",\n            \"original_title\": \"\",\n            \"_invalid\": false\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-02 11:49:20\"\n    },\n    \"nav_menu_item[-281963863913121800]\": {\n        \"value\": {\n            \"object_id\": 20,\n            \"object\": \"product_cat\",\n            \"menu_item_parent\": 0,\n            \"position\": 1,\n            \"type\": \"taxonomy\",\n            \"title\": \"\\u0416\\u0435\\u043d\\u0441\\u043a\\u0438\\u0435\",\n            \"url\": \"https://manufacturer-cloth.ru/product-category/zhenskie\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"\\u0416\\u0435\\u043d\\u0441\\u043a\\u0438\\u0435\",\n            \"nav_menu_term_id\": 18,\n            \"_invalid\": false,\n            \"type_label\": \"\\u041a\\u0430\\u0442\\u0435\\u0433\\u043e\\u0440\\u0438\\u044f\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-02 11:49:20\"\n    },\n    \"nav_menu_item[-6633505307349545000]\": {\n        \"value\": {\n            \"object_id\": 16,\n            \"object\": \"product_cat\",\n            \"menu_item_parent\": 0,\n            \"position\": 2,\n            \"type\": \"taxonomy\",\n            \"title\": \"\\u041c\\u0443\\u0436\\u0441\\u043a\\u0438\\u0435\",\n            \"url\": \"https://manufacturer-cloth.ru/product-category/muzhskie\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"\\u041c\\u0443\\u0436\\u0441\\u043a\\u0438\\u0435\",\n            \"nav_menu_term_id\": 18,\n            \"_invalid\": false,\n            \"type_label\": \"\\u041a\\u0430\\u0442\\u0435\\u0433\\u043e\\u0440\\u0438\\u044f\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-02 11:49:20\"\n    },\n    \"nav_menu_item[-8967348860953156000]\": {\n        \"value\": {\n            \"object_id\": 21,\n            \"object\": \"product_cat\",\n            \"menu_item_parent\": 0,\n            \"position\": 3,\n            \"type\": \"taxonomy\",\n            \"title\": \"\\u041f\\u043e\\u0434\\u0440\\u043e\\u0441\\u0442\\u043a\\u0438\",\n            \"url\": \"https://manufacturer-cloth.ru/product-category/podrostki\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"\\u041f\\u043e\\u0434\\u0440\\u043e\\u0441\\u0442\\u043a\\u0438\",\n            \"nav_menu_term_id\": 18,\n            \"_invalid\": false,\n            \"type_label\": \"\\u041a\\u0430\\u0442\\u0435\\u0433\\u043e\\u0440\\u0438\\u044f\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-02 11:49:20\"\n    },\n    \"nav_menu_item[-7561177160853893000]\": {\n        \"value\": {\n            \"object_id\": 22,\n            \"object\": \"product_cat\",\n            \"menu_item_parent\": 0,\n            \"position\": 4,\n            \"type\": \"taxonomy\",\n            \"title\": \"\\u0414\\u0435\\u0442\\u0438\",\n            \"url\": \"https://manufacturer-cloth.ru/product-category/deti\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"\\u0414\\u0435\\u0442\\u0438\",\n            \"nav_menu_term_id\": 18,\n            \"_invalid\": false,\n            \"type_label\": \"\\u041a\\u0430\\u0442\\u0435\\u0433\\u043e\\u0440\\u0438\\u044f\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-02 11:49:20\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '912fb1e2-c292-4cb4-8525-b0a1809c2805', '', '', '2021-06-02 14:49:20', '2021-06-02 11:49:20', '', 0, 'https://manufacturer-cloth.ru/bez-rubriki/912fb1e2-c292-4cb4-8525-b0a1809c2805', 0, 'customize_changeset', '', 0),
(29, 1, '2021-06-03 00:01:46', '2021-06-02 21:01:46', 'Лёгкое платье в клетку виши выполнено из хлопка. Расклешённый крой, пояс в комплекте. Круглый вырез с пуговицей сзади, короткие цельнокроеные рукава с подворотами, волан.', 'КЛЕТЧАТОЕ ПЛАТЬЕ С ПОЯСОМ', 'Лёгкое платье в клетку виши выполнено из хлопка. Расклешённый крой, пояс в комплекте. Круглый вырез с пуговицей сзади, короткие цельнокроеные рукава с подворотами, волан.', 'publish', 'open', 'closed', '', 'kletchatoe-plate-s-pojasom', '', '', '2021-06-03 14:10:57', '2021-06-03 11:10:57', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=29', 0, 'product', '', 0),
(30, 1, '2021-06-03 00:01:07', '2021-06-02 21:01:07', '', 'GDR020836-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'gdr020836-1-01-300wx300h', '', '', '2021-06-03 00:01:07', '2021-06-02 21:01:07', '', 29, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/gdr020836-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(31, 1, '2021-06-03 13:35:43', '2021-06-03 10:33:27', '', 'Главная', '', 'publish', 'closed', 'closed', '', 'glavnaja', '', '', '2021-06-03 13:35:43', '2021-06-03 10:35:43', '', 0, 'https://manufacturer-cloth.ru/?p=31', 1, 'nav_menu_item', '', 0),
(32, 1, '2021-06-03 13:33:42', '2021-06-03 10:33:42', '<!-- wp:columns -->\n<div class=\"wp-block-columns\"><!-- wp:column {\"width\":\"100%\"} -->\n<div class=\"wp-block-column\" style=\"flex-basis:100%\"><!-- wp:paragraph -->\n<p>Бренд модной женской одежды и аксессуаров в 2021 году.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Наши дизайнеры вдохновляются последними мировыми трендами для того, чтобы дать каждой женщине возможность подобрать то, что лучше всего подходит именно ей и отражает ее индивидуальность.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Мы внимательно относимся к выбору материалов, чтобы созданные нами изделия в течение долгого времени сохраняли первоначальный вид.</p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:column --></div>\n<!-- /wp:columns -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'О компании', '', 'publish', 'closed', 'closed', '', 'o-kompanii', '', '', '2021-06-04 00:04:50', '2021-06-03 21:04:50', '', 0, 'https://manufacturer-cloth.ru/?page_id=32', 0, 'page', '', 0),
(33, 1, '2021-06-03 13:33:42', '2021-06-03 10:33:42', '', 'О компании', '', 'inherit', 'closed', 'closed', '', '32-revision-v1', '', '', '2021-06-03 13:33:42', '2021-06-03 10:33:42', '', 32, 'https://manufacturer-cloth.ru/?p=33', 0, 'revision', '', 0),
(35, 1, '2021-06-03 13:33:56', '2021-06-03 10:33:56', '<!-- wp:paragraph -->\n<p>MANUFACTURER – бренд первоклассной и доступной одежды для каждого члена семьи. Компания была основана в 1988 году и на сегодняшний день является лидером в сегменте fast fashion в России.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Вертикально-интегрированный ритейлер MANUFACTURER - это более 15 собственных и 200 партнерских производственных фабрик, два современных логистических центра и монобрендовая сеть розничных магазинов, которая на конец 2018 года насчитывала более 550 магазинов в России и СНГ.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Узнаваемость бренда MANUFACTURER составляет 99% среди россиян (согласно рейтингу Fitch, 2018 г.).</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Магазины MANUFACTURER – это место, в котором шопинг для каждого члена семьи будет поистине захватывающим, а не рутинным. Здесь можно найти абсолютно все: от любимых джинсов до модных новинок на каждый сезон. Каждую неделю в магазины поступает более 100 новых моделей.</p>\n<!-- /wp:paragraph -->', 'О нас', '', 'publish', 'closed', 'closed', '', 'o-nas', '', '', '2021-06-04 00:17:53', '2021-06-03 21:17:53', '', 0, 'https://manufacturer-cloth.ru/?page_id=35', 0, 'page', '', 0),
(36, 1, '2021-06-03 13:33:56', '2021-06-03 10:33:56', '', 'О нас', '', 'inherit', 'closed', 'closed', '', '35-revision-v1', '', '', '2021-06-03 13:33:56', '2021-06-03 10:33:56', '', 35, 'https://manufacturer-cloth.ru/?p=36', 0, 'revision', '', 0),
(37, 1, '2021-06-03 13:34:07', '2021-06-03 10:34:07', '<!-- wp:html -->\n<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d86573.42405259634!2d39.666602647336205!3d47.30614266501103!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40e3b7c043ab3f7f%3A0x67fea0b96057f85f!2z0JLQvtGA0L7RiNC40LvQvtCy0YHQutC40LksINCg0L7RgdGC0L7Qsi3QvdCwLdCU0L7QvdGDLCDQoNC-0YHRgtC-0LLRgdC60LDRjyDQvtCx0Lsu!5e0!3m2!1sru!2sru!4v1622755321671!5m2!1sru!2sru\" style=\"width:100%\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\"></iframe>\n<!-- /wp:html -->', 'Контакты', '', 'publish', 'closed', 'closed', '', 'kontakty', '', '', '2021-06-04 00:23:32', '2021-06-03 21:23:32', '', 0, 'https://manufacturer-cloth.ru/?page_id=37', 0, 'page', '', 0),
(38, 1, '2021-06-03 13:34:07', '2021-06-03 10:34:07', '', 'Контакты', '', 'inherit', 'closed', 'closed', '', '37-revision-v1', '', '', '2021-06-03 13:34:07', '2021-06-03 10:34:07', '', 37, 'https://manufacturer-cloth.ru/?p=38', 0, 'revision', '', 0),
(39, 1, '2021-06-03 13:35:43', '2021-06-03 10:35:12', ' ', '', '', 'publish', 'closed', 'closed', '', '39', '', '', '2021-06-03 13:35:43', '2021-06-03 10:35:43', '', 0, 'https://manufacturer-cloth.ru/?p=39', 5, 'nav_menu_item', '', 0),
(40, 1, '2021-06-03 13:35:43', '2021-06-03 10:35:12', ' ', '', '', 'publish', 'closed', 'closed', '', '40', '', '', '2021-06-03 13:35:43', '2021-06-03 10:35:43', '', 0, 'https://manufacturer-cloth.ru/?p=40', 4, 'nav_menu_item', '', 0),
(41, 1, '2021-06-03 13:35:43', '2021-06-03 10:35:12', ' ', '', '', 'publish', 'closed', 'closed', '', '41', '', '', '2021-06-03 13:35:43', '2021-06-03 10:35:43', '', 0, 'https://manufacturer-cloth.ru/?p=41', 3, 'nav_menu_item', '', 0),
(42, 1, '2021-06-03 13:35:43', '2021-06-03 10:35:43', ' ', '', '', 'publish', 'closed', 'closed', '', '42', '', '', '2021-06-03 13:35:43', '2021-06-03 10:35:43', '', 0, 'https://manufacturer-cloth.ru/?p=42', 2, 'nav_menu_item', '', 0),
(44, 1, '2021-06-03 17:44:23', '2021-06-03 14:44:23', '{\n    \"nav_menu_item[43]\": {\n        \"value\": false,\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-03 14:44:23\"\n    },\n    \"nav_menu_item[-6433429249705972000]\": {\n        \"value\": {\n            \"object_id\": 16,\n            \"object\": \"product_cat\",\n            \"menu_item_parent\": 0,\n            \"position\": 2,\n            \"type\": \"taxonomy\",\n            \"title\": \"\\u041c\\u0443\\u0436\\u0441\\u043a\\u0438\\u0435\",\n            \"url\": \"https://manufacturer-cloth.ru/product-category/muzhskie\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"\\u041c\\u0443\\u0436\\u0441\\u043a\\u0438\\u0435\",\n            \"nav_menu_term_id\": 19,\n            \"_invalid\": false,\n            \"type_label\": \"\\u041a\\u0430\\u0442\\u0435\\u0433\\u043e\\u0440\\u0438\\u044f\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-03 14:44:23\"\n    },\n    \"nav_menu_item[-8635048765447494000]\": {\n        \"value\": {\n            \"object_id\": 20,\n            \"object\": \"product_cat\",\n            \"menu_item_parent\": 0,\n            \"position\": 3,\n            \"type\": \"taxonomy\",\n            \"title\": \"\\u0416\\u0435\\u043d\\u0441\\u043a\\u0438\\u0435\",\n            \"url\": \"https://manufacturer-cloth.ru/product-category/zhenskie\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"\\u0416\\u0435\\u043d\\u0441\\u043a\\u0438\\u0435\",\n            \"nav_menu_term_id\": 19,\n            \"_invalid\": false,\n            \"type_label\": \"\\u041a\\u0430\\u0442\\u0435\\u0433\\u043e\\u0440\\u0438\\u044f\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-03 14:44:23\"\n    },\n    \"nav_menu_item[-197890481894686720]\": {\n        \"value\": false,\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-03 14:44:23\"\n    },\n    \"nav_menu_item[-5748464997312692000]\": {\n        \"value\": {\n            \"object_id\": 21,\n            \"object\": \"product_cat\",\n            \"menu_item_parent\": 0,\n            \"position\": 5,\n            \"type\": \"taxonomy\",\n            \"title\": \"\\u041f\\u043e\\u0434\\u0440\\u043e\\u0441\\u0442\\u043a\\u0438\",\n            \"url\": \"https://manufacturer-cloth.ru/product-category/podrostki\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"\\u041f\\u043e\\u0434\\u0440\\u043e\\u0441\\u0442\\u043a\\u0438\",\n            \"nav_menu_term_id\": 19,\n            \"_invalid\": false,\n            \"type_label\": \"\\u041a\\u0430\\u0442\\u0435\\u0433\\u043e\\u0440\\u0438\\u044f\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-03 14:44:23\"\n    },\n    \"nav_menu_item[-1090419236519282700]\": {\n        \"value\": {\n            \"object_id\": 22,\n            \"object\": \"product_cat\",\n            \"menu_item_parent\": 0,\n            \"position\": 6,\n            \"type\": \"taxonomy\",\n            \"title\": \"\\u0414\\u0435\\u0442\\u0438\",\n            \"url\": \"https://manufacturer-cloth.ru/product-category/deti\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"\\u0414\\u0435\\u0442\\u0438\",\n            \"nav_menu_term_id\": 19,\n            \"_invalid\": false,\n            \"type_label\": \"\\u041a\\u0430\\u0442\\u0435\\u0433\\u043e\\u0440\\u0438\\u044f\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-03 14:44:23\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '19616e01-2850-4d53-9552-716e7bb5bcbf', '', '', '2021-06-03 17:44:23', '2021-06-03 14:44:23', '', 0, 'https://manufacturer-cloth.ru/bez-rubriki/19616e01-2850-4d53-9552-716e7bb5bcbf', 0, 'customize_changeset', '', 0),
(45, 1, '2021-06-03 18:16:28', '2021-06-03 14:44:23', ' ', '', '', 'publish', 'closed', 'closed', '', '45', '', '', '2021-06-03 18:16:28', '2021-06-03 15:16:28', '', 0, 'https://manufacturer-cloth.ru/bez-rubriki/45', 3, 'nav_menu_item', '', 0),
(46, 1, '2021-06-03 18:16:28', '2021-06-03 14:44:23', ' ', '', '', 'publish', 'closed', 'closed', '', '46', '', '', '2021-06-03 18:16:28', '2021-06-03 15:16:28', '', 0, 'https://manufacturer-cloth.ru/bez-rubriki/46', 2, 'nav_menu_item', '', 0),
(47, 1, '2021-06-03 18:12:46', '2021-06-03 14:44:23', ' ', '', '', 'publish', 'closed', 'closed', '', '47', '', '', '2021-06-03 18:12:46', '2021-06-03 15:12:46', '', 0, 'https://manufacturer-cloth.ru/bez-rubriki/47', 4, 'nav_menu_item', '', 0),
(48, 1, '2021-06-03 18:16:28', '2021-06-03 14:44:23', ' ', '', '', 'publish', 'closed', 'closed', '', '48', '', '', '2021-06-03 18:16:28', '2021-06-03 15:16:28', '', 0, 'https://manufacturer-cloth.ru/bez-rubriki/48', 6, 'nav_menu_item', '', 0),
(49, 1, '2021-06-03 17:44:57', '2021-06-03 14:44:57', '{\n    \"nav_menu_item[47]\": {\n        \"value\": {\n            \"object_id\": 21,\n            \"object\": \"product_cat\",\n            \"menu_item_parent\": 0,\n            \"position\": 4,\n            \"type\": \"taxonomy\",\n            \"title\": \"\\u041f\\u043e\\u0434\\u0440\\u043e\\u0441\\u0442\\u043a\\u0438\",\n            \"url\": \"https://manufacturer-cloth.ru/product-category/podrostki\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"\\u041f\\u043e\\u0434\\u0440\\u043e\\u0441\\u0442\\u043a\\u0438\",\n            \"nav_menu_term_id\": 19,\n            \"_invalid\": false,\n            \"type_label\": \"\\u041a\\u0430\\u0442\\u0435\\u0433\\u043e\\u0440\\u0438\\u044f\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-03 14:44:57\"\n    },\n    \"nav_menu_item[48]\": {\n        \"value\": {\n            \"object_id\": 22,\n            \"object\": \"product_cat\",\n            \"menu_item_parent\": 0,\n            \"position\": 5,\n            \"type\": \"taxonomy\",\n            \"title\": \"\\u0414\\u0435\\u0442\\u0438\",\n            \"url\": \"https://manufacturer-cloth.ru/product-category/deti\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"\\u0414\\u0435\\u0442\\u0438\",\n            \"nav_menu_term_id\": 19,\n            \"_invalid\": false,\n            \"type_label\": \"\\u041a\\u0430\\u0442\\u0435\\u0433\\u043e\\u0440\\u0438\\u044f\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-03 14:44:57\"\n    },\n    \"nav_menu_item[-1131592447853260800]\": {\n        \"value\": {\n            \"object_id\": 0,\n            \"object\": \"custom\",\n            \"menu_item_parent\": 0,\n            \"position\": 1,\n            \"type\": \"custom\",\n            \"title\": \"\\u0412\\u0441\\u0435\",\n            \"url\": \"/\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"\\u0412\\u0441\\u0435\",\n            \"nav_menu_term_id\": 19,\n            \"_invalid\": false,\n            \"type_label\": \"\\u041f\\u0440\\u043e\\u0438\\u0437\\u0432\\u043e\\u043b\\u044c\\u043d\\u0430\\u044f \\u0441\\u0441\\u044b\\u043b\\u043a\\u0430\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-03 14:44:57\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '278a4887-f026-4a4c-88fe-bd0bd23a3cbc', '', '', '2021-06-03 17:44:57', '2021-06-03 14:44:57', '', 0, 'https://manufacturer-cloth.ru/bez-rubriki/278a4887-f026-4a4c-88fe-bd0bd23a3cbc', 0, 'customize_changeset', '', 0),
(50, 1, '2021-06-03 18:12:46', '2021-06-03 14:44:57', '', 'Все', '', 'publish', 'closed', 'closed', '', 'vse', '', '', '2021-06-03 18:12:46', '2021-06-03 15:12:46', '', 0, 'https://manufacturer-cloth.ru/bez-rubriki/vse', 1, 'nav_menu_item', '', 0),
(51, 1, '2021-06-03 18:14:11', '2021-06-03 15:14:11', 'Жёлтое платье с цветочным принтом выполнено из лёгкого креп-шифона. Приталенный крой с запАхом, пояс, короткие рукава, подкладка.', 'ЖЁЛТОЕ ПЛАТЬЕ-ХАЛАТ С ПОЯСОМ', 'Жёлтое платье с цветочным принтом выполнено из лёгкого креп-шифона. Приталенный крой с запАхом, пояс, короткие рукава, подкладка.', 'publish', 'closed', 'closed', '', 'zhjoltoe-plate-halat-s-pojasom', '', '', '2021-06-03 18:16:02', '2021-06-03 15:16:02', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=51', 0, 'product', '', 0),
(52, 1, '2021-06-03 18:14:07', '2021-06-03 15:14:07', '', 'GDR021496-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'gdr021496-1-01-300wx300h', '', '', '2021-06-03 18:14:07', '2021-06-03 15:14:07', '', 51, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/gdr021496-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(53, 1, '2021-06-03 18:17:19', '2021-06-03 15:17:19', 'Удобные шорты бежевого цвета изготовлены из хлопкового твила. Прямой крой, эластичный пояс со шнурком, карманы.', 'БЕЖЕВЫЕ ШОРТЫ С РЕЗИНКОЙ', 'Удобные шорты бежевого цвета изготовлены из хлопкового твила. Прямой крой, эластичный пояс со шнурком, карманы.', 'publish', 'closed', 'closed', '', 'bezhevye-shorty-s-rezinkoj', '', '', '2021-06-03 18:17:19', '2021-06-03 15:17:19', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=53', 0, 'product', '', 0),
(54, 1, '2021-06-03 18:16:28', '2021-06-03 15:16:28', '{\n    \"nav_menu_item[45]\": {\n        \"value\": {\n            \"menu_item_parent\": 0,\n            \"object_id\": 16,\n            \"object\": \"product_cat\",\n            \"type\": \"taxonomy\",\n            \"type_label\": \"\\u041a\\u0430\\u0442\\u0435\\u0433\\u043e\\u0440\\u0438\\u044f\",\n            \"url\": \"https://manufacturer-cloth.ru/product-category/muzhskie\",\n            \"title\": \"\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"nav_menu_term_id\": 19,\n            \"position\": 3,\n            \"status\": \"publish\",\n            \"original_title\": \"\\u041c\\u0443\\u0436\\u0441\\u043a\\u0438\\u0435\",\n            \"_invalid\": false\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-03 15:16:28\"\n    },\n    \"nav_menu_item[46]\": {\n        \"value\": {\n            \"menu_item_parent\": 0,\n            \"object_id\": 20,\n            \"object\": \"product_cat\",\n            \"type\": \"taxonomy\",\n            \"type_label\": \"\\u041a\\u0430\\u0442\\u0435\\u0433\\u043e\\u0440\\u0438\\u044f\",\n            \"url\": \"https://manufacturer-cloth.ru/product-category/zhenskie\",\n            \"title\": \"\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"nav_menu_term_id\": 19,\n            \"position\": 2,\n            \"status\": \"publish\",\n            \"original_title\": \"\\u0416\\u0435\\u043d\\u0441\\u043a\\u0438\\u0435\",\n            \"_invalid\": false\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-03 15:16:28\"\n    },\n    \"nav_menu_item[48]\": {\n        \"value\": {\n            \"menu_item_parent\": 0,\n            \"object_id\": 22,\n            \"object\": \"product_cat\",\n            \"type\": \"taxonomy\",\n            \"type_label\": \"\\u041a\\u0430\\u0442\\u0435\\u0433\\u043e\\u0440\\u0438\\u044f\",\n            \"url\": \"https://manufacturer-cloth.ru/product-category/deti\",\n            \"title\": \"\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"nav_menu_term_id\": 19,\n            \"position\": 6,\n            \"status\": \"publish\",\n            \"original_title\": \"\\u0414\\u0435\\u0442\\u0438\",\n            \"_invalid\": false\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-03 15:16:28\"\n    },\n    \"nav_menu_item[-7699728933849414000]\": {\n        \"value\": {\n            \"object_id\": 23,\n            \"object\": \"product_cat\",\n            \"menu_item_parent\": 0,\n            \"position\": 5,\n            \"type\": \"taxonomy\",\n            \"title\": \"\\u041d\\u043e\\u0432\\u043e\\u0440\\u043e\\u0436\\u0434\\u0451\\u043d\\u043d\\u044b\\u0435\",\n            \"url\": \"https://manufacturer-cloth.ru/product-category/novorozhdjonnye\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"\\u041d\\u043e\\u0432\\u043e\\u0440\\u043e\\u0436\\u0434\\u0451\\u043d\\u043d\\u044b\\u0435\",\n            \"nav_menu_term_id\": 19,\n            \"_invalid\": false,\n            \"type_label\": \"\\u041a\\u0430\\u0442\\u0435\\u0433\\u043e\\u0440\\u0438\\u044f\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-03 15:16:28\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '329d0bcd-c82c-475f-87c8-522580f90a2d', '', '', '2021-06-03 18:16:28', '2021-06-03 15:16:28', '', 0, 'https://manufacturer-cloth.ru/bez-rubriki/329d0bcd-c82c-475f-87c8-522580f90a2d', 0, 'customize_changeset', '', 0),
(55, 1, '2021-06-03 18:16:28', '2021-06-03 15:16:28', ' ', '', '', 'publish', 'closed', 'closed', '', '55', '', '', '2021-06-03 18:16:28', '2021-06-03 15:16:28', '', 0, 'https://manufacturer-cloth.ru/bez-rubriki/55', 5, 'nav_menu_item', '', 0),
(56, 1, '2021-06-03 18:16:32', '2021-06-03 15:16:32', '', 'BSH005135-2-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bsh005135-2-01-300wx300h', '', '', '2021-06-03 18:16:32', '2021-06-03 15:16:32', '', 53, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bsh005135-2-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(57, 1, '2021-06-03 18:18:06', '2021-06-03 15:18:06', 'Свободные шорты из футера. Эластичный пояс со шнурком, два боковых кармана.', 'ГОЛУБЫЕ СПОРТИВНЫЕ ШОРТЫ', 'Свободные шорты из футера. Эластичный пояс со шнурком, два боковых кармана.', 'publish', 'closed', 'closed', '', 'golubye-sportivnye-shorty', '', '', '2021-06-03 18:19:05', '2021-06-03 15:19:05', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=57', 0, 'product', '', 0),
(58, 1, '2021-06-03 18:17:42', '2021-06-03 15:17:42', '', 'BSH004865-2-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bsh004865-2-01-300wx300h', '', '', '2021-06-03 18:17:42', '2021-06-03 15:17:42', '', 57, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bsh004865-2-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(59, 1, '2021-06-03 18:18:48', '2021-06-03 15:18:48', 'Светло-оливковая футболка с надписью ALL WE NEED IS TO MOVE. выполнена из хлопкового трикотажа джерси. Прямой силуэт, круглый вырез горловины, короткие рукава.', 'ОЛИВКОВАЯ ФУТБОЛКА С НАДПИСЬЮ', 'Светло-оливковая футболка с надписью ALL WE NEED IS TO MOVE. выполнена из хлопкового трикотажа джерси. Прямой силуэт, круглый вырез горловины, короткие рукава.', 'publish', 'closed', 'closed', '', 'olivkovaja-futbolka-s-nadpisju', '', '', '2021-06-03 18:18:48', '2021-06-03 15:18:48', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=59', 0, 'product', '', 0),
(60, 1, '2021-06-03 18:18:42', '2021-06-03 15:18:42', '', 'BKT008801-1-04-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bkt008801-1-04-300wx300h', '', '', '2021-06-03 18:18:42', '2021-06-03 15:18:42', '', 59, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bkt008801-1-04-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(61, 1, '2021-06-03 18:20:07', '2021-06-03 15:20:07', 'Чёрное худи выполнено из смесового футера. Свободный крой oversize, капюшон со шнурком, карман-кенгуру из ткани с эффектом «хамелеон», заниженная линия плеча.', 'ЧЁРНОЕ ХУДИ OVERSIZE С КАРМАНОМ-КЕНГУРУ И ПРИНТОМ WORLDWIDE', 'Чёрное худи выполнено из смесового футера. Свободный крой oversize, капюшон со шнурком, карман-кенгуру из ткани с эффектом «хамелеон», заниженная линия плеча.', 'publish', 'closed', 'closed', '', 'chjornoe-hudi-oversize-s-karmanom-kenguru-i-printom-worldwide', '', '', '2021-06-03 18:20:07', '2021-06-03 15:20:07', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=61', 0, 'product', '', 0),
(62, 1, '2021-06-03 18:19:50', '2021-06-03 15:19:50', '', 'BAC008702-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bac008702-1-01-300wx300h', '', '', '2021-06-03 18:19:50', '2021-06-03 15:19:50', '', 61, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bac008702-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(63, 1, '2021-06-03 18:21:00', '2021-06-03 15:21:00', 'Чёрный свитшот с монохромным фотопринтом выполнен из смесового футера. Прямой крой, круглый вырез горловины, длинные рукава с заниженной линией плеча и манжетами.', 'ЧЁРНЫЙ СВИТШОТ С ФОТОПРИНТОМ DOWNTOWN', 'Чёрный свитшот с монохромным фотопринтом выполнен из смесового футера. Прямой крой, круглый вырез горловины, длинные рукава с заниженной линией плеча и манжетами.', 'publish', 'closed', 'closed', '', 'chjornyj-svitshot-s-fotoprintom-downtown', '', '', '2021-06-03 18:21:00', '2021-06-03 15:21:00', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=63', 0, 'product', '', 0),
(64, 1, '2021-06-03 18:20:36', '2021-06-03 15:20:36', '', 'BAC008655-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bac008655-1-01-300wx300h', '', '', '2021-06-03 18:20:36', '2021-06-03 15:20:36', '', 63, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bac008655-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(65, 1, '2021-06-03 18:22:10', '2021-06-03 15:22:10', 'Ветровка в стиле колор-блок выполнена из лёгкой ткани. Капюшон с фиксаторами, застёжка на молнию с небольшим защитным клапаном на конце, два кармана, резинки на манжетах и внизу. Декоративные аппликации в виде надписей.', 'ВЕТРОВКА КОЛОР-БЛОК', 'Ветровка в стиле колор-блок выполнена из лёгкой ткани. Капюшон с фиксаторами, застёжка на молнию с небольшим защитным клапаном на конце, два кармана, резинки на манжетах и внизу. Декоративные аппликации в виде надписей.', 'publish', 'closed', 'closed', '', 'vetrovka-kolor-blok', '', '', '2021-06-03 18:22:10', '2021-06-03 15:22:10', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=65', 0, 'product', '', 0),
(66, 1, '2021-06-03 18:22:03', '2021-06-03 15:22:03', '', 'BOW001276-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bow001276-1-01-300wx300h', '', '', '2021-06-03 18:22:03', '2021-06-03 15:22:03', '', 65, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bow001276-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(67, 1, '2021-06-03 18:23:00', '2021-06-03 15:23:00', 'Классическая джинсовая куртка выполнена из плотного хлопкового денима традиционного синего цвета. Прямой крой, отложной воротник, планка и манжеты на металлических пуговицах, нагрудные карманы с клапанами, два боковых кармана.', 'КЛАССИЧЕСКАЯ ДЖИНСОВАЯ КУРТКА', 'Классическая джинсовая куртка выполнена из плотного хлопкового денима традиционного синего цвета. Прямой крой, отложной воротник, планка и манжеты на металлических пуговицах, нагрудные карманы с клапанами, два боковых кармана.', 'publish', 'closed', 'closed', '', 'klassicheskaja-dzhinsovaja-kurtka', '', '', '2021-06-03 18:23:22', '2021-06-03 15:23:22', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=67', 0, 'product', '', 0),
(68, 1, '2021-06-03 18:22:34', '2021-06-03 15:22:34', '', 'BJC001658-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bjc001658-1-01-300wx300h', '', '', '2021-06-03 18:22:34', '2021-06-03 15:22:34', '', 67, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bjc001658-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(69, 1, '2021-06-03 18:24:30', '2021-06-03 15:24:30', 'Классическая джинсовая куртка выполнена из плотного хлопкового денима голубого цвета. Прямой крой, отложной воротник, планка и манжеты на металлических пуговицах, нагрудные карманы с клапанами, два боковых кармана.', 'КЛАССИЧЕСКАЯ ДЖИНСОВАЯ КУРТКА', 'Классическая джинсовая куртка выполнена из плотного хлопкового денима голубого цвета. Прямой крой, отложной воротник, планка и манжеты на металлических пуговицах, нагрудные карманы с клапанами, два боковых кармана.', 'publish', 'closed', 'closed', '', 'klassicheskaja-dzhinsovaja-kurtka-2', '', '', '2021-06-03 18:24:30', '2021-06-03 15:24:30', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=69', 0, 'product', '', 0),
(70, 1, '2021-06-03 18:23:41', '2021-06-03 15:23:41', '', 'BJC001658-2-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bjc001658-2-01-300wx300h', '', '', '2021-06-03 18:23:41', '2021-06-03 15:23:41', '', 69, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bjc001658-2-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(71, 1, '2021-06-03 18:25:17', '2021-06-03 15:25:17', 'Бежевые брюки-чинос выполнены из хлопковой ткани. Прямой крой, застёжка на молнию и пуговицу, шлёвки для ремня, боковые и задние карманы.', 'БЕЖЕВЫЕ БРЮКИ-ЧИНОС', 'Бежевые брюки-чинос выполнены из хлопковой ткани. Прямой крой, застёжка на молнию и пуговицу, шлёвки для ремня, боковые и задние карманы.', 'publish', 'closed', 'closed', '', 'bezhevye-brjuki-chinos', '', '', '2021-06-03 18:25:17', '2021-06-03 15:25:17', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=71', 0, 'product', '', 0),
(72, 1, '2021-06-03 18:24:57', '2021-06-03 15:24:57', '', 'BPT002709-2-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bpt002709-2-01-300wx300h', '', '', '2021-06-03 18:24:57', '2021-06-03 15:24:57', '', 71, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bpt002709-2-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(73, 1, '2021-06-03 18:26:55', '2021-06-03 15:26:55', 'Тёмно-серая футболка с надписями выполнена из хлопкового трикотажа. Свободная посадка comfort, круглый вырез горловины, короткие рукава с заниженной линией плеча.', 'ТЁМНО-СЕРАЯ ФУТБОЛКА С ПРИНТОМ', 'Тёмно-серая футболка с надписями выполнена из хлопкового трикотажа. Свободная посадка comfort, круглый вырез горловины, короткие рукава с заниженной линией плеча.', 'publish', 'closed', 'closed', '', 'tjomno-seraja-futbolka-s-printom', '', '', '2021-06-03 18:26:55', '2021-06-03 15:26:55', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=73', 0, 'product', '', 0),
(74, 1, '2021-06-03 18:26:33', '2021-06-03 15:26:33', '', 'BKT007967-2-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bkt007967-2-01-300wx300h', '', '', '2021-06-03 18:26:33', '2021-06-03 15:26:33', '', 73, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bkt007967-2-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(75, 1, '2021-06-03 18:28:24', '2021-06-03 15:28:24', 'Спортивные брюки цвета хаки выполнены из плотного и мягкого футера с начёсом. Удобный крой со свободной посадкой, эластичный пояс со шнурком, манжеты, два боковых кармана. Лаконичный текстовый принт.', 'ХАКИ СПОРТИВНЫЕ БРЮКИ', 'Спортивные брюки цвета хаки выполнены из плотного и мягкого футера с начёсом. Удобный крой со свободной посадкой, эластичный пояс со шнурком, манжеты, два боковых кармана. Лаконичный текстовый принт.', 'publish', 'closed', 'closed', '', 'haki-sportivnye-brjuki', '', '', '2021-06-03 18:28:25', '2021-06-03 15:28:25', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=75', 0, 'product', '', 0),
(76, 1, '2021-06-03 18:28:01', '2021-06-03 15:28:01', '', 'BAC008511-2-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bac008511-2-01-300wx300h', '', '', '2021-06-03 18:28:01', '2021-06-03 15:28:01', '', 75, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bac008511-2-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(77, 1, '2021-06-03 18:29:20', '2021-06-03 15:29:20', 'Чёрные брюки-карго выполнены из смесового футера. Спортивный фасон Jogger: эластичный пояс со шнурком, манжеты. Накладные карманы-карго с клапанами, стандартные боковые карманы.', 'ЧЁРНЫЕ СПОРТИВНЫЕ БРЮКИ С КАРМАНАМИ-КАРГО', 'Чёрные брюки-карго выполнены из смесового футера. Спортивный фасон Jogger: эластичный пояс со шнурком, манжеты. Накладные карманы-карго с клапанами, стандартные боковые карманы.', 'publish', 'closed', 'closed', '', 'chjornye-sportivnye-brjuki-s-karmanami-kargo', '', '', '2021-06-03 18:29:28', '2021-06-03 15:29:28', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=77', 0, 'product', '', 0),
(78, 1, '2021-06-03 18:29:05', '2021-06-03 15:29:05', '', 'BAC008650-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bac008650-1-01-300wx300h', '', '', '2021-06-03 18:29:05', '2021-06-03 15:29:05', '', 77, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bac008650-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(79, 1, '2021-06-03 18:30:19', '2021-06-03 15:30:19', 'Белое классическое поло с вышитым парусником выполнено из хлопковой ткани пике. Прямой крой, отложной воротник-поло, короткая планка на пуговицах, короткие рукава с манжетами.', 'БЕЛОЕ ПОЛО С ВЫШИВКОЙ', 'Белое классическое поло с вышитым парусником выполнено из хлопковой ткани пике. Прямой крой, отложной воротник-поло, короткая планка на пуговицах, короткие рукава с манжетами.', 'publish', 'closed', 'closed', '', 'beloe-polo-s-vyshivkoj', '', '', '2021-06-03 18:30:19', '2021-06-03 15:30:19', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=79', 0, 'product', '', 0),
(80, 1, '2021-06-03 18:30:14', '2021-06-03 15:30:14', '', 'BKT006911-5-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bkt006911-5-01-300wx300h', '', '', '2021-06-03 18:30:14', '2021-06-03 15:30:14', '', 79, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bkt006911-5-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(81, 1, '2021-06-03 18:31:01', '2021-06-03 15:31:01', 'Голубая базовая футболка выполнена из хлопкового трикотажа. Свободная посадка comfort, круглый вырез горловины, короткие рукава с заниженной линией плеча, небольшая нашивка.', 'ГОЛУБАЯ БАЗОВАЯ ФУТБОЛКА COMFORT', 'Голубая базовая футболка выполнена из хлопкового трикотажа. Свободная посадка comfort, круглый вырез горловины, короткие рукава с заниженной линией плеча, небольшая нашивка.', 'publish', 'closed', 'closed', '', 'golubaja-bazovaja-futbolka-comfort', '', '', '2021-06-03 18:31:01', '2021-06-03 15:31:01', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=81', 0, 'product', '', 0),
(82, 1, '2021-06-03 18:30:56', '2021-06-03 15:30:56', '', 'BKT007749-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bkt007749-1-01-300wx300h', '', '', '2021-06-03 18:30:56', '2021-06-03 15:30:56', '', 81, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bkt007749-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(83, 1, '2021-06-03 18:31:41', '2021-06-03 15:31:41', 'Бежевая футболка с текстовым принтом выполнена из хлопкового трикотажа. Свободная посадка comfort, круглый вырез горловины, короткие рукава с заниженной линией плеча.', 'БЕЖЕВАЯ ФУТБОЛКА С ПРИНТОМ CREATE', 'Бежевая футболка с текстовым принтом выполнена из хлопкового трикотажа. Свободная посадка comfort, круглый вырез горловины, короткие рукава с заниженной линией плеча.', 'publish', 'closed', 'closed', '', 'bezhevaja-futbolka-s-printom-create', '', '', '2021-06-03 18:31:41', '2021-06-03 15:31:41', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=83', 0, 'product', '', 0),
(84, 1, '2021-06-03 18:31:22', '2021-06-03 15:31:22', '', 'BKT007966-2-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bkt007966-2-01-300wx300h', '', '', '2021-06-03 18:31:22', '2021-06-03 15:31:22', '', 83, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bkt007966-2-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(85, 1, '2021-06-03 18:33:10', '2021-06-03 15:33:10', 'Тёмно-синие брюки с текстовым принтом выполнены из смесового футера. Спортивный фасон с посадкой comfort: эластичный пояс со шнурком, манжеты, два боковых кармана.', 'СИНИЕ СПОРТИВНЫЕ БРЮКИ С ПРИНТОМ', 'Тёмно-синие брюки с текстовым принтом выполнены из смесового футера. Спортивный фасон с посадкой comfort: эластичный пояс со шнурком, манжеты, два боковых кармана.', 'publish', 'closed', 'closed', '', 'sinie-sportivnye-brjuki-s-printom', '', '', '2021-06-03 18:33:10', '2021-06-03 15:33:10', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=85', 0, 'product', '', 0),
(86, 1, '2021-06-03 18:32:45', '2021-06-03 15:32:45', '', 'BAC008718-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bac008718-1-01-300wx300h', '', '', '2021-06-03 18:32:45', '2021-06-03 15:32:45', '', 85, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bac008718-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(88, 1, '2021-06-03 18:36:06', '2021-06-03 15:36:06', 'Бежевые брюки-джоггеры выполнены из эластичного хлопкового твила. Свободная посадка джоггер, эластичный пояс, эластичные манжеты, карманы.', 'БЕЖЕВЫЕ БРЮКИ-ДЖОГГЕРЫ ИЗ ТВИЛА', 'Бежевые брюки-джоггеры выполнены из эластичного хлопкового твила. Свободная посадка джоггер, эластичный пояс, эластичные манжеты, карманы.', 'publish', 'closed', 'closed', '', 'bezhevye-brjuki-dzhoggery-iz-tvila', '', '', '2021-06-03 18:36:06', '2021-06-03 15:36:06', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=88', 0, 'product', '', 0),
(89, 1, '2021-06-03 18:36:00', '2021-06-03 15:36:00', '', 'BPT002671-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bpt002671-1-01-300wx300h', '', '', '2021-06-03 18:36:00', '2021-06-03 15:36:00', '', 88, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bpt002671-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(90, 1, '2021-06-03 18:36:49', '2021-06-03 15:36:49', 'Хаки брюки-джоггеры выполнены из эластичного хлопкового твила. Свободная посадка джоггер, эластичный пояс, эластичные манжеты, карманы.', 'ХАКИ БРЮКИ-ДЖОГГЕРЫ ИЗ ТВИЛА', 'Хаки брюки-джоггеры выполнены из эластичного хлопкового твила. Свободная посадка джоггер, эластичный пояс, эластичные манжеты, карманы.', 'publish', 'closed', 'closed', '', 'haki-brjuki-dzhoggery-iz-tvila', '', '', '2021-06-03 18:36:49', '2021-06-03 15:36:49', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=90', 0, 'product', '', 0),
(91, 1, '2021-06-03 18:36:38', '2021-06-03 15:36:38', '', 'BPT002671-2-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bpt002671-2-01-300wx300h', '', '', '2021-06-03 18:36:38', '2021-06-03 15:36:38', '', 90, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bpt002671-2-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(92, 1, '2021-06-03 18:38:01', '2021-06-03 15:38:01', 'Тёмно-серые брюки свободного кроя выполнены из мягкого футера. Свободная комфортная посадка, эластичные пояс и манжеты, два кармана. Небольшой принт.', 'СЕРЫЕ СПОРТИВНЫЕ БРЮКИ OVERSIZE', 'Тёмно-серые брюки свободного кроя выполнены из мягкого футера. Свободная комфортная посадка, эластичные пояс и манжеты, два кармана. Небольшой принт.', 'publish', 'closed', 'closed', '', 'serye-sportivnye-brjuki-oversize', '', '', '2021-06-03 18:38:01', '2021-06-03 15:38:01', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=92', 0, 'product', '', 0),
(93, 1, '2021-06-03 18:37:57', '2021-06-03 15:37:57', '', 'BAC008363-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bac008363-1-01-300wx300h', '', '', '2021-06-03 18:37:57', '2021-06-03 15:37:57', '', 92, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bac008363-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(94, 1, '2021-06-03 18:38:41', '2021-06-03 15:38:41', 'Синие спортивные джоггеры выполнены из футера с начёсом. Свободный крой, эластичный пояс со шнурком, два боковых кармана и карман сзади, эластичные манжеты. Фактурный принт в виде надписи.', 'СИНИЕ СПОРТИВНЫЕ БРЮКИ С ВЫШИВКОЙ', 'Синие спортивные джоггеры выполнены из футера с начёсом. Свободный крой, эластичный пояс со шнурком, два боковых кармана и карман сзади, эластичные манжеты. Фактурный принт в виде надписи.', 'publish', 'closed', 'closed', '', 'sinie-sportivnye-brjuki-s-vyshivkoj', '', '', '2021-06-03 18:38:41', '2021-06-03 15:38:41', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=94', 0, 'product', '', 0),
(95, 1, '2021-06-03 18:38:20', '2021-06-03 15:38:20', '', 'BAC008654-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bac008654-1-01-300wx300h', '', '', '2021-06-03 18:38:20', '2021-06-03 15:38:20', '', 94, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bac008654-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(96, 1, '2021-06-03 18:39:40', '2021-06-03 15:39:40', 'Серые спортивные брюки с надписью KEEP IT REAL выполнены из хлопкового футера. Посадка comfort fit: свободный крой, эластичный пояс со шнурком, резинки на штанинах, два кармана.', 'СЕРЫЕ СПОРТИВНЫЕ БРЮКИ С НАДПИСЬЮ', 'Серые спортивные брюки с надписью KEEP IT REAL выполнены из хлопкового футера. Посадка comfort fit: свободный крой, эластичный пояс со шнурком, резинки на штанинах, два кармана.', 'publish', 'closed', 'closed', '', 'serye-sportivnye-brjuki-s-nadpisju', '', '', '2021-06-03 18:39:40', '2021-06-03 15:39:40', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=96', 0, 'product', '', 0),
(97, 1, '2021-06-03 18:39:33', '2021-06-03 15:39:33', '', 'BAC009526-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bac009526-1-01-300wx300h', '', '', '2021-06-03 18:39:33', '2021-06-03 15:39:33', '', 96, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bac009526-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(98, 1, '2021-06-03 18:41:19', '2021-06-03 15:41:19', 'Классические брюки-чиносы выполнены из хлопковой ткани с содержанием эластичного спандекса. Зауженный фасон Slim, застёжка на молнию и пуговицу, косые боковые карманы и прорезные карманы сзади.', 'БРЮКИ-ЧИНОС ХАКИ', 'Классические брюки-чиносы выполнены из хлопковой ткани с содержанием эластичного спандекса. Зауженный фасон Slim, застёжка на молнию и пуговицу, косые боковые карманы и прорезные карманы сзади.', 'publish', 'closed', 'closed', '', 'brjuki-chinos-haki', '', '', '2021-06-03 18:41:19', '2021-06-03 15:41:19', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=98', 0, 'product', '', 0),
(99, 1, '2021-06-03 18:41:14', '2021-06-03 15:41:14', '', 'BPT002851-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bpt002851-1-01-300wx300h', '', '', '2021-06-03 18:41:14', '2021-06-03 15:41:14', '', 98, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bpt002851-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(100, 1, '2021-06-03 18:42:43', '2021-06-03 15:42:43', 'Джинсы-джоггеры выполнены из плотного хлопкового твила. Фасон джоггер: свободная посадка, эластичный пояс со шнурком, резинки на штанинах, карманы по бокам и сзади.', 'ТЁМНО-СИНИЕ ДЖИНСЫ JOGGER', 'Джинсы-джоггеры выполнены из плотного хлопкового твила. Фасон джоггер: свободная посадка, эластичный пояс со шнурком, резинки на штанинах, карманы по бокам и сзади.', 'publish', 'closed', 'closed', '', 'tjomno-sinie-dzhinsy-jogger', '', '', '2021-06-03 18:42:43', '2021-06-03 15:42:43', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=100', 0, 'product', '', 0),
(101, 1, '2021-06-03 18:41:43', '2021-06-03 15:41:43', '', 'BPT002722-4-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bpt002722-4-01-300wx300h', '', '', '2021-06-03 18:41:43', '2021-06-03 15:41:43', '', 100, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bpt002722-4-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(102, 1, '2021-06-03 18:44:24', '2021-06-03 15:44:24', 'Чёрное платье с цветочным принтом выполнено из лёгкой струящейся ткани. Приталенный крой с запáхом, рукава-крылышки.', 'ЧЁРНОЕ ЦВЕТОЧНОЕ ПЛАТЬЕ С ЗАПÁХОМ', 'Чёрное платье с цветочным принтом выполнено из лёгкой струящейся ткани. Приталенный крой с запáхом, рукава-крылышки.', 'publish', 'closed', 'closed', '', 'chjornoe-cvetochnoe-plate-s-zap-hom', '', '', '2021-06-03 18:44:24', '2021-06-03 15:44:24', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=102', 0, 'product', '', 0),
(103, 1, '2021-06-03 18:44:14', '2021-06-03 15:44:14', '', 'GDR022837-2-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'gdr022837-2-01-300wx300h', '', '', '2021-06-03 18:44:14', '2021-06-03 15:44:14', '', 102, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/gdr022837-2-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(104, 1, '2021-06-03 18:45:55', '2021-06-03 15:45:55', 'Лёгкое оливковое платье выполнено из жатой трикотажной ткани с цветочным принтом. Расклешённый крой, круглый вырез горловины, объёмные рукава-фонарики с резинками.', 'ОЛИВКОВОЕ ПЛАТЬЕ С ЦВЕТОЧНЫМ ПРИНТОМ', 'Лёгкое оливковое платье выполнено из жатой трикотажной ткани с цветочным принтом. Расклешённый крой, круглый вырез горловины, объёмные рукава-фонарики с резинками.', 'publish', 'closed', 'closed', '', 'olivkovoe-plate-s-cvetochnym-printom', '', '', '2021-06-03 18:45:55', '2021-06-03 15:45:55', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=104', 0, 'product', '', 0),
(105, 1, '2021-06-03 18:45:50', '2021-06-03 15:45:50', '', 'GDR023418-2-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'gdr023418-2-01-300wx300h', '', '', '2021-06-03 18:45:50', '2021-06-03 15:45:50', '', 104, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/gdr023418-2-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(106, 1, '2021-06-03 18:46:30', '2021-06-03 15:46:30', 'Сиреневые джинсы-слаучи выполнены из плотного хлопкового денима с варкой. Фасон Slouchy: свободный верх с высокой талией, зауженный от колена низ. Застёжка на молнию и пуговицу, шлёвки для ремня, пять карманов. Эти джинсы мы изготовили, используя в два раза меньше воды и электроэнергии.', 'СИРЕНЕВЫЕ ДЖИНСЫ SLOUCHY С ВЫСОКОЙ ТАЛИЕЙ', 'Сиреневые джинсы-слаучи выполнены из плотного хлопкового денима с варкой. Фасон Slouchy: свободный верх с высокой талией, зауженный от колена низ. Застёжка на молнию и пуговицу, шлёвки для ремня, пять карманов. Эти джинсы мы изготовили, используя в два раза меньше воды и электроэнергии.', 'publish', 'closed', 'closed', '', 'sirenevye-dzhinsy-slouchy-s-vysokoj-taliej', '', '', '2021-06-03 18:46:30', '2021-06-03 15:46:30', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=106', 0, 'product', '', 0),
(107, 1, '2021-06-03 18:46:17', '2021-06-03 15:46:17', '', 'GJN019872-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'gjn019872-1-01-300wx300h', '', '', '2021-06-03 18:46:17', '2021-06-03 15:46:17', '', 106, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/gjn019872-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(108, 1, '2021-06-03 18:47:01', '2021-06-03 15:47:01', 'Голубое платье выполнено из струящейся вискозы. Приталенный крой, резинка на талии и пояс, V-образный вырез с запАхом, каскадные рукава-крылышки.', 'ГОЛУБОЕ ПЛАТЬЕ С ПОЯСОМ И РУКАВАМИ-КРЫЛЫШКАМИ', 'Голубое платье выполнено из струящейся вискозы. Приталенный крой, резинка на талии и пояс, V-образный вырез с запАхом, каскадные рукава-крылышки.', 'publish', 'closed', 'closed', '', 'goluboe-plate-s-pojasom-i-rukavami-krylyshkami', '', '', '2021-06-03 18:47:01', '2021-06-03 15:47:01', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=108', 0, 'product', '', 0),
(109, 1, '2021-06-03 18:46:53', '2021-06-03 15:46:53', '', 'GDR023729-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'gdr023729-1-01-300wx300h', '', '', '2021-06-03 18:46:53', '2021-06-03 15:46:53', '', 108, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/gdr023729-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(110, 1, '2021-06-03 18:47:44', '2021-06-03 15:47:44', 'Жёлтое платье-халат с цветочным принтом выполнено из лёгкой вискозы. Длина миди, V-образный вырез, короткие рукава, пояс.', 'ЖЁЛТОЕ ПЛАТЬЕ-ХАЛАТ С ПОЯСОМ', 'Жёлтое платье-халат с цветочным принтом выполнено из лёгкой вискозы. Длина миди, V-образный вырез, короткие рукава, пояс.', 'publish', 'closed', 'closed', '', 'zhjoltoe-plate-halat-s-pojasom-2', '', '', '2021-06-03 18:47:44', '2021-06-03 15:47:44', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=110', 0, 'product', '', 0),
(111, 1, '2021-06-03 18:47:32', '2021-06-03 15:47:32', '', 'GDR023802-2-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'gdr023802-2-01-300wx300h', '', '', '2021-06-03 18:47:32', '2021-06-03 15:47:32', '', 110, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/gdr023802-2-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(112, 1, '2021-06-03 18:48:21', '2021-06-03 15:48:21', 'Свободные шорты-бермуды выполнены из смесового футера. Фасон Bermudas: свободный крой, высокая талия. Эластичный пояс со шнурком, карманы.', 'МОЛОЧНЫЕ ШОРТЫ BERMUDAS', 'Свободные шорты-бермуды выполнены из смесового футера. Фасон Bermudas: свободный крой, высокая талия. Эластичный пояс со шнурком, карманы.', 'publish', 'closed', 'closed', '', 'molochnye-shorty-bermudas', '', '', '2021-06-03 18:48:21', '2021-06-03 15:48:21', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=112', 0, 'product', '', 0),
(113, 1, '2021-06-03 18:48:15', '2021-06-03 15:48:15', '', 'GSH007021-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'gsh007021-1-01-300wx300h', '', '', '2021-06-03 18:48:15', '2021-06-03 15:48:15', '', 112, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/gsh007021-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(114, 1, '2021-06-03 18:49:02', '2021-06-03 15:49:02', 'Свободные шорты-бермуды выполнены из смесового футера. Фасон Bermudas: свободный крой, высокая талия. Эластичный пояс со шнурком, карманы.', 'ЛИЛОВЫЕ ШОРТЫ BERMUDAS', 'Свободные шорты-бермуды выполнены из смесового футера. Фасон Bermudas: свободный крой, высокая талия. Эластичный пояс со шнурком, карманы.', 'publish', 'closed', 'closed', '', 'lilovye-shorty-bermudas', '', '', '2021-06-03 18:49:02', '2021-06-03 15:49:02', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=114', 0, 'product', '', 0),
(115, 1, '2021-06-03 18:48:44', '2021-06-03 15:48:44', '', 'GSH007021-2-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'gsh007021-2-01-300wx300h', '', '', '2021-06-03 18:48:44', '2021-06-03 15:48:44', '', 114, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/gsh007021-2-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(116, 1, '2021-06-03 18:50:17', '2021-06-03 15:50:17', 'Чёрное платье в белый горох polka dot выполнено из лёгкой вискозы. Приталенный фасон с расклешённой юбкой, завязки на воротнике, короткие рукава с резинками.', 'ЧЁРНОЕ ПРИТАЛЕННОЕ ПЛАТЬЕ В ГОРОХ', 'Чёрное платье в белый горох polka dot выполнено из лёгкой вискозы. Приталенный фасон с расклешённой юбкой, завязки на воротнике, короткие рукава с резинками.', 'publish', 'closed', 'closed', '', 'chjornoe-pritalennoe-plate-v-goroh', '', '', '2021-06-03 18:50:17', '2021-06-03 15:50:17', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=116', 0, 'product', '', 0),
(117, 1, '2021-06-03 18:50:01', '2021-06-03 15:50:01', '', 'GDR022968-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'gdr022968-1-01-300wx300h', '', '', '2021-06-03 18:50:01', '2021-06-03 15:50:01', '', 116, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/gdr022968-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(118, 1, '2021-06-03 18:50:57', '2021-06-03 15:50:57', 'Чёрная толстовка oversize с принтом FUTURE спереди и на спинке выполнена из хлопкового футера. Слегка удлинённый, свободный крой oversize. Капюшон, застёжка на молнию, два кармана.', 'ЧЁРНАЯ ТОЛСТОВКА OVERSIZE С ПРИНТОМ FUTURE', 'Чёрная толстовка oversize с принтом FUTURE спереди и на спинке выполнена из хлопкового футера. Слегка удлинённый, свободный крой oversize. Капюшон, застёжка на молнию, два кармана.', 'publish', 'closed', 'closed', '', 'chjornaja-tolstovka-oversize-s-printom-future', '', '', '2021-06-03 18:50:57', '2021-06-03 15:50:57', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=118', 0, 'product', '', 0),
(119, 1, '2021-06-03 18:50:47', '2021-06-03 15:50:47', '', 'GAC015272-2-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'gac015272-2-01-300wx300h', '', '', '2021-06-03 18:50:47', '2021-06-03 15:50:47', '', 118, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/gac015272-2-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(120, 1, '2021-06-03 18:51:31', '2021-06-03 15:51:31', 'Меланжевое худи свободного кроя oversize из мягкого футера с начёсом. Капюшон со шнурком, заниженная линия плеча, карман-кенгуру. Сканируй QR-код на рукаве, и попадёшь на наш плейлист в Spotify. Танцуй под плейлист любимого бренда!', 'СЕРОЕ ХУДИ OVERSIZE С QR-КОДОМ', 'Меланжевое худи свободного кроя oversize из мягкого футера с начёсом. Капюшон со шнурком, заниженная линия плеча, карман-кенгуру. Сканируй QR-код на рукаве, и попадёшь на наш плейлист в Spotify. Танцуй под плейлист любимого бренда!', 'publish', 'closed', 'closed', '', 'seroe-hudi-oversize-s-qr-kodom', '', '', '2021-06-03 18:51:31', '2021-06-03 15:51:31', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=120', 0, 'product', '', 0),
(121, 1, '2021-06-03 18:51:25', '2021-06-03 15:51:25', '', 'GAC015635-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'gac015635-1-01-300wx300h', '', '', '2021-06-03 18:51:25', '2021-06-03 15:51:25', '', 120, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/gac015635-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(122, 1, '2021-06-03 18:52:39', '2021-06-03 15:52:39', 'Тёмно-серое укороченное худи с принтом и QR-кодом на рукаве. Модель выполнена из футера. Капюшон со шнурком, манжеты и широкая резинка на талии в рубчик.', 'ТЁМНО-СЕРОЕ УКОРОЧЕННОЕ ХУДИ С ПРИНТОМ', 'Тёмно-серое укороченное худи с принтом и QR-кодом на рукаве. Модель выполнена из футера. Капюшон со шнурком, манжеты и широкая резинка на талии в рубчик.', 'publish', 'closed', 'closed', '', 'tjomno-seroe-ukorochennoe-hudi-s-printom', '', '', '2021-06-03 18:52:39', '2021-06-03 15:52:39', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=122', 0, 'product', '', 0),
(123, 1, '2021-06-03 18:52:00', '2021-06-03 15:52:00', '', 'GAC016108-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'gac016108-1-01-300wx300h', '', '', '2021-06-03 18:52:00', '2021-06-03 15:52:00', '', 122, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/gac016108-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(124, 1, '2021-06-03 18:53:53', '2021-06-03 15:53:53', 'Тёмно-серые спортивные брюки выполнены из мягкого футера. Фасон Jogger: свободный крой, зауженный силуэт, эластичный пояс, манжеты, карманы.', 'ТЁМНО-СЕРЫЕ СПОРТИВНЫЕ БРЮКИ', 'Тёмно-серые спортивные брюки выполнены из мягкого футера. Фасон Jogger: свободный крой, зауженный силуэт, эластичный пояс, манжеты, карманы.', 'publish', 'closed', 'closed', '', 'tjomno-serye-sportivnye-brjuki', '', '', '2021-06-03 18:53:53', '2021-06-03 15:53:53', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=124', 0, 'product', '', 0),
(125, 1, '2021-06-03 18:53:07', '2021-06-03 15:53:07', '', 'GAC016154-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'gac016154-1-01-300wx300h', '', '', '2021-06-03 18:53:07', '2021-06-03 15:53:07', '', 124, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/gac016154-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(126, 1, '2021-06-03 18:55:15', '2021-06-03 15:55:15', '<div class=\"product-information specifications-wrapper\">\r\n<div class=\"product-information__content\">\r\n<div class=\"product-information__item\">\r\n<div class=\"product-care\">Оливковая укорочённая толстовка с молнией и капюшоном. Модель выполнена из футера и дополнена тесьмой с надписями на горловине и пуллере молнии. Заниженная линия плеча, манжеты и эластичный низ.</div>\r\n</div>\r\n</div>\r\n</div>', 'ОЛИВКОВАЯ УКОРОЧЕННАЯ ТОЛСТОВКА', 'Оливковая укорочённая толстовка с молнией и капюшоном. Модель выполнена из футера и дополнена тесьмой с надписями на горловине и пуллере молнии. Заниженная линия плеча, манжеты и эластичный низ.', 'publish', 'closed', 'closed', '', 'olivkovaja-ukorochennaja-tolstovka', '', '', '2021-06-03 18:55:15', '2021-06-03 15:55:15', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=126', 0, 'product', '', 0),
(127, 1, '2021-06-03 18:54:56', '2021-06-03 15:54:56', '', 'GAC016646-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'gac016646-1-01-300wx300h', '', '', '2021-06-03 18:54:56', '2021-06-03 15:54:56', '', 126, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/gac016646-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(128, 1, '2021-06-03 18:55:59', '2021-06-03 15:55:59', 'Зелёные спортивные велосипедки', 'ЗЕЛЁНЫЕ СПОРТИВНЫЕ ВЕЛОСИПЕДКИ', 'Зелёные спортивные велосипедки', 'publish', 'closed', 'closed', '', 'zeljonye-sportivnye-velosipedki', '', '', '2021-06-03 18:55:59', '2021-06-03 15:55:59', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=128', 0, 'product', '', 0),
(129, 1, '2021-06-03 18:55:54', '2021-06-03 15:55:54', '', 'GHS005814-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'ghs005814-1-01-300wx300h', '', '', '2021-06-03 18:55:54', '2021-06-03 15:55:54', '', 128, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/ghs005814-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(130, 1, '2021-06-03 18:56:37', '2021-06-03 15:56:37', 'Облегающие джинсы с высокой талией подчеркнут фигуру. Плотный хлопковый деним с выраженной зернистой структурой обладает эластичными свойствами благодаря прочным эластичным волокнам спандекса. Застёжка на пуговицы, шлёвки для ремня, карманы. Винтажный эффект. Эти джинсы мы изготовили, используя в два раза меньше электроэнергии и воды.', 'ДЖИНСЫ LEGGING WIDE WAIST НА ПУГОВИЦАХ', 'Облегающие джинсы с высокой талией подчеркнут фигуру. Плотный хлопковый деним с выраженной зернистой структурой обладает эластичными свойствами благодаря прочным эластичным волокнам спандекса. Застёжка на пуговицы, шлёвки для ремня, карманы. Винтажный эффект. Эти джинсы мы изготовили, используя в два раза меньше электроэнергии и воды.', 'publish', 'closed', 'closed', '', 'dzhinsy-legging-wide-waist-na-pugovicah', '', '', '2021-06-03 18:56:37', '2021-06-03 15:56:37', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=130', 0, 'product', '', 0),
(131, 1, '2021-06-03 18:56:32', '2021-06-03 15:56:32', '', 'GJN019134-2-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'gjn019134-2-01-300wx300h', '', '', '2021-06-03 18:56:32', '2021-06-03 15:56:32', '', 130, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/gjn019134-2-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(132, 1, '2021-06-03 18:57:15', '2021-06-03 15:57:15', 'Чёрные джинсы − базовая модель. Облегающий фасон Legging: плотная посадка, стандартная талия. Подчеркивает фигуру, повторяет линии силуэта и делает его более подтянутым и стройным. Прочный деним на основе хлопка с содержанием эластичных нитей обладает скульптурирующими свойствами. Застёжка на молнию и пуговицу, шлёвки для ремня, карманы. Эти джинсы мы изготовили, используя в два раза меньше электроэнергии и воды.', 'ЧЁРНЫЕ ДЖИНСЫ LEGGING', 'Чёрные джинсы − базовая модель. Облегающий фасон Legging: плотная посадка, стандартная талия. Подчеркивает фигуру, повторяет линии силуэта и делает его более подтянутым и стройным. Прочный деним на основе хлопка с содержанием эластичных нитей обладает скульптурирующими свойствами. Застёжка на молнию и пуговицу, шлёвки для ремня, карманы. Эти джинсы мы изготовили, используя в два раза меньше электроэнергии и воды.', 'publish', 'closed', 'closed', '', 'chjornye-dzhinsy-legging', '', '', '2021-06-03 18:57:15', '2021-06-03 15:57:15', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=132', 0, 'product', '', 0),
(133, 1, '2021-06-03 18:57:12', '2021-06-03 15:57:12', '', 'GJN019502-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'gjn019502-1-01-300wx300h', '', '', '2021-06-03 18:57:12', '2021-06-03 15:57:12', '', 132, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/gjn019502-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(135, 1, '2021-06-03 19:01:43', '2021-06-03 16:01:43', 'Чёрный свитшот с рельефным принтом выполнен из футера. Свободный крой, круглый вырез горловины, длинные рукава с манжетами.', 'ЧЁРНЫЙ СВИТШОТ С РЕЛЬЕФНЫМ ПРИНТОМ', 'Чёрный свитшот с рельефным принтом выполнен из футера. Свободный крой, круглый вырез горловины, длинные рукава с манжетами.', 'publish', 'closed', 'closed', '', 'chjornyj-svitshot-s-relefnym-printom', '', '', '2021-06-03 19:01:43', '2021-06-03 16:01:43', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=135', 0, 'product', '', 0),
(136, 1, '2021-06-03 19:01:32', '2021-06-03 16:01:32', '', 'BAC008663-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bac008663-1-01-300wx300h', '', '', '2021-06-03 19:01:32', '2021-06-03 16:01:32', '', 135, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bac008663-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(137, 1, '2021-06-03 19:02:36', '2021-06-03 16:02:36', 'Чёрные спортивные брюки с рельефным принтом выполнены из футера. Фасон Jogger: свободная посадка, зауженный крой, эластичный пояс со шнурком, манжеты, карманы.', 'ЧЁРНЫЕ СПОРТИВНЫЕ БРЮКИ С РЕЛЬЕФНЫМ ПРИНТОМ ДЛЯ МАЛЬЧИКА', 'Чёрные спортивные брюки с рельефным принтом выполнены из футера. Фасон Jogger: свободная посадка, зауженный крой, эластичный пояс со шнурком, манжеты, карманы.', 'publish', 'closed', 'closed', '', 'chjornye-sportivnye-brjuki-s-relefnym-printom-dlja-malchika', '', '', '2021-06-03 19:02:36', '2021-06-03 16:02:36', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=137', 0, 'product', '', 0),
(138, 1, '2021-06-03 19:02:30', '2021-06-03 16:02:30', '', 'BAC008678-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bac008678-1-01-300wx300h', '', '', '2021-06-03 19:02:30', '2021-06-03 16:02:30', '', 137, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bac008678-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(139, 1, '2021-06-03 19:03:08', '2021-06-03 16:03:08', 'Чёрные брюки с контрастной отделкой по бокам выполнены из футера. Фасон Jogger: свободная посадка, зауженный крой, эластичный пояс со шнурком, манжеты, карманы.', 'ЧЁРНЫЕ БРЮКИ-ДЖОГГЕРЫ ДЛЯ МАЛЬЧИКА', 'Чёрные брюки с контрастной отделкой по бокам выполнены из футера. Фасон Jogger: свободная посадка, зауженный крой, эластичный пояс со шнурком, манжеты, карманы.', 'publish', 'closed', 'closed', '', 'chjornye-brjuki-dzhoggery-dlja-malchika', '', '', '2021-06-03 19:03:08', '2021-06-03 16:03:08', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=139', 0, 'product', '', 0),
(140, 1, '2021-06-03 19:02:54', '2021-06-03 16:02:54', '', 'BAC008927-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bac008927-1-01-300wx300h', '', '', '2021-06-03 19:02:54', '2021-06-03 16:02:54', '', 139, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bac008927-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(141, 1, '2021-06-03 19:03:50', '2021-06-03 16:03:50', 'Светло-зелёное худи с принтом выполнено из хлопкового футера. Свободный крой oversize, капюшон со шнурком, длинные рукава с заниженной линией плеча, манжеты и эластичный низ.', 'СВЕТЛО-ЗЕЛЁНОЕ ХУДИ OVERSIZE С ПРИНТОМ', 'Светло-зелёное худи с принтом выполнено из хлопкового футера. Свободный крой oversize, капюшон со шнурком, длинные рукава с заниженной линией плеча, манжеты и эластичный низ.', 'publish', 'closed', 'closed', '', 'svetlo-zeljonoe-hudi-oversize-s-printom', '', '', '2021-06-03 19:03:50', '2021-06-03 16:03:50', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=141', 0, 'product', '', 0),
(142, 1, '2021-06-03 19:03:44', '2021-06-03 16:03:44', '', 'BAC008974-2-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bac008974-2-01-300wx300h', '', '', '2021-06-03 19:03:44', '2021-06-03 16:03:44', '', 141, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bac008974-2-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(143, 1, '2021-06-03 19:04:22', '2021-06-03 16:04:22', 'Чёрная толстовка свободного фасона oversize выполнена из хлопкового футера. Двойной капюшон, заниженная линия плеча, застёжка на молнию, карманы.', 'ЧЁРНАЯ ТОЛСТОВКА OVERSIZE ДЛЯ МАЛЬЧИКА', 'Чёрная толстовка свободного фасона oversize выполнена из хлопкового футера. Двойной капюшон, заниженная линия плеча, застёжка на молнию, карманы.', 'publish', 'closed', 'closed', '', 'chjornaja-tolstovka-oversize-dlja-malchika', '', '', '2021-06-03 19:04:22', '2021-06-03 16:04:22', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=143', 0, 'product', '', 0),
(144, 1, '2021-06-03 19:04:06', '2021-06-03 16:04:06', '', 'BAC009119-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bac009119-1-01-300wx300h', '', '', '2021-06-03 19:04:06', '2021-06-03 16:04:06', '', 143, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bac009119-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(145, 1, '2021-06-03 19:04:57', '2021-06-03 16:04:57', 'Тёмно-синее худи с готическим принтом выполнено из плотного хлопкового футера. Свободный крой, капюшон со шнурком, длинные рукава с заниженной линией плеча, карман-кенгуру, манжеты и эластичный низ. Сочетается с брюками BAC009205.', 'ТЁМНО-СИНЕЕ ХУДИ OVERSIZE С ПРИНТОМ ДЛЯ МАЛЬЧИКА', 'Тёмно-синее худи с готическим принтом выполнено из плотного хлопкового футера. Свободный крой, капюшон со шнурком, длинные рукава с заниженной линией плеча, карман-кенгуру, манжеты и эластичный низ. Сочетается с брюками BAC009205.', 'publish', 'closed', 'closed', '', 'tjomno-sinee-hudi-oversize-s-printom-dlja-malchika', '', '', '2021-06-03 19:04:57', '2021-06-03 16:04:57', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=145', 0, 'product', '', 0),
(146, 1, '2021-06-03 19:04:42', '2021-06-03 16:04:42', '', 'BAC009203-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bac009203-1-01-300wx300h', '', '', '2021-06-03 19:04:42', '2021-06-03 16:04:42', '', 145, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bac009203-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(148, 1, '2021-06-03 19:05:37', '2021-06-03 16:05:37', 'Светло-салатовое худи с принтом на груди и спине выполнено из футера. Свободный крой oversize, капюшон со шнурком, длинные рукава с заниженной линией плеча, манжеты и эластичный низ.', 'СВЕТЛО-САЛАТОВОЕ ХУДИ OVERSIZE С ПРИНТОМ ДЛЯ МАЛЬЧИКА', 'Светло-салатовое худи с принтом на груди и спине выполнено из футера. Свободный крой oversize, капюшон со шнурком, длинные рукава с заниженной линией плеча, манжеты и эластичный низ.', 'publish', 'closed', 'closed', '', 'svetlo-salatovoe-hudi-oversize-s-printom-dlja-malchika', '', '', '2021-06-03 19:05:37', '2021-06-03 16:05:37', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=148', 0, 'product', '', 0),
(149, 1, '2021-06-03 19:05:24', '2021-06-03 16:05:24', '', 'BAC009320-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bac009320-1-01-300wx300h', '', '', '2021-06-03 19:05:24', '2021-06-03 16:05:24', '', 148, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bac009320-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(150, 1, '2021-06-03 19:06:26', '2021-06-03 16:06:26', 'Серое худи с текстовым принтом выполнено из хлопкового меланжевого футера. Свободный крой oversize, капюшон с молнией, заниженная линия плеча, карман-кенгуру.', 'СЕРОЕ ХУДИ OVERSIZE С ПРИНТОМ ДЛЯ МАЛЬЧИКА', 'Серое худи с текстовым принтом выполнено из хлопкового меланжевого футера. Свободный крой oversize, капюшон с молнией, заниженная линия плеча, карман-кенгуру.', 'publish', 'closed', 'closed', '', 'seroe-hudi-oversize-s-printom-dlja-malchika', '', '', '2021-06-03 19:06:29', '2021-06-03 16:06:29', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=150', 0, 'product', '', 0),
(151, 1, '2021-06-03 19:06:21', '2021-06-03 16:06:21', '', 'BAC009329-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bac009329-1-01-300wx300h', '', '', '2021-06-03 19:06:21', '2021-06-03 16:06:21', '', 150, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bac009329-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(152, 1, '2021-06-03 19:07:04', '2021-06-03 16:07:04', 'Бежевое худи с принтом выполнено из футера. Свободный крой oversize, капюшон со шнурком, заниженная линия плеча, манжеты и вставка внизу из трикотажной резинки в рубчик.', 'БЕЖЕВОЕ ХУДИ OVERSIZE С ПРИНТОМ ДЛЯ МАЛЬЧИКА', 'Бежевое худи с принтом выполнено из футера. Свободный крой oversize, капюшон со шнурком, заниженная линия плеча, манжеты и вставка внизу из трикотажной резинки в рубчик.', 'publish', 'closed', 'closed', '', 'bezhevoe-hudi-oversize-s-printom-dlja-malchika', '', '', '2021-06-03 19:07:12', '2021-06-03 16:07:12', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=152', 0, 'product', '', 0),
(153, 1, '2021-06-03 19:06:53', '2021-06-03 16:06:53', '', 'BAC009521-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bac009521-1-01-300wx300h', '', '', '2021-06-03 19:06:53', '2021-06-03 16:06:53', '', 152, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bac009521-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(154, 1, '2021-06-03 19:07:45', '2021-06-03 16:07:45', 'Бежевые брюки-карго выполнены из смесового футера. Фасон Jogger: эластичный пояс со шнурком и резинки на штанинах. Боковые карманы и карманы-карго с клапанами.', 'БЕЖЕВЫЕ СПОРТИВНЫЕ БРЮКИ-КАРГО ДЛЯ МАЛЬЧИКА', 'Бежевые брюки-карго выполнены из смесового футера. Фасон Jogger: эластичный пояс со шнурком и резинки на штанинах. Боковые карманы и карманы-карго с клапанами.', 'publish', 'closed', 'closed', '', 'bezhevye-sportivnye-brjuki-kargo-dlja-malchika', '', '', '2021-06-03 19:07:45', '2021-06-03 16:07:45', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=154', 0, 'product', '', 0),
(155, 1, '2021-06-03 19:07:30', '2021-06-03 16:07:30', '', 'BAC009523-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bac009523-1-01-300wx300h', '', '', '2021-06-03 19:07:30', '2021-06-03 16:07:30', '', 154, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bac009523-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(156, 1, '2021-06-03 19:10:10', '2021-06-03 16:10:10', 'Чёрная футболка со светоотражающим принтом выполнена из хлопкового трикотажа джерси. Свободный крой oversize, круглый вырез горловины, короткие рукава с заниженной линией плеча.', 'ЧЁРНАЯ ФУТБОЛКА OVERSIZE СО СВЕТООТРАЖАЮЩИМ ПРИНТОМ', 'Чёрная футболка со светоотражающим принтом выполнена из хлопкового трикотажа джерси. Свободный крой oversize, круглый вырез горловины, короткие рукава с заниженной линией плеча.', 'publish', 'closed', 'closed', '', 'chjornaja-futbolka-oversize-so-svetootrazhajushhim-printom', '', '', '2021-06-03 19:10:10', '2021-06-03 16:10:10', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=156', 0, 'product', '', 0),
(157, 1, '2021-06-03 19:10:02', '2021-06-03 16:10:02', '', 'BKT008522-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bkt008522-1-01-300wx300h', '', '', '2021-06-03 19:10:02', '2021-06-03 16:10:02', '', 156, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bkt008522-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(158, 1, '2021-06-03 19:10:51', '2021-06-03 16:10:51', 'Чёрные брюки с лампасами выполнены из хлопкового стрейч-твила. Свободный фасон Jogger-oversize: эластичный пояс со шнурком, резинки на штанинах внизу, карманы.', 'ЧЁРНЫЕ БРЮКИ JOGGER-OVERSIZE ДЛЯ МАЛЬЧИКА', 'Чёрные брюки с лампасами выполнены из хлопкового стрейч-твила. Свободный фасон Jogger-oversize: эластичный пояс со шнурком, резинки на штанинах внизу, карманы.', 'publish', 'closed', 'closed', '', 'chjornye-brjuki-jogger-oversize-dlja-malchika', '', '', '2021-06-03 19:10:51', '2021-06-03 16:10:51', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=158', 0, 'product', '', 0),
(159, 1, '2021-06-03 19:10:36', '2021-06-03 16:10:36', '', 'BPT002772-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bpt002772-1-01-300wx300h', '', '', '2021-06-03 19:10:36', '2021-06-03 16:10:36', '', 158, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bpt002772-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(160, 1, '2021-06-03 19:11:46', '2021-06-03 16:11:46', 'Чёрное худи с принтом выполнено из футера. Укороченный силуэт, капюшон, длинные рукава с заниженной линией плеча и манжетами.', 'ЧЁРНОЕ ХУДИ С ПРИНТОМ YOU\'RE THE ONE ДЛЯ ДЕВОЧКИ', 'Чёрное худи с принтом выполнено из футера. Укороченный силуэт, капюшон, длинные рукава с заниженной линией плеча и манжетами.', 'publish', 'closed', 'closed', '', 'chjornoe-hudi-s-printom-you-re-the-one-dlja-devochki', '', '', '2021-06-03 19:11:46', '2021-06-03 16:11:46', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=160', 0, 'product', '', 0),
(161, 1, '2021-06-03 19:11:42', '2021-06-03 16:11:42', '', 'GAC016382-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'gac016382-1-01-300wx300h', '', '', '2021-06-03 19:11:42', '2021-06-03 16:11:42', '', 160, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/gac016382-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(162, 1, '2021-06-03 19:12:22', '2021-06-03 16:12:22', 'Фиолетовое худи с принтом 24/7 выполнено из хлопкового футера. Капюшон, цельнокроеные рукава с манжетами, резинка внизу.', 'ФИОЛЕТОВОЕ ХУДИ С ПРИНТОМ 24/7 ДЛЯ ДЕВОЧКИ', 'Фиолетовое худи с принтом 24/7 выполнено из хлопкового футера. Капюшон, цельнокроеные рукава с манжетами, резинка внизу.', 'publish', 'closed', 'closed', '', 'fioletovoe-hudi-s-printom-24-7-dlja-devochki', '', '', '2021-06-03 19:12:22', '2021-06-03 16:12:22', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=162', 0, 'product', '', 0),
(163, 1, '2021-06-03 19:12:03', '2021-06-03 16:12:03', '', 'GAC016395-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'gac016395-1-01-300wx300h', '', '', '2021-06-03 19:12:03', '2021-06-03 16:12:03', '', 162, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/gac016395-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(164, 1, '2021-06-03 19:13:17', '2021-06-03 16:13:17', 'Голубой свитшот с принтом выполнен из плотного хлопкового футера. Суперсвободный крой oversize, длинные рукава с заниженной линией плеча, манжеты и эластичный низ. Сочетается со спортивными брюками GAC016872.', 'ГОЛУБОЙ СВИТШОТ OVERSIZE С ПРИНТОМ BALANCE ДЛЯ ДЕВОЧКИ', 'Голубой свитшот с принтом выполнен из плотного хлопкового футера. Суперсвободный крой oversize, длинные рукава с заниженной линией плеча, манжеты и эластичный низ. Сочетается со спортивными брюками GAC016872.', 'publish', 'closed', 'closed', '', 'goluboj-svitshot-oversize-s-printom-balance-dlja-devochki', '', '', '2021-06-03 19:13:17', '2021-06-03 16:13:17', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=164', 0, 'product', '', 0),
(165, 1, '2021-06-03 19:13:14', '2021-06-03 16:13:14', '', 'GAC016705-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'gac016705-1-01-300wx300h', '', '', '2021-06-03 19:13:14', '2021-06-03 16:13:14', '', 164, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/gac016705-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(166, 1, '2021-06-03 19:13:52', '2021-06-03 16:13:52', 'Бежевое худи с принтом выполнено из плотного хлопкового футера. Суперсвободный крой oversize, капюшон, длинные рукава с заниженной линией плеча, манжеты и эластичный низ.', 'БЕЖЕВОЕ ХУДИ OVERSIZE С НАДПИСЬЮ ДЛЯ ДЕВОЧКИ', 'Бежевое худи с принтом выполнено из плотного хлопкового футера. Суперсвободный крой oversize, капюшон, длинные рукава с заниженной линией плеча, манжеты и эластичный низ.', 'publish', 'closed', 'closed', '', 'bezhevoe-hudi-oversize-s-nadpisju-dlja-devochki', '', '', '2021-06-03 19:13:52', '2021-06-03 16:13:52', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=166', 0, 'product', '', 0),
(167, 1, '2021-06-03 19:13:46', '2021-06-03 16:13:46', '', 'GAC016876-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'gac016876-1-01-300wx300h', '', '', '2021-06-03 19:13:46', '2021-06-03 16:13:46', '', 166, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/gac016876-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(168, 1, '2021-06-03 19:14:24', '2021-06-03 16:14:24', 'Чёрные джинсы выполнены из эластичного денима. Облегающий силуэт, высокая посадка, застёжка на молнию и пуговицу, шлёвки для ремня, карманы. Мы заботимся о планете, поэтому эти джинсы изготовили, используя в два раза меньше электроэнергии и воды.', 'ЧЁРНЫЕ ДЖИНСЫ LEGGING ДЛЯ ДЕВОЧКИ', 'Чёрные джинсы выполнены из эластичного денима. Облегающий силуэт, высокая посадка, застёжка на молнию и пуговицу, шлёвки для ремня, карманы. Мы заботимся о планете, поэтому эти джинсы изготовили, используя в два раза меньше электроэнергии и воды.', 'publish', 'closed', 'closed', '', 'chjornye-dzhinsy-legging-dlja-devochki', '', '', '2021-06-03 19:14:24', '2021-06-03 16:14:24', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=168', 0, 'product', '', 0),
(169, 1, '2021-06-03 19:14:09', '2021-06-03 16:14:09', '', 'GJN019075-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'gjn019075-1-01-300wx300h', '', '', '2021-06-03 19:14:09', '2021-06-03 16:14:09', '', 168, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/gjn019075-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(170, 1, '2021-06-03 19:15:20', '2021-06-03 16:15:20', 'Шорты-бермуды выполнены из искусственной кожи. Свободный крой, высокая талия, застёжка на молнию, ремень с фастексом, шлёвки.', 'ЧЁРНЫЕ ШОРТЫ ИЗ ЭКОКОЖИ С РЕМНЁМ ДЛЯ ДЕВОЧКИ', 'Шорты-бермуды выполнены из искусственной кожи. Свободный крой, высокая талия, застёжка на молнию, ремень с фастексом, шлёвки.', 'publish', 'closed', 'closed', '', 'chjornye-shorty-iz-jekokozhi-s-remnjom-dlja-devochki', '', '', '2021-06-03 19:15:20', '2021-06-03 16:15:20', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=170', 0, 'product', '', 0),
(171, 1, '2021-06-03 19:15:12', '2021-06-03 16:15:12', '', 'GSE000802-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'gse000802-1-01-300wx300h', '', '', '2021-06-03 19:15:12', '2021-06-03 16:15:12', '', 170, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/gse000802-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(172, 1, '2021-06-03 19:17:35', '2021-06-03 16:17:35', 'Розовый свитшот с принтом выполнен из мягкого футера с начёсом. Прямой крой, круглый вырез горловины, застёжка на кнопки на плече, длинные рукава с заниженной линией плеча, манжеты и эластичный низ. Принт дополнен глиттером.', 'РОЗОВЫЙ СВИТШОТ С ПРИНТОМ LOVE YOU ДЛЯ ДЕВОЧКИ', 'Розовый свитшот с принтом выполнен из мягкого футера с начёсом. Прямой крой, круглый вырез горловины, застёжка на кнопки на плече, длинные рукава с заниженной линией плеча, манжеты и эластичный низ. Принт дополнен глиттером.', 'publish', 'closed', 'closed', '', 'rozovyj-svitshot-s-printom-love-you-dlja-devochki', '', '', '2021-06-03 19:17:35', '2021-06-03 16:17:35', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=172', 0, 'product', '', 0),
(173, 1, '2021-06-03 19:17:05', '2021-06-03 16:17:05', '', 'GAC015220-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'gac015220-1-01-300wx300h', '', '', '2021-06-03 19:17:05', '2021-06-03 16:17:05', '', 172, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/gac015220-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(174, 1, '2021-06-03 19:18:25', '2021-06-03 16:18:25', 'Бежевый свитшот из смесового футера с принтом в виде динозавров. Прямой крой, круглый вырез горловины, манжеты, трикотажная резинка снизу. Модель представлена в двух вариантах: с застёжкой на пуговицы на плече для малышей до двух лет и без застёжки для детей от двух лет.', 'БЕЖЕВЫЙ СВИТШОТ С ДИНОЗАВРАМИ ДЛЯ МАЛЬЧИКА', 'Бежевый свитшот из смесового футера с принтом в виде динозавров. Прямой крой, круглый вырез горловины, манжеты, трикотажная резинка снизу. Модель представлена в двух вариантах: с застёжкой на пуговицы на плече для малышей до двух лет и без застёжки для детей от двух лет.', 'publish', 'closed', 'closed', '', 'bezhevyj-svitshot-s-dinozavrami-dlja-malchika', '', '', '2021-06-03 19:18:25', '2021-06-03 16:18:25', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=174', 0, 'product', '', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(175, 1, '2021-06-03 19:18:07', '2021-06-03 16:18:07', '', 'BAC008635-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bac008635-1-01-300wx300h', '', '', '2021-06-03 19:18:07', '2021-06-03 16:18:07', '', 174, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bac008635-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(178, 1, '2021-06-03 19:19:16', '2021-06-03 16:19:16', 'Светло-розовое худи с принтом Тролли выполнено из хлопкового футера. Прямой крой, капюшон, короткие рукава с заниженной линией плеча, резинка снизу.', 'СВЕТЛО-РОЗОВОЕ ХУДИ С ПРИНТОМ ТРОЛЛИ И КОРОТКИМИ РУКАВАМИ ДЛЯ ДЕВОЧКИ', 'Светло-розовое худи с принтом Тролли выполнено из хлопкового футера. Прямой крой, капюшон, короткие рукава с заниженной линией плеча, резинка снизу.', 'publish', 'closed', 'closed', '', 'svetlo-rozovoe-hudi-s-printom-trolli-i-korotkimi-rukavami-dlja-devochki', '', '', '2021-06-03 19:19:16', '2021-06-03 16:19:16', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=178', 0, 'product', '', 0),
(179, 1, '2021-06-03 19:19:13', '2021-06-03 16:19:13', '', 'GAC016893-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'gac016893-1-01-300wx300h', '', '', '2021-06-03 19:19:13', '2021-06-03 16:19:13', '', 178, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/gac016893-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(180, 1, '2021-06-03 19:20:03', '2021-06-03 16:20:03', 'Жёлтый сарафан с принтом выполнен из ткани оксфорд. Силуэт-трапеция, резинка на талии, лямки с оборками.', 'ЖЁЛТЫЙ САРАФАН С ЛИМОНАМИ ДЛЯ ДЕВОЧКИ', 'Жёлтый сарафан с принтом выполнен из ткани оксфорд. Силуэт-трапеция, резинка на талии, лямки с оборками.', 'publish', 'closed', 'closed', '', 'zhjoltyj-sarafan-s-limonami-dlja-devochki', '', '', '2021-06-03 19:20:03', '2021-06-03 16:20:03', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=180', 0, 'product', '', 0),
(181, 1, '2021-06-03 19:19:49', '2021-06-03 16:19:49', '', 'GDR023818-2-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'gdr023818-2-01-300wx300h', '', '', '2021-06-03 19:19:49', '2021-06-03 16:19:49', '', 180, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/gdr023818-2-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(183, 1, '2021-06-03 19:20:53', '2021-06-03 16:20:53', 'Джинсы выполнены из хлопкового денима. Посадка Paperbag: высокая талия с эластичным поясом и присборенностями. Зауженный от колен силуэт, два кармана, небольшая нашивка. декоративные пуговицы. Эти джинсы мы изготовили, используя в два раза меньше воды и электроэнергии.', 'ДЖИНСЫ LOOSE С ВЫСОКОЙ ТАЛИЕЙ ДЛЯ ДЕВОЧКИ', 'Джинсы выполнены из хлопкового денима. Посадка Paperbag: высокая талия с эластичным поясом и присборенностями. Зауженный от колен силуэт, два кармана, небольшая нашивка. декоративные пуговицы. Эти джинсы мы изготовили, используя в два раза меньше воды и электроэнергии.', 'publish', 'closed', 'closed', '', 'dzhinsy-loose-s-vysokoj-taliej-dlja-devochki', '', '', '2021-06-03 19:20:53', '2021-06-03 16:20:53', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=183', 0, 'product', '', 0),
(184, 1, '2021-06-03 19:20:49', '2021-06-03 16:20:49', '', 'GJN019025-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'gjn019025-1-01-300wx300h', '', '', '2021-06-03 19:20:49', '2021-06-03 16:20:49', '', 183, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/gjn019025-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(185, 1, '2021-06-03 19:21:54', '2021-06-03 16:21:54', 'Сиреневая футболка с принтом выполнена из хлопкового трикотажа джерси. Свободный крой oversize, круглый вырез горловины, короткие рукава с заниженной линией плеча. Принт дополнен глиттером.', 'СИРЕНЕВАЯ ФУТБОЛКА OVERSIZE С ПРИНТОМ HELLO PARADISE ДЛЯ ДЕВОЧКИ', 'Сиреневая футболка с принтом выполнена из хлопкового трикотажа джерси. Свободный крой oversize, круглый вырез горловины, короткие рукава с заниженной линией плеча. Принт дополнен глиттером.', 'publish', 'closed', 'closed', '', 'sirenevaja-futbolka-oversize-s-printom-hello-paradise-dlja-devochki', '', '', '2021-06-03 19:21:54', '2021-06-03 16:21:54', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=185', 0, 'product', '', 0),
(186, 1, '2021-06-03 19:21:50', '2021-06-03 16:21:50', '', 'GKT014320-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'gkt014320-1-01-300wx300h', '', '', '2021-06-03 19:21:50', '2021-06-03 16:21:50', '', 185, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/gkt014320-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(188, 1, '2021-06-03 19:23:13', '2021-06-03 16:23:13', 'Розовые шорты из коллекции «Тролли» выполнены из хлопкового футера. Свободный спортивный фасон с талией Paperbag: эластичная талия с присборенностями. Два кармана.', 'СВЕТЛО-РОЗОВЫЕ ШОРТЫ «ТРОЛЛИ» ДЛЯ ДЕВОЧКИ', 'Розовые шорты из коллекции «Тролли» выполнены из хлопкового футера. Свободный спортивный фасон с талией Paperbag: эластичная талия с присборенностями. Два кармана.', 'publish', 'closed', 'closed', '', 'svetlo-rozovye-shorty-trolli-dlja-devochki', '', '', '2021-06-03 19:23:13', '2021-06-03 16:23:13', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=188', 0, 'product', '', 0),
(189, 1, '2021-06-03 19:23:00', '2021-06-03 16:23:00', '', 'GSH008072-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'gsh008072-1-01-300wx300h', '', '', '2021-06-03 19:23:00', '2021-06-03 16:23:00', '', 188, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/gsh008072-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(190, 1, '2021-06-03 19:24:18', '2021-06-03 16:24:18', 'Серые брюки-джоггеры с бульдогами выполнены из мягкой смесовой ткани. Фасон джоггер: эластичный пояс, манжеты. Имитация карманов.', 'СЕРЫЕ БРЮКИ-ДЖОГГЕРЫ С БУЛЬДОГАМИ ДЛЯ МАЛЬЧИКА', 'Серые брюки-джоггеры с бульдогами выполнены из мягкой смесовой ткани. Фасон джоггер: эластичный пояс, манжеты. Имитация карманов.', 'publish', 'closed', 'closed', '', 'serye-brjuki-dzhoggery-s-buldogami-dlja-malchika', '', '', '2021-06-03 19:24:18', '2021-06-03 16:24:18', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=190', 0, 'product', '', 0),
(191, 1, '2021-06-03 19:24:13', '2021-06-03 16:24:13', '', 'BAC008612-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bac008612-1-01-300wx300h', '', '', '2021-06-03 19:24:13', '2021-06-03 16:24:13', '', 190, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bac008612-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(192, 1, '2021-06-03 19:26:00', '2021-06-03 16:26:00', 'Серый свитшот с бульдогами выполнен из мягкой ткани. Прямой крой, круглый вырез горловины, манжеты и эластичный низ.', 'СЕРЫЙ СВИТШОТ С БУЛЬДОГАМИ ДЛЯ МАЛЬЧИКА', 'Серый свитшот с бульдогами выполнен из мягкой ткани. Прямой крой, круглый вырез горловины, манжеты и эластичный низ.', 'publish', 'closed', 'closed', '', 'seryj-svitshot-s-buldogami-dlja-malchika', '', '', '2021-06-03 19:26:00', '2021-06-03 16:26:00', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=192', 0, 'product', '', 0),
(193, 1, '2021-06-03 19:25:48', '2021-06-03 16:25:48', '', 'BAC008627-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bac008627-1-01-300wx300h', '', '', '2021-06-03 19:25:48', '2021-06-03 16:25:48', '', 192, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bac008627-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(194, 1, '2021-06-03 19:26:28', '2021-06-03 16:26:28', 'Спортивные брюки в стиле колор-блок выполнены из мягкого футера с начёсом. Фасон Jogger: свободная посадка, зауженный крой, эластичный пояс со шнурком, манжеты, карманы.', 'СПОРТИВНЫЕ БРЮКИ КОЛОР-БЛОК ДЛЯ МАЛЬЧИКА', 'Спортивные брюки в стиле колор-блок выполнены из мягкого футера с начёсом. Фасон Jogger: свободная посадка, зауженный крой, эластичный пояс со шнурком, манжеты, карманы.', 'publish', 'closed', 'closed', '', 'sportivnye-brjuki-kolor-blok-dlja-malchika', '', '', '2021-06-03 19:26:28', '2021-06-03 16:26:28', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=194', 0, 'product', '', 0),
(195, 1, '2021-06-03 19:26:17', '2021-06-03 16:26:17', '', 'BAC008712-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bac008712-1-01-300wx300h', '', '', '2021-06-03 19:26:17', '2021-06-03 16:26:17', '', 194, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bac008712-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(199, 1, '2021-06-03 19:27:39', '2021-06-03 16:27:39', 'Розовый комбинезон с принтом для девочки', 'РОЗОВЫЙ КОМБИНЕЗОН С ПРИНТОМ ДЛЯ ДЕВОЧКИ', 'Розовый комбинезон с принтом для девочки', 'publish', 'closed', 'closed', '', 'rozovyj-kombinezon-s-printom-dlja-devochki', '', '', '2021-06-03 19:27:40', '2021-06-03 16:27:40', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=199', 0, 'product', '', 0),
(200, 1, '2021-06-03 19:27:27', '2021-06-03 16:27:27', '', 'GCV000269-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'gcv000269-1-01-300wx300h', '', '', '2021-06-03 19:27:27', '2021-06-03 16:27:27', '', 199, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/gcv000269-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(201, 1, '2021-06-03 19:28:56', '2021-06-03 16:28:56', 'Комплект одежды с космическим принтом для малыша: жёлтая футболка с кнопками на плече, серое боди-лонгслив с плечиками внахлёст и кнопками снизу, серые брюки с резинкой. Изделия выполнены из хлопкового трикотажа.', 'КОМПЛЕКТ ОДЕЖДЫ ДЛЯ МАЛЫША', 'Комплект одежды с космическим принтом для малыша: жёлтая футболка с кнопками на плече, серое боди-лонгслив с плечиками внахлёст и кнопками снизу, серые брюки с резинкой. Изделия выполнены из хлопкового трикотажа.', 'publish', 'closed', 'closed', '', 'komplekt-odezhdy-dlja-malysha', '', '', '2021-06-03 19:28:56', '2021-06-03 16:28:56', '', 0, 'https://manufacturer-cloth.ru/?post_type=product&#038;p=201', 0, 'product', '', 0),
(202, 1, '2021-06-03 19:28:54', '2021-06-03 16:28:54', '', 'BSE000492-1-01-300Wx300H', '', 'inherit', 'open', 'closed', '', 'bse000492-1-01-300wx300h', '', '', '2021-06-03 19:28:54', '2021-06-03 16:28:54', '', 201, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/bse000492-1-01-300wx300h.jpg', 0, 'attachment', 'image/jpeg', 0),
(203, 1, '2021-06-03 22:00:40', '2021-06-03 19:00:40', ' ', '', '', 'publish', 'closed', 'closed', '', '203', '', '', '2021-06-03 22:00:40', '2021-06-03 19:00:40', '', 0, 'https://manufacturer-cloth.ru/?p=203', 3, 'nav_menu_item', '', 0),
(204, 1, '2021-06-03 22:00:40', '2021-06-03 19:00:40', ' ', '', '', 'publish', 'closed', 'closed', '', '204', '', '', '2021-06-03 22:00:40', '2021-06-03 19:00:40', '', 0, 'https://manufacturer-cloth.ru/?p=204', 2, 'nav_menu_item', '', 0),
(205, 1, '2021-06-03 22:00:40', '2021-06-03 19:00:40', ' ', '', '', 'publish', 'closed', 'closed', '', '205', '', '', '2021-06-03 22:00:40', '2021-06-03 19:00:40', '', 0, 'https://manufacturer-cloth.ru/?p=205', 1, 'nav_menu_item', '', 0),
(206, 1, '2021-06-03 23:13:39', '2021-06-03 20:13:39', '', 'Order &ndash; 3 июня, 2021 @ 11:13 ПП', '', 'wc-completed', 'closed', 'closed', 'wc_order_kTyLuI2wujVpB', 'zakaz-ndash-03-jun-2021-v-20-13', '', '', '2021-06-03 23:29:50', '2021-06-03 20:29:50', '', 0, 'https://manufacturer-cloth.ru/?post_type=shop_order&#038;p=206', 0, 'shop_order', '', 2),
(207, 1, '2021-06-04 00:04:33', '2021-06-03 21:04:33', '<!-- wp:html -->\n<p>Бренд модной женской одежды и аксессуаров в 2021 году.</p><p>Наши дизайнеры вдохновляются последними мировыми трендами для того, чтобы дать каждой женщине возможность подобрать то, что лучше всего подходит именно ей и отражает ее индивидуальность.</p><p>Мы внимательно относимся к выбору материалов, чтобы созданные нами изделия в течение долгого времени сохраняли первоначальный вид.</p>\n<!-- /wp:html -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'О компании', '', 'inherit', 'closed', 'closed', '', '32-autosave-v1', '', '', '2021-06-04 00:04:33', '2021-06-03 21:04:33', '', 32, 'https://manufacturer-cloth.ru/?p=207', 0, 'revision', '', 0),
(209, 1, '2021-06-03 23:34:54', '2021-06-03 20:34:54', '', 'about-company', '', 'inherit', 'open', 'closed', '', 'about-company', '', '', '2021-06-03 23:34:54', '2021-06-03 20:34:54', '', 32, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/about-company.jpg', 0, 'attachment', 'image/jpeg', 0),
(210, 1, '2021-06-03 23:34:58', '2021-06-03 20:34:58', '<!-- wp:paragraph -->\n<p>Бренд модной женской одежды и аксессуаров в 2021 году.<br><br>Наши дизайнеры вдохновляются последними мировыми трендами для того, чтобы дать каждой женщине возможность подобрать то, что лучше всего подходит именно ей и отражает ее индивидуальность.<br><br>Мы внимательно относимся к выбору материалов, чтобы созданные нами изделия в течение долгого времени сохраняли первоначальный вид.</p>\n<!-- /wp:paragraph -->', 'О компании', '', 'inherit', 'closed', 'closed', '', '32-revision-v1', '', '', '2021-06-03 23:34:58', '2021-06-03 20:34:58', '', 32, 'https://manufacturer-cloth.ru/?p=210', 0, 'revision', '', 0),
(211, 1, '2021-06-04 00:04:20', '2021-06-03 21:04:20', '<!-- wp:paragraph -->\n<p>Бренд модной женской одежды и аксессуаров в 2021 году.</p><p>Наши дизайнеры вдохновляются последними мировыми трендами для того, чтобы дать каждой женщине возможность подобрать то, что лучше всего подходит именно ей и отражает ее индивидуальность.</p><p>Мы внимательно относимся к выбору материалов, чтобы созданные нами изделия в течение долгого времени сохраняли первоначальный вид.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'О компании', '', 'inherit', 'closed', 'closed', '', '32-revision-v1', '', '', '2021-06-04 00:04:20', '2021-06-03 21:04:20', '', 32, 'https://manufacturer-cloth.ru/?p=211', 0, 'revision', '', 0),
(212, 1, '2021-06-04 00:04:50', '2021-06-03 21:04:50', '<!-- wp:columns -->\n<div class=\"wp-block-columns\"><!-- wp:column {\"width\":\"100%\"} -->\n<div class=\"wp-block-column\" style=\"flex-basis:100%\"><!-- wp:paragraph -->\n<p>Бренд модной женской одежды и аксессуаров в 2021 году.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Наши дизайнеры вдохновляются последними мировыми трендами для того, чтобы дать каждой женщине возможность подобрать то, что лучше всего подходит именно ей и отражает ее индивидуальность.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Мы внимательно относимся к выбору материалов, чтобы созданные нами изделия в течение долгого времени сохраняли первоначальный вид.</p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:column --></div>\n<!-- /wp:columns -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'О компании', '', 'inherit', 'closed', 'closed', '', '32-revision-v1', '', '', '2021-06-04 00:04:50', '2021-06-03 21:04:50', '', 32, 'https://manufacturer-cloth.ru/?p=212', 0, 'revision', '', 0),
(213, 1, '2021-06-04 00:13:56', '2021-06-03 21:13:56', '', 'О нас', '', 'inherit', 'closed', 'closed', '', '35-autosave-v1', '', '', '2021-06-04 00:13:56', '2021-06-03 21:13:56', '', 35, 'https://manufacturer-cloth.ru/?p=213', 0, 'revision', '', 0),
(214, 1, '2021-06-04 00:14:10', '2021-06-03 21:14:10', '<!-- wp:paragraph -->\n<p>MANUFACTURER – бренд первоклассной и доступной одежды для каждого члена семьи. Компания была основана в 1988 году и на сегодняшний день является лидером в сегменте fast fashion в России.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Вертикально-интегрированный ритейлер MANUFACTURER - это более 15 собственных и 200 партнерских производственных фабрик, два современных логистических центра и монобрендовая сеть розничных магазинов, которая на конец 2018 года насчитывала более 550 магазинов в России и СНГ.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Узнаваемость бренда MANUFACTURER составляет 99% среди россиян (согласно рейтингу Fitch, 2018 г.).</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Магазины MANUFACTURER – это место, в котором шопинг для каждого члена семьи будет поистине захватывающим, а не рутинным. Здесь можно найти абсолютно все: от любимых джинсов до модных новинок на каждый сезон. Каждую неделю в магазины поступает более 100 новых моделей.</p>\n<!-- /wp:paragraph -->', 'О нас', '', 'inherit', 'closed', 'closed', '', '35-revision-v1', '', '', '2021-06-04 00:14:10', '2021-06-03 21:14:10', '', 35, 'https://manufacturer-cloth.ru/?p=214', 0, 'revision', '', 0),
(215, 1, '2021-06-04 00:17:50', '2021-06-03 21:17:50', '', 'Image', '', 'inherit', 'open', 'closed', '', 'image', '', '', '2021-06-04 00:17:50', '2021-06-03 21:17:50', '', 35, 'https://manufacturer-cloth.ru/wp-content/uploads/2021/06/image.jpg', 0, 'attachment', 'image/jpeg', 0),
(216, 1, '2021-06-04 00:23:30', '2021-06-03 21:23:30', '<!-- wp:html -->\n<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d86573.42405259634!2d39.666602647336205!3d47.30614266501103!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40e3b7c043ab3f7f%3A0x67fea0b96057f85f!2z0JLQvtGA0L7RiNC40LvQvtCy0YHQutC40LksINCg0L7RgdGC0L7Qsi3QvdCwLdCU0L7QvdGDLCDQoNC-0YHRgtC-0LLRgdC60LDRjyDQvtCx0Lsu!5e0!3m2!1sru!2sru!4v1622755321671!5m2!1sru!2sru\" style=\"width: height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\"></iframe>\n<!-- /wp:html -->', 'Контакты', '', 'inherit', 'closed', 'closed', '', '37-autosave-v1', '', '', '2021-06-04 00:23:30', '2021-06-03 21:23:30', '', 37, 'https://manufacturer-cloth.ru/?p=216', 0, 'revision', '', 0),
(217, 1, '2021-06-04 00:22:56', '2021-06-03 21:22:56', '<!-- wp:html -->\n<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d86573.42405259634!2d39.666602647336205!3d47.30614266501103!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40e3b7c043ab3f7f%3A0x67fea0b96057f85f!2z0JLQvtGA0L7RiNC40LvQvtCy0YHQutC40LksINCg0L7RgdGC0L7Qsi3QvdCwLdCU0L7QvdGDLCDQoNC-0YHRgtC-0LLRgdC60LDRjyDQvtCx0Lsu!5e0!3m2!1sru!2sru!4v1622755321671!5m2!1sru!2sru\" width=\"600\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\"></iframe>\n<!-- /wp:html -->', 'Контакты', '', 'inherit', 'closed', 'closed', '', '37-revision-v1', '', '', '2021-06-04 00:22:56', '2021-06-03 21:22:56', '', 37, 'https://manufacturer-cloth.ru/?p=217', 0, 'revision', '', 0),
(218, 1, '2021-06-04 00:23:32', '2021-06-03 21:23:32', '<!-- wp:html -->\n<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d86573.42405259634!2d39.666602647336205!3d47.30614266501103!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40e3b7c043ab3f7f%3A0x67fea0b96057f85f!2z0JLQvtGA0L7RiNC40LvQvtCy0YHQutC40LksINCg0L7RgdGC0L7Qsi3QvdCwLdCU0L7QvdGDLCDQoNC-0YHRgtC-0LLRgdC60LDRjyDQvtCx0Lsu!5e0!3m2!1sru!2sru!4v1622755321671!5m2!1sru!2sru\" style=\"width:100%\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\"></iframe>\n<!-- /wp:html -->', 'Контакты', '', 'inherit', 'closed', 'closed', '', '37-revision-v1', '', '', '2021-06-04 00:23:32', '2021-06-03 21:23:32', '', 37, 'https://manufacturer-cloth.ru/?p=218', 0, 'revision', '', 0),
(220, 1, '2021-06-15 18:32:35', '2021-06-15 15:32:35', '', 'Order &ndash; 15 июня, 2021 @ 06:32 ПП', '', 'trash', 'open', 'closed', 'wc_order_mWZHeCpMvd4NR', 'zakaz-ndash-15-jun-2021-v-15-32__trashed', '', '', '2021-06-16 02:48:30', '2021-06-15 23:48:30', '', 0, 'https://manufacturer-cloth.ru/?post_type=shop_order&#038;p=220', 0, 'shop_order', '', 1),
(221, 1, '2021-06-16 00:06:51', '2021-06-15 21:06:51', '', 'Order &ndash; 16 июня, 2021 @ 12:06 ДП', '', 'trash', 'open', 'closed', 'wc_order_iQOCPLlNzDZAK', 'zakaz-ndash-15-jun-2021-v-21-06__trashed', '', '', '2021-06-16 02:47:07', '2021-06-15 23:47:07', '', 0, 'https://manufacturer-cloth.ru/?post_type=shop_order&#038;p=221', 0, 'shop_order', '', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_robomarket_orders`
--
-- Создание: Июн 01 2021 г., 18:10
--

DROP TABLE IF EXISTS `wp_robomarket_orders`;
CREATE TABLE `wp_robomarket_orders` (
  `post_id` int(11) NOT NULL COMMENT 'Id поста, он же id заказа',
  `other_id` int(11) NOT NULL COMMENT 'Id на стороне робомаркета'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_sms_stats`
--
-- Создание: Июн 01 2021 г., 18:10
--

DROP TABLE IF EXISTS `wp_sms_stats`;
CREATE TABLE `wp_sms_stats` (
  `sms_id` int(10) UNSIGNED NOT NULL,
  `order_id` int(11) NOT NULL,
  `type` int(1) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `number` varchar(11) NOT NULL,
  `text` text NOT NULL,
  `send_time` datetime DEFAULT NULL,
  `response` text,
  `reply` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_termmeta`
--
-- Создание: Июн 01 2021 г., 08:28
--

DROP TABLE IF EXISTS `wp_termmeta`;
CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_termmeta`
--

INSERT INTO `wp_termmeta` (`meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES
(1, 16, 'order', '0'),
(2, 16, 'product_count_product_cat', '24'),
(3, 17, 'product_count_product_tag', '1'),
(4, 20, 'order', '0'),
(5, 20, 'display_type', ''),
(6, 20, 'thumbnail_id', '0'),
(7, 21, 'order', '0'),
(8, 21, 'display_type', ''),
(9, 21, 'thumbnail_id', '0'),
(10, 22, 'order', '0'),
(11, 22, 'display_type', ''),
(12, 22, 'thumbnail_id', '0'),
(13, 15, 'product_count_product_cat', '0'),
(14, 20, 'product_count_product_cat', '18'),
(15, 22, 'product_count_product_cat', '10'),
(16, 21, 'product_count_product_cat', '18'),
(17, 23, 'order', '0'),
(18, 23, 'product_count_product_cat', '2');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_terms`
--
-- Создание: Июн 01 2021 г., 08:28
--

DROP TABLE IF EXISTS `wp_terms`;
CREATE TABLE `wp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Без рубрики', 'bez-rubriki', 0),
(2, 'simple', 'simple', 0),
(3, 'grouped', 'grouped', 0),
(4, 'variable', 'variable', 0),
(5, 'external', 'external', 0),
(6, 'exclude-from-search', 'exclude-from-search', 0),
(7, 'exclude-from-catalog', 'exclude-from-catalog', 0),
(8, 'featured', 'featured', 0),
(9, 'outofstock', 'outofstock', 0),
(10, 'rated-1', 'rated-1', 0),
(11, 'rated-2', 'rated-2', 0),
(12, 'rated-3', 'rated-3', 0),
(13, 'rated-4', 'rated-4', 0),
(14, 'rated-5', 'rated-5', 0),
(15, 'Misc', 'misc', 0),
(16, 'Мужские', 'muzhskie', 0),
(17, 'mancloth', 'mancloth', 0),
(18, 'top-menu', 'top-menu', 0),
(19, 'product-menu', 'product-menu', 0),
(20, 'Женские', 'zhenskie', 0),
(21, 'Подростки', 'podrostki', 0),
(22, 'Дети', 'deti', 0),
(23, 'Новорождённые', 'novorozhdjonnye', 0),
(24, 'footer_menu', 'footer_menu', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_term_relationships`
--
-- Создание: Июн 01 2021 г., 08:28
--

DROP TABLE IF EXISTS `wp_term_relationships`;
CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(10, 2, 0),
(10, 16, 0),
(10, 17, 0),
(29, 2, 0),
(29, 20, 0),
(31, 18, 0),
(39, 18, 0),
(40, 18, 0),
(41, 18, 0),
(42, 18, 0),
(45, 19, 0),
(46, 19, 0),
(47, 19, 0),
(48, 19, 0),
(50, 19, 0),
(51, 2, 0),
(51, 20, 0),
(53, 2, 0),
(53, 16, 0),
(55, 19, 0),
(57, 2, 0),
(57, 16, 0),
(59, 2, 0),
(59, 16, 0),
(61, 2, 0),
(61, 16, 0),
(63, 2, 0),
(63, 16, 0),
(65, 2, 0),
(65, 16, 0),
(67, 2, 0),
(67, 16, 0),
(69, 2, 0),
(69, 16, 0),
(71, 2, 0),
(71, 16, 0),
(73, 2, 0),
(73, 16, 0),
(75, 2, 0),
(75, 16, 0),
(77, 2, 0),
(77, 16, 0),
(79, 2, 0),
(79, 16, 0),
(81, 2, 0),
(81, 16, 0),
(83, 2, 0),
(83, 16, 0),
(85, 2, 0),
(85, 16, 0),
(88, 2, 0),
(88, 16, 0),
(90, 2, 0),
(90, 16, 0),
(92, 2, 0),
(92, 16, 0),
(94, 2, 0),
(94, 16, 0),
(96, 2, 0),
(96, 16, 0),
(98, 2, 0),
(98, 16, 0),
(100, 2, 0),
(100, 16, 0),
(102, 2, 0),
(102, 20, 0),
(104, 2, 0),
(104, 20, 0),
(106, 2, 0),
(106, 20, 0),
(108, 2, 0),
(108, 20, 0),
(110, 2, 0),
(110, 20, 0),
(112, 2, 0),
(112, 20, 0),
(114, 2, 0),
(114, 20, 0),
(116, 2, 0),
(116, 20, 0),
(118, 2, 0),
(118, 20, 0),
(120, 2, 0),
(120, 20, 0),
(122, 2, 0),
(122, 20, 0),
(124, 2, 0),
(124, 20, 0),
(126, 2, 0),
(126, 20, 0),
(128, 2, 0),
(128, 20, 0),
(130, 2, 0),
(130, 20, 0),
(132, 2, 0),
(132, 20, 0),
(135, 2, 0),
(135, 21, 0),
(137, 2, 0),
(137, 21, 0),
(139, 2, 0),
(139, 21, 0),
(141, 2, 0),
(141, 21, 0),
(143, 2, 0),
(143, 21, 0),
(145, 2, 0),
(145, 21, 0),
(148, 2, 0),
(148, 21, 0),
(150, 2, 0),
(150, 21, 0),
(152, 2, 0),
(152, 21, 0),
(154, 2, 0),
(154, 21, 0),
(156, 2, 0),
(156, 21, 0),
(158, 2, 0),
(158, 21, 0),
(160, 2, 0),
(160, 21, 0),
(162, 2, 0),
(162, 21, 0),
(164, 2, 0),
(164, 21, 0),
(166, 2, 0),
(166, 21, 0),
(168, 2, 0),
(168, 21, 0),
(170, 2, 0),
(170, 21, 0),
(172, 2, 0),
(172, 22, 0),
(174, 2, 0),
(174, 22, 0),
(178, 2, 0),
(178, 22, 0),
(180, 2, 0),
(180, 22, 0),
(183, 2, 0),
(183, 22, 0),
(185, 2, 0),
(185, 22, 0),
(188, 2, 0),
(188, 22, 0),
(190, 2, 0),
(190, 22, 0),
(192, 2, 0),
(192, 22, 0),
(194, 2, 0),
(194, 22, 0),
(199, 2, 0),
(199, 23, 0),
(201, 2, 0),
(201, 23, 0),
(203, 24, 0),
(204, 24, 0),
(205, 24, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_term_taxonomy`
--
-- Создание: Июн 01 2021 г., 08:28
--

DROP TABLE IF EXISTS `wp_term_taxonomy`;
CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'product_type', '', 0, 72),
(3, 3, 'product_type', '', 0, 0),
(4, 4, 'product_type', '', 0, 0),
(5, 5, 'product_type', '', 0, 0),
(6, 6, 'product_visibility', '', 0, 0),
(7, 7, 'product_visibility', '', 0, 0),
(8, 8, 'product_visibility', '', 0, 0),
(9, 9, 'product_visibility', '', 0, 0),
(10, 10, 'product_visibility', '', 0, 0),
(11, 11, 'product_visibility', '', 0, 0),
(12, 12, 'product_visibility', '', 0, 0),
(13, 13, 'product_visibility', '', 0, 0),
(14, 14, 'product_visibility', '', 0, 0),
(15, 15, 'product_cat', '', 0, 0),
(16, 16, 'product_cat', '', 0, 24),
(17, 17, 'product_tag', '', 0, 1),
(18, 18, 'nav_menu', '', 0, 5),
(19, 19, 'nav_menu', '', 0, 6),
(20, 20, 'product_cat', '', 0, 18),
(21, 21, 'product_cat', '', 0, 18),
(22, 22, 'product_cat', '', 0, 10),
(23, 23, 'product_cat', '', 0, 2),
(24, 24, 'nav_menu', '', 0, 3);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_usermeta`
--
-- Создание: Июн 01 2021 г., 08:28
--

DROP TABLE IF EXISTS `wp_usermeta`;
CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', '123'),
(3, 1, 'last_name', '123'),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'false'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:4:{s:64:\"467b50481a04a62a870bed834cba539e9ff74bd60ee8a2db119d44ec6984455d\";a:4:{s:10:\"expiration\";i:1625010334;s:2:\"ip\";s:13:\"87.117.58.168\";s:2:\"ua\";s:142:\"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 YaBrowser/21.5.2.644 Yowser/2.5 Safari/537.36\";s:5:\"login\";i:1623800734;}s:64:\"8ddcf89076f3a098a7f2fcc3a700544489b034421ad92daa39f226dbc23fa53e\";a:4:{s:10:\"expiration\";i:1624572108;s:2:\"ip\";s:13:\"31.23.185.253\";s:2:\"ua\";s:147:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 YaBrowser/21.5.2.638 Yowser/2.5 Safari/537.36\";s:5:\"login\";i:1624399308;}s:64:\"f1afffcc3d8f78fdf57c9ad7a1e4ac19023512981f8180dc49ecc9cade7b1ec8\";a:4:{s:10:\"expiration\";i:1625649634;s:2:\"ip\";s:13:\"176.59.67.234\";s:2:\"ua\";s:137:\"Mozilla/5.0 (iPhone; CPU iPhone OS 14_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.1 Mobile/15E148 Safari/604.1\";s:5:\"login\";i:1624440034;}s:64:\"a6f52685b088b7fa252ef18c5c8ae2ff16c62dbf8df296febf374bd7db8bf413\";a:4:{s:10:\"expiration\";i:1624615191;s:2:\"ip\";s:13:\"176.59.67.234\";s:2:\"ua\";s:137:\"Mozilla/5.0 (iPhone; CPU iPhone OS 14_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.1 Mobile/15E148 Safari/604.1\";s:5:\"login\";i:1624442391;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '222'),
(18, 1, 'community-events-location', 'a:1:{s:2:\"ip\";s:11:\"176.59.67.0\";}'),
(19, 1, '_woocommerce_tracks_anon_id', 'woo:P/euSlCi/vEYa/ZBZAlMPzDX'),
(20, 1, 'last_update', '1624399340'),
(21, 1, 'woocommerce_admin_activity_panel_inbox_last_read', '1624399340388'),
(22, 1, 'woocommerce_admin_task_list_tracked_started_tasks', '{\"products\":1}'),
(23, 1, 'wp_user-settings', 'libraryContent=browse'),
(24, 1, 'wp_user-settings-time', '1622546642'),
(25, 1, 'wc_last_active', '1624406400'),
(27, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
(28, 1, 'metaboxhidden_nav-menus', 'a:5:{i:0;s:21:\"add-post-type-product\";i:1;s:12:\"add-post_tag\";i:2;s:15:\"add-post_format\";i:3;s:15:\"add-product_cat\";i:4;s:15:\"add-product_tag\";}'),
(29, 1, 'billing_first_name', 'Владимир'),
(30, 1, 'billing_last_name', 'Ткачёв'),
(31, 1, 'billing_company', '123'),
(32, 1, 'billing_address_1', 'Криворожская 61'),
(33, 1, 'billing_address_2', 'кв 87, 4 этаж, 5 подъезд'),
(34, 1, 'billing_city', 'Ростов-на-Дону'),
(35, 1, 'billing_postcode', '340000'),
(36, 1, 'billing_country', 'RU'),
(37, 1, 'billing_state', 'Ростовская область'),
(38, 1, 'billing_phone', '8(928) 442-02-67'),
(39, 1, 'billing_email', 'gartonot62@gmail.com'),
(40, 1, 'shipping_first_name', ''),
(41, 1, 'shipping_last_name', ''),
(42, 1, 'shipping_company', ''),
(43, 1, 'shipping_address_1', ''),
(44, 1, 'shipping_address_2', ''),
(45, 1, 'shipping_city', ''),
(46, 1, 'shipping_postcode', ''),
(47, 1, 'shipping_country', ''),
(48, 1, 'shipping_state', ''),
(49, 1, 'nav_menu_recently_edited', '24'),
(50, 1, 'shipping_method', ''),
(57, 1, '_woocommerce_persistent_cart_1', 'a:1:{s:4:\"cart\";a:3:{s:32:\"7e7757b1e12abcb736ab9a754ffb617a\";a:11:{s:3:\"key\";s:32:\"7e7757b1e12abcb736ab9a754ffb617a\";s:10:\"product_id\";i:166;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:7;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:13993;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:13993;s:8:\"line_tax\";i:0;}s:32:\"37a749d808e46495a8da1e5352d03cae\";a:11:{s:3:\"key\";s:32:\"37a749d808e46495a8da1e5352d03cae\";s:10:\"product_id\";i:152;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:1999;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:1999;s:8:\"line_tax\";i:0;}s:32:\"d1fe173d08e959397adf34b1d77e88d7\";a:11:{s:3:\"key\";s:32:\"d1fe173d08e959397adf34b1d77e88d7\";s:10:\"product_id\";i:79;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:2;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:1998;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:1998;s:8:\"line_tax\";i:0;}}}'),
(58, 1, 'paying_customer', '1'),
(64, 1, 'closedpostboxes_shop_order', 'a:1:{i:0;s:23:\"woocommerce-order-notes\";}'),
(65, 1, 'metaboxhidden_shop_order', 'a:0:{}'),
(66, 1, '_order_count', '1'),
(67, 1, '_last_order', '206'),
(70, 1, 'meta-box-order_dashboard', 'a:4:{s:6:\"normal\";s:85:\"dashboard_site_health,wc_admin_dashboard_setup,dashboard_right_now,dashboard_activity\";s:4:\"side\";s:39:\"dashboard_quick_press,dashboard_primary\";s:7:\"column3\";s:0:\"\";s:7:\"column4\";s:0:\"\";}');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_users`
--
-- Создание: Июн 01 2021 г., 08:28
--

DROP TABLE IF EXISTS `wp_users`;
CREATE TABLE `wp_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BS7yTJ6XkYLGGYug01Zzo3f5rpS9Vw.', 'admin', 'gartonot62@gmail.com', 'http://manufacturer-cloth.ru', '2021-04-08 07:30:00', '', 0, 'admin');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_wc_admin_notes`
--
-- Создание: Июн 01 2021 г., 11:17
--

DROP TABLE IF EXISTS `wp_wc_admin_notes`;
CREATE TABLE `wp_wc_admin_notes` (
  `note_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `locale` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `title` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `content_data` longtext COLLATE utf8mb4_unicode_520_ci,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_reminder` datetime DEFAULT NULL,
  `is_snoozable` tinyint(1) NOT NULL DEFAULT '0',
  `layout` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `image` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `icon` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'info'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_wc_admin_notes`
--

INSERT INTO `wp_wc_admin_notes` (`note_id`, `name`, `type`, `locale`, `title`, `content`, `content_data`, `status`, `source`, `date_created`, `date_reminder`, `is_snoozable`, `layout`, `image`, `is_deleted`, `icon`) VALUES
(1, 'wc-admin-wc-helper-connection', 'info', 'en_US', 'Подключиться к WooCommerce.com', 'Подключайтесь, чтобы получать важные уведомления о товаре и обновления.', '{}', 'unactioned', 'woocommerce-admin', '2021-06-01 11:16:01', NULL, 0, 'plain', '', 0, 'info'),
(2, 'paypal_ppcp_gtm_2021', 'marketing', 'en_US', 'Offer more options with the new PayPal', 'Get the latest PayPal extension for a full suite of payment methods with extensive currency and country coverage.', '{}', 'pending', 'woocommerce.com', '2021-05-17 23:16:01', NULL, 0, 'plain', '', 0, 'info'),
(3, 'facebook_pixel_api_2021', 'marketing', 'en_US', 'Improve the performance of your Facebook ads', 'Enable Facebook Pixel and Conversions API through the latest version of Facebook for WooCommerce for improved measurement and ad targeting capabilities.', '{}', 'pending', 'woocommerce.com', '2021-05-17 23:16:01', NULL, 0, 'plain', '', 0, 'info'),
(4, 'facebook_ec_2021', 'marketing', 'en_US', 'Sync your product catalog with Facebook to help boost sales', 'A single click adds all products to your Facebook Business Page shop. Product changes are automatically synced, with the flexibility to control which products are listed.', '{}', 'pending', 'woocommerce.com', '2021-05-17 23:16:01', NULL, 0, 'plain', '', 0, 'info'),
(5, 'ecomm-need-help-setting-up-your-store', 'info', 'en_US', 'Need help setting up your Store?', 'Schedule a free 30-min <a href=\"https://wordpress.com/support/concierge-support/\">quick start session</a> and get help from our specialists. We’re happy to walk through setup steps, show you around the WordPress.com dashboard, troubleshoot any issues you may have, and help you the find the features you need to accomplish your goals for your site.', '{}', 'pending', 'woocommerce.com', '2021-05-17 23:16:01', NULL, 0, 'plain', '', 0, 'info'),
(6, 'woocommerce-services', 'info', 'en_US', 'WooCommerce Shipping & Tax', 'WooCommerce Shipping &amp; Tax helps get your store “ready to sell” as quickly as possible. You create your products. We take care of tax calculation, payment processing, and shipping label printing! Learn more about the extension that you just installed.', '{}', 'pending', 'woocommerce.com', '2021-05-17 23:16:01', NULL, 0, 'plain', '', 0, 'info'),
(7, 'ecomm-unique-shopping-experience', 'info', 'en_US', 'For a shopping experience as unique as your customers', 'Product Add-Ons allow your customers to personalize products while they’re shopping on your online store. No more follow-up email requests—customers get what they want, before they’re done checking out. Learn more about this extension that comes included in your plan.', '{}', 'pending', 'woocommerce.com', '2021-05-17 23:16:01', NULL, 0, 'plain', '', 0, 'info'),
(8, 'wc-admin-getting-started-in-ecommerce', 'info', 'en_US', 'Getting Started in eCommerce - webinar', 'We want to make eCommerce and this process of getting started as easy as possible for you. Watch this webinar to get tips on how to have our store up and running in a breeze.', '{}', 'pending', 'woocommerce.com', '2021-05-17 23:16:01', NULL, 0, 'plain', '', 0, 'info'),
(9, 'your-first-product', 'info', 'en_US', 'Your first product', 'That\'s huge! You\'re well on your way to building a successful online store — now it’s time to think about how you\'ll fulfill your orders.<br /><br />Read our shipping guide to learn best practices and options for putting together your shipping strategy. And for WooCommerce stores in the United States, you can print discounted shipping labels via USPS with <a href=\"https://href.li/?https://woocommerce.com/shipping\" target=\"_blank\">WooCommerce Shipping</a>.', '{}', 'unactioned', 'woocommerce.com', '2021-05-18 08:24:06', NULL, 0, 'plain', '', 0, 'info'),
(10, 'wc-square-apple-pay-boost-sales', 'marketing', 'en_US', 'Boost sales with Apple Pay', 'Now that you accept Apple Pay® with Square you can increase conversion rates by letting your customers know that Apple Pay® is available. Here’s a marketing guide to help you get started.', '{}', 'pending', 'woocommerce.com', '2021-05-17 23:16:01', NULL, 0, 'plain', '', 0, 'info'),
(11, 'wc-square-apple-pay-grow-your-business', 'marketing', 'en_US', 'Grow your business with Square and Apple Pay ', 'Now more than ever, shoppers want a fast, simple, and secure online checkout experience. Increase conversion rates by letting your customers know that you now accept Apple Pay®.', '{}', 'pending', 'woocommerce.com', '2021-05-17 23:16:01', NULL, 0, 'plain', '', 0, 'info'),
(12, 'wcpay-apple-pay-is-now-available', 'marketing', 'en_US', 'Apple Pay is now available with WooCommerce Payments!', 'Increase your conversion rate by offering a fast and secure checkout with <a href=\"https://woocommerce.com/apple-pay/?utm_source=inbox&amp;utm_medium=product&amp;utm_campaign=wcpay_applepay\" target=\"_blank\">Apple Pay</a>®. It’s free to get started with <a href=\"https://woocommerce.com/payments/?utm_source=inbox&amp;utm_medium=product&amp;utm_campaign=wcpay_applepay\" target=\"_blank\">WooCommerce Payments</a>.', '{}', 'pending', 'woocommerce.com', '2021-05-17 23:16:01', NULL, 0, 'plain', '', 0, 'info'),
(13, 'wcpay-apple-pay-boost-sales', 'marketing', 'en_US', 'Boost sales with Apple Pay', 'Now that you accept Apple Pay® with WooCommerce Payments you can increase conversion rates by letting your customers know that Apple Pay® is available. Here’s a marketing guide to help you get started.', '{}', 'pending', 'woocommerce.com', '2021-05-17 23:16:01', NULL, 0, 'plain', '', 0, 'info'),
(14, 'wcpay-apple-pay-grow-your-business', 'marketing', 'en_US', 'Grow your business with WooCommerce Payments and Apple Pay', 'Now more than ever, shoppers want a fast, simple, and secure online checkout experience. Increase conversion rates by letting your customers know that you now accept Apple Pay®.', '{}', 'pending', 'woocommerce.com', '2021-05-17 23:16:01', NULL, 0, 'plain', '', 0, 'info'),
(15, 'wc-admin-optimizing-the-checkout-flow', 'info', 'en_US', 'Optimizing the checkout flow', 'It\'s crucial to get your store\'s checkout as smooth as possible to avoid losing sales. Let\'s take a look at how you can optimize the checkout experience for your shoppers.', '{}', 'unactioned', 'woocommerce.com', '2021-06-01 05:41:57', NULL, 0, 'plain', '', 0, 'info'),
(16, 'wc-admin-first-five-things-to-customize', 'info', 'en_US', 'The first 5 things to customize in your store', 'Deciding what to start with first is tricky. To help you properly prioritize, we\'ve put together this short list of the first few things you should customize in WooCommerce.', '{}', 'unactioned', 'woocommerce.com', '2021-05-21 05:17:54', NULL, 0, 'plain', '', 0, 'info'),
(17, 'wc-payments-qualitative-feedback', 'info', 'en_US', 'WooCommerce Payments setup - let us know what you think', 'Congrats on enabling WooCommerce Payments for your store. Please share your feedback in this 2 minute survey to help us improve the setup process.', '{}', 'pending', 'woocommerce.com', '2021-05-17 23:16:01', NULL, 0, 'plain', '', 0, 'info'),
(18, 'share-your-feedback-on-paypal', 'info', 'en_US', 'Share your feedback on PayPal', 'Share your feedback in this 2 minute survey about how we can make the process of accepting payments more useful for your store.', '{}', 'pending', 'woocommerce.com', '2021-05-17 23:16:01', NULL, 0, 'plain', '', 0, 'info'),
(19, 'wcpay_instant_deposits_gtm_2021', 'marketing', 'en_US', 'Get paid within minutes – Instant Deposits for WooCommerce Payments', 'Stay flexible with immediate access to your funds when you need them – including nights, weekends, and holidays. With <a href=\"https://woocommerce.com/products/woocommerce-payments/?utm_source=inbox&amp;utm_medium=product&amp;utm_campaign=wcpay_instant_deposits\">WooCommerce Payments\'</a> new Instant Deposits feature, you’re able to transfer your earnings to a debit card within minutes.', '{}', 'pending', 'woocommerce.com', '2021-05-17 23:16:01', NULL, 0, 'plain', '', 0, 'info'),
(20, 'wc-subscriptions-security-update-3-0-15', 'info', 'en_US', 'WooCommerce Subscriptions security update!', 'We recently released an important security update to WooCommerce Subscriptions. To ensure your site\'s data is protected, please upgrade <strong>WooCommerce Subscriptions to version 3.0.15</strong> or later.<br /><br />Click the button below to view and update to the latest Subscriptions version, or log in to <a href=\"https://woocommerce.com/my-dashboard\">WooCommerce.com Dashboard</a> and navigate to your <strong>Downloads</strong> page.<br /><br />We recommend always using the latest version of WooCommerce Subscriptions, and other software running on your site, to ensure maximum security.<br /><br />If you have any questions we are here to help — just <a href=\"https://woocommerce.com/my-account/create-a-ticket/\">open a ticket</a>.', '{}', 'pending', 'woocommerce.com', '2021-05-17 23:16:01', NULL, 0, 'plain', '', 0, 'info'),
(21, 'wc-admin-onboarding-email-marketing', 'info', 'en_US', 'Зарегистрируйтесь, чтобы получать советы, информацию об обновлениях товаров и новые идеи', 'Мы рады помогать вам — получайте советы, информацию об обновлении товаров и вдохновляющие идеи прямо на почту.', '{}', 'unactioned', 'woocommerce-admin', '2021-06-01 11:16:01', NULL, 0, 'plain', '', 0, 'info'),
(22, 'wc-admin-learn-more-about-variable-products', 'info', 'en_US', 'Узнать больше о вариативных товарах', 'Вариативный товар - это мощный тип товара, который позволяет вам предлагать набор различных вариантов продукта, которые могут отличаться по ценам, иметь разные изображения, фиксировать складские остатки каждой вариации. Их можно использовать для таких товаров, как рубашка, которая имеет различные размеры и цвета.', '{}', 'unactioned', 'woocommerce-admin', '2021-06-01 11:24:06', NULL, 0, 'plain', '', 0, 'info'),
(23, 'wc-admin-orders-milestone', 'info', 'en_US', 'Получен первый заказ', 'Поздравляем с получением первого заказа! Самое время узнать, как управлять этими заказами.', '{}', 'unactioned', 'woocommerce-admin', '2021-06-01 20:57:48', NULL, 0, 'plain', '', 0, 'info'),
(24, 'wc-admin-choosing-a-theme', 'marketing', 'en_US', 'Выбираете тему?', 'Узнайте, какие темы совместимы с WooCommerce и выберите ту, что лучше подойдёт под стиль и требования вашего бизнеса.', '{}', 'unactioned', 'woocommerce-admin', '2021-06-02 11:37:52', NULL, 0, 'plain', '', 0, 'info'),
(25, 'wc-admin-insight-first-product-and-payment', 'survey', 'en_US', 'Совет', 'Более 80% новых продавцов добавляют первый товар и настраивают хотя бы один способ оплаты в течение первой недели.<br /><br />Считаете ли вы, что такая информация полезна?', '{}', 'unactioned', 'woocommerce-admin', '2021-06-02 11:37:52', NULL, 0, 'plain', '', 0, 'info'),
(26, 'wc-admin-customizing-product-catalog', 'info', 'en_US', 'Как настроить каталог товаров', 'Вы хотите, чтобы ваш каталог товаров с изображениями выглядели великолепно и соответствовали вашему бренду. Это руководство даст вам все необходимые советы, чтобы ваши продукты отлично смотрелись в вашем магазине.', '{}', 'unactioned', 'woocommerce-admin', '2021-06-02 11:37:52', NULL, 0, 'plain', '', 0, 'info'),
(27, 'wc-admin-mobile-app', 'info', 'en_US', 'Установите мобильное приложение Woo', 'Установите мобильное приложение WooCommerce для управления заказами, получения уведомлений о продажах и просмотра ключевых показателей — где бы вы ни находились.', '{}', 'unactioned', 'woocommerce-admin', '2021-06-03 11:17:54', NULL, 0, 'plain', '', 0, 'info'),
(28, 'wc-admin-launch-checklist', 'info', 'en_US', 'Готовы запустить собственный магазин?', 'Чтобы у вас не возникало чувство, что вы что-то забыли, мы составили чек-лист для использования перед запуском.', '{}', 'unactioned', 'woocommerce-admin', '2021-06-03 11:17:54', NULL, 0, 'plain', '', 0, 'info'),
(29, 'wc-admin-online-clothing-store', 'info', 'en_US', 'Запустите свой магазин одежды', 'Запускать веб-сайт о моде интересно, но требует много сил. В этой статье мы поможем вам преодолеть процесс настройки шаг за шагом, научим создавать списки товаров и покажем, как привлечь нужных посетителей.', '{}', 'unactioned', 'woocommerce-admin', '2021-06-03 11:17:54', NULL, 0, 'plain', '', 0, 'info'),
(30, 'wc-admin-draw-attention', 'info', 'en_US', 'Выделяйтесь: узнайте, как привлечь внимание к своему интернет-магазину', 'Вот семь способов повысить продажи и не уступать клиентов конкурентам с похожими товарами массового производства. Это поможет вам сделать первые шаги.', '{}', 'unactioned', 'woocommerce-admin', '2021-06-04 11:41:56', NULL, 0, 'plain', '', 0, 'info'),
(31, 'wc-admin-need-some-inspiration', 'info', 'en_US', 'Просмотрите наши истории успеха', 'Узнайте больше о том, как другие предприниматели использовали WooCommerce для создания успешного бизнеса.', '{}', 'unactioned', 'woocommerce-admin', '2021-06-05 12:12:41', NULL, 0, 'plain', '', 0, 'info'),
(32, 'wc-admin-marketing-intro', 'info', 'en_US', 'Найдите свою аудиторию', 'Расширяйте базу заказчиков и увеличивайте продажи с помощью маркетинговых инструментов для WooCommerce.', '{}', 'unactioned', 'woocommerce-admin', '2021-06-06 12:35:52', NULL, 0, 'plain', '', 0, 'info'),
(33, 'google_listings_and_ads_install', 'marketing', 'en_US', 'Drive traffic and sales with Google', 'Reach online shoppers to drive traffic and sales for your store by showcasing products across Google, for free or with ads.', '{}', 'pending', 'woocommerce.com', '2021-06-04 15:08:59', NULL, 0, 'plain', '', 0, 'info'),
(34, 'wc-admin-usage-tracking-opt-in', 'info', 'en_US', 'Помогите WooCommerce стать лучше, согласившись делиться данными об использовании.', 'Сбор данных об использовании позволяет нам улучшить WooCommerce. Информация о вашем магазине будет использоваться для оценки новых функций, определения качества обновлений и принятия решений о целесообразности дальнейших улучшений. Вы всегда можете зайти в <a href=\"https://manufacturer-cloth.ru/wp-admin/admin.php?page=wc-settings&#038;tab=advanced&#038;section=woocommerce_com\" target=\"_blank\">Настройки</a> и выбрать отмену отправки ваших данных. <a href=\"https://woocommerce.com/usage-tracking\" target=\"_blank\">Читать подробнее</a> о том, какие данные мы собираем.', '{}', 'unactioned', 'woocommerce-admin', '2021-06-08 11:50:53', NULL, 0, 'plain', '', 0, 'info'),
(35, 'wc-admin-store-notice-giving-feedback-2', 'info', 'en_US', 'Приглашаем вас поделиться опытом', 'Теперь, когда мы стали вашим партнером, мы постараемся обеспечить вас всеми необходимыми инструментами. Ждем ваш отзыв о процессе настройки магазина. Он поможет нам оптимизировать его в будущем.', '{}', 'unactioned', 'woocommerce-admin', '2021-06-09 11:25:25', NULL, 0, 'plain', '', 0, 'info'),
(36, 'wc-admin-insight-first-sale', 'survey', 'en_US', 'Знаете ли вы?', 'В среднем магазину на базе WooCommerce требуется 31 день, чтобы получить первый заказ. Вы на правильном пути! Вам пригодилась эта информация?', '{}', 'unactioned', 'woocommerce-admin', '2021-06-09 11:25:25', NULL, 0, 'plain', '', 0, 'info'),
(37, 'woocommerce-core-update-5-4-0', 'info', 'en_US', 'Update to WooCommerce 5.4.1 now', 'WooCommerce 5.4.1 addresses a checkout issue discovered in WooCommerce 5.4. We recommend upgrading to WooCommerce 5.4.1 as soon as possible.', '{}', 'pending', 'woocommerce.com', '2021-06-08 00:38:20', NULL, 0, 'plain', '', 0, 'info'),
(38, 'wcpay-promo-2020-11', 'marketing', 'en_US', 'wcpay-promo-2020-11', 'wcpay-promo-2020-11', '{}', 'pending', 'woocommerce.com', '2021-06-10 05:56:55', NULL, 0, 'plain', '', 0, 'info'),
(39, 'wcpay-promo-2020-12', 'marketing', 'en_US', 'wcpay-promo-2020-12', 'wcpay-promo-2020-12', '{}', 'pending', 'woocommerce.com', '2021-06-10 05:56:55', NULL, 0, 'plain', '', 0, 'info'),
(40, 'wcpay-promo-2021-6-incentive-1', 'marketing', 'en_US', 'Special offer: Save 50% on transaction fees for up to $125,000 in payments', 'Save big when you add <a href=\"https://woocommerce.com/payments/?utm_medium=notification&amp;utm_source=product&amp;utm_campaign=wcpay_exp222\">WooCommerce Payments</a> to your store today.\n                Get a discounted rate of 1.5% + $0.15 on all transactions – that’s 50% off the standard fee on up to $125,000 in processed payments (or six months, whichever comes first). Act now – this offer is available for a limited time only.\n                <br /><br />By clicking \"Get WooCommerce Payments,\" you agree to the promotional <a href=\"https://woocommerce.com/terms-conditions/woocommerce-payments-half-off-six-promotion/?utm_medium=notification&amp;utm_source=product&amp;utm_campaign=wcpay_exp222\">Terms of Service</a>.', '{}', 'pending', 'woocommerce.com', '2021-06-10 05:56:55', NULL, 0, 'plain', '', 0, 'info'),
(41, 'wcpay-promo-2021-6-incentive-2', 'marketing', 'en_US', 'Special offer: No transaction fees* for up to three months', 'Save big when you add <a href=\"https://woocommerce.com/payments/?utm_medium=notification&amp;utm_source=product&amp;utm_campaign=wcpay_exp233\">WooCommerce Payments</a> to your store today. Pay zero transaction fees* on up to $25,000 in processed payments (or three months, whichever comes first). Act now – this offer is available for a limited time only. *Currency conversion fees excluded.\n                <br /><br />By clicking \"Get WooCommerce Payments,\" you agree to the promotional <a href=\"https://woocommerce.com/terms-conditions/woocommerce-payments-no-transaction-fees-for-three-promotion/?utm_medium=notification&amp;utm_source=product&amp;utm_campaign=wcpay_exp233\">Terms of Service</a>.', '{}', 'pending', 'woocommerce.com', '2021-06-10 05:56:55', NULL, 0, 'plain', '', 0, 'info'),
(42, 'wc-admin-customize-store-with-blocks', 'info', 'en_US', 'Настраивайте свой онлайн-магазин с помощью блоков WooCommerce', 'С помощью блоков можно отображать выбранные товары, категории, фильтры и другие элементы почти в любом месте сайта без шорткодов и изменения кода. Узнайте больше о том, как пользоваться каждым из них.', '{}', 'unactioned', 'woocommerce-admin', '2021-06-15 12:24:09', NULL, 0, 'plain', '', 0, 'info'),
(43, 'ppxo-pps-upgrade-paypal-payments-1', 'info', 'en_US', 'Get the latest PayPal extension for WooCommerce', 'Heads up! There\'s a new PayPal on the block!<br /><br />Now is a great time to upgrade to our latest <a href=\"https://woocommerce.com/products/woocommerce-paypal-payments/\" target=\"_blank\">PayPal extension</a> to continue to receive support and updates with PayPal.<br /><br />Get access to a full suite of PayPal payment methods, extensive currency and country coverage, and pay later options with the all-new PayPal extension for WooCommerce.', '{}', 'pending', 'woocommerce.com', '2021-06-22 14:20:59', NULL, 0, 'plain', '', 0, 'info'),
(44, 'ppxo-pps-upgrade-paypal-payments-2', 'info', 'en_US', 'Upgrade your PayPal experience!', 'We\'ve developed a whole new <a href=\"https://woocommerce.com/products/woocommerce-paypal-payments/\" target=\"_blank\">PayPal extension for WooCommerce</a> that combines the best features of our many PayPal extensions into just one extension.<br /><br />Get access to a full suite of PayPal payment methods, extensive currency and country coverage, offer subscription and recurring payments, and the new PayPal pay later options.<br /><br />Start using our latest PayPal today to continue to receive support and updates.', '{}', 'pending', 'woocommerce.com', '2021-06-22 14:20:59', NULL, 0, 'plain', '', 0, 'info'),
(45, 'eu_vat_changes_2021', 'marketing', 'en_US', 'Get your business ready for the new EU tax regulations', 'On July 1, 2021, new taxation rules will come into play when the <a href=\"https://ec.europa.eu/taxation_customs/business/vat/modernising-vat-cross-border-ecommerce_en\">European Union (EU) Value-Added Tax (VAT) eCommerce package</a> takes effect.<br /><br />The new regulations will impact virtually every B2C business involved in cross-border eCommerce trade with the EU.<br /><br />We therefore recommend <a href=\"https://woocommerce.com/posts/new-eu-vat-regulations\">familiarizing yourself with the new updates</a>, and consult with a tax professional to ensure your business is following regulations and best practice.', '{}', 'unactioned', 'woocommerce.com', '2021-06-23 17:19:13', NULL, 0, 'plain', '', 0, 'info');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_wc_admin_note_actions`
--
-- Создание: Июн 01 2021 г., 11:17
--

DROP TABLE IF EXISTS `wp_wc_admin_note_actions`;
CREATE TABLE `wp_wc_admin_note_actions` (
  `action_id` bigint(20) UNSIGNED NOT NULL,
  `note_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `query` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT '0',
  `actioned_text` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_wc_admin_note_actions`
--

INSERT INTO `wp_wc_admin_note_actions` (`action_id`, `note_id`, `name`, `label`, `query`, `status`, `is_primary`, `actioned_text`) VALUES
(1, 1, 'connect', 'Подключить', '?page=wc-addons&section=helper', 'unactioned', 0, ''),
(22, 21, 'yes-please', 'Да, пожалуйста!', 'https://woocommerce.us8.list-manage.com/subscribe/post?u=2c1434dc56f9506bf3c3ecd21&amp;id=13860df971&amp;SIGNUPPAGE=plugin', 'actioned', 0, ''),
(63, 22, 'learn-more', 'Узнать больше', 'https://docs.woocommerce.com/document/variable-product/?utm_source=inbox', 'actioned', 0, ''),
(104, 23, 'learn-more', 'Узнать больше', 'https://docs.woocommerce.com/document/managing-orders/?utm_source=inbox', 'actioned', 0, ''),
(105, 24, 'visit-the-theme-marketplace', 'Посетите каталог тем', 'https://woocommerce.com/product-category/themes/?utm_source=inbox', 'actioned', 0, ''),
(106, 25, 'affirm-insight-first-product-and-payment', 'Да', '', 'actioned', 0, 'Спасибо за отзыв'),
(107, 25, 'affirm-insight-first-product-and-payment', 'Нет', '', 'actioned', 0, 'Спасибо за отзыв'),
(108, 26, 'day-after-first-product', 'Узнать больше', 'https://docs.woocommerce.com/document/woocommerce-customizer/?utm_source=inbox', 'actioned', 0, ''),
(209, 27, 'learn-more', 'Узнать больше', 'https://woocommerce.com/mobile/', 'actioned', 0, ''),
(210, 28, 'learn-more', 'Узнать больше', 'https://woocommerce.com/posts/pre-launch-checklist-the-essentials/?utm_source=inbox', 'actioned', 0, ''),
(211, 29, 'online-clothing-store', 'Узнать больше', 'https://woocommerce.com/posts/starting-an-online-clothing-store/?utm_source=inbox', 'actioned', 1, ''),
(1812, 30, 'learn-more', 'Узнать больше', 'https://woocommerce.com/posts/how-to-make-your-online-store-stand-out/?utm_source=inbox', 'actioned', 1, ''),
(1833, 31, 'need-some-inspiration', 'Прочитайте истории успеха', 'https://woocommerce.com/success-stories/?utm_source=inbox', 'actioned', 1, ''),
(1854, 32, 'open-marketing-hub', 'Открыть маркетинговый центр', 'https://manufacturer-cloth.ru/wp-admin/admin.php?page=wc-admin&path=/marketing', 'actioned', 0, ''),
(1896, 34, 'tracking-opt-in', 'Активировать отслеживание использования', '', 'actioned', 1, ''),
(1918, 35, 'share-feedback', 'Отправить отзыв', 'https://automattic.survey.fm/store-setup-survey', 'actioned', 0, ''),
(1919, 36, 'affirm-insight-first-sale', 'Да', '', 'actioned', 0, 'Спасибо за отзыв'),
(1920, 36, 'deny-insight-first-sale', 'Нет', '', 'actioned', 0, 'Спасибо за отзыв'),
(2058, 42, 'customize-store-with-blocks', 'Узнать больше', 'https://woocommerce.com/posts/how-to-customize-your-online-store-with-woocommerce-blocks/?utm_source=inbox', 'actioned', 1, ''),
(2439, 45, 'eu_vat_changes_2021', 'Learn more about the EU tax regulations', 'https://woocommerce.com/posts/new-eu-vat-regulations', 'actioned', 1, ''),
(2440, 2, 'open_wc_paypal_payments_product_page', 'Learn more', 'https://woocommerce.com/products/woocommerce-paypal-payments/', 'actioned', 1, ''),
(2441, 3, 'upgrade_now_facebook_pixel_api', 'Upgrade now', 'plugin-install.php?tab=plugin-information&plugin=&section=changelog', 'actioned', 1, ''),
(2442, 4, 'learn_more_facebook_ec', 'Learn more', 'https://woocommerce.com/products/facebook/', 'unactioned', 1, ''),
(2443, 5, 'set-up-concierge', 'Schedule free session', 'https://wordpress.com/me/concierge', 'actioned', 1, ''),
(2444, 6, 'learn-more', 'Learn more', 'https://docs.woocommerce.com/document/woocommerce-shipping-and-tax/?utm_source=inbox', 'unactioned', 1, ''),
(2445, 7, 'learn-more-ecomm-unique-shopping-experience', 'Learn more', 'https://docs.woocommerce.com/document/product-add-ons/?utm_source=inbox', 'actioned', 1, ''),
(2446, 8, 'watch-the-webinar', 'Watch the webinar', 'https://youtu.be/V_2XtCOyZ7o', 'actioned', 1, ''),
(2447, 9, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/ecommerce-shipping-solutions-guide/?utm_source=inbox', 'actioned', 1, ''),
(2448, 10, 'boost-sales-marketing-guide', 'See marketing guide', 'https://developer.apple.com/apple-pay/marketing/?utm_source=inbox&utm_campaign=square-boost-sales', 'actioned', 1, ''),
(2449, 11, 'grow-your-business-marketing-guide', 'See marketing guide', 'https://developer.apple.com/apple-pay/marketing/?utm_source=inbox&utm_campaign=square-grow-your-business', 'actioned', 1, ''),
(2450, 12, 'add-apple-pay', 'Add Apple Pay', '/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments', 'actioned', 1, ''),
(2451, 12, 'learn-more', 'Learn more', 'https://docs.woocommerce.com/document/payments/apple-pay/?utm_source=inbox&utm_medium=product&utm_campaign=wcpay_applepay', 'actioned', 1, ''),
(2452, 13, 'boost-sales-marketing-guide', 'See marketing guide', 'https://developer.apple.com/apple-pay/marketing/?utm_source=inbox&utm_campaign=wcpay-boost-sales', 'actioned', 1, ''),
(2453, 14, 'grow-your-business-marketing-guide', 'See marketing guide', 'https://developer.apple.com/apple-pay/marketing/?utm_source=inbox&utm_campaign=wcpay-grow-your-business', 'actioned', 1, ''),
(2454, 15, 'optimizing-the-checkout-flow', 'Learn more', 'https://woocommerce.com/posts/optimizing-woocommerce-checkout?utm_source=inbox', 'actioned', 1, ''),
(2455, 16, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/first-things-customize-woocommerce/?utm_source=inbox', 'unactioned', 1, ''),
(2456, 17, 'qualitative-feedback-from-new-users', 'Share feedback', 'https://automattic.survey.fm/wc-pay-new', 'actioned', 1, ''),
(2457, 18, 'share-feedback', 'Share feedback', 'http://automattic.survey.fm/paypal-feedback', 'unactioned', 1, ''),
(2458, 19, 'learn-more', 'Learn about Instant Deposits eligibility', 'https://docs.woocommerce.com/document/payments/instant-deposits/?utm_source=inbox&utm_medium=product&utm_campaign=wcpay_instant_deposits', 'actioned', 1, ''),
(2459, 33, 'get-started', 'Get started', 'https://woocommerce.com/products/google-listings-and-ads', 'actioned', 1, ''),
(2460, 20, 'update-wc-subscriptions-3-0-15', 'View latest version', 'https://manufacturer-cloth.ru/wp-admin/admin.php?page=wc-admin&page=wc-addons&section=helper', 'actioned', 1, ''),
(2461, 37, 'update-wc-core-5-4-0', 'How to update WooCommerce', 'https://docs.woocommerce.com/document/how-to-update-woocommerce/', 'actioned', 1, ''),
(2462, 40, 'get-woo-commerce-payments', 'Get WooCommerce Payments', 'admin.php?page=wc-admin&action=setup-woocommerce-payments', 'actioned', 1, ''),
(2463, 41, 'get-woocommerce-payments', 'Get WooCommerce Payments', 'admin.php?page=wc-admin&action=setup-woocommerce-payments', 'actioned', 1, ''),
(2464, 43, 'ppxo-pps-install-paypal-payments-1', 'View upgrade guide', 'https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/', 'actioned', 1, ''),
(2465, 44, 'ppxo-pps-install-paypal-payments-2', 'View upgrade guide', 'https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/', 'actioned', 1, '');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_wc_category_lookup`
--
-- Создание: Июн 01 2021 г., 11:17
--

DROP TABLE IF EXISTS `wp_wc_category_lookup`;
CREATE TABLE `wp_wc_category_lookup` (
  `category_tree_id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_wc_category_lookup`
--

INSERT INTO `wp_wc_category_lookup` (`category_tree_id`, `category_id`) VALUES
(15, 15);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_wc_customer_lookup`
--
-- Создание: Июн 01 2021 г., 11:17
--

DROP TABLE IF EXISTS `wp_wc_customer_lookup`;
CREATE TABLE `wp_wc_customer_lookup` (
  `customer_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `username` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `first_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `date_last_active` timestamp NULL DEFAULT NULL,
  `date_registered` timestamp NULL DEFAULT NULL,
  `country` char(2) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `postcode` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_wc_customer_lookup`
--

INSERT INTO `wp_wc_customer_lookup` (`customer_id`, `user_id`, `username`, `first_name`, `last_name`, `email`, `date_last_active`, `date_registered`, `country`, `postcode`, `city`, `state`) VALUES
(1, 1, 'admin', '123', '123', 'gartonot62@gmail.com', '2021-06-22 21:00:00', '2021-04-08 04:30:00', 'RU', '340000', 'Ростов-на-Дону', 'Ростовская область'),
(2, NULL, '', 'Илья', 'Гусев', 'provero4ka@mail.ru', '2021-06-15 12:32:35', NULL, 'RU', '345', 'Ркси', 'Ростовская'),
(3, NULL, '', 'ehr', 'sdg', 'sff@mail.ru', '2021-06-15 18:06:51', NULL, 'RU', '777', 'khcm', 'df');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_wc_download_log`
--
-- Создание: Июн 01 2021 г., 11:16
--

DROP TABLE IF EXISTS `wp_wc_download_log`;
CREATE TABLE `wp_wc_download_log` (
  `download_log_id` bigint(20) UNSIGNED NOT NULL,
  `timestamp` datetime NOT NULL,
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `user_ip_address` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_wc_order_coupon_lookup`
--
-- Создание: Июн 01 2021 г., 11:17
--

DROP TABLE IF EXISTS `wp_wc_order_coupon_lookup`;
CREATE TABLE `wp_wc_order_coupon_lookup` (
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `coupon_id` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `discount_amount` double NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_wc_order_product_lookup`
--
-- Создание: Июн 01 2021 г., 11:17
--

DROP TABLE IF EXISTS `wp_wc_order_product_lookup`;
CREATE TABLE `wp_wc_order_product_lookup` (
  `order_item_id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `variation_id` bigint(20) UNSIGNED NOT NULL,
  `customer_id` bigint(20) UNSIGNED DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `product_qty` int(11) NOT NULL,
  `product_net_revenue` double NOT NULL DEFAULT '0',
  `product_gross_revenue` double NOT NULL DEFAULT '0',
  `coupon_amount` double NOT NULL DEFAULT '0',
  `tax_amount` double NOT NULL DEFAULT '0',
  `shipping_amount` double NOT NULL DEFAULT '0',
  `shipping_tax_amount` double NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_wc_order_product_lookup`
--

INSERT INTO `wp_wc_order_product_lookup` (`order_item_id`, `order_id`, `product_id`, `variation_id`, `customer_id`, `date_created`, `product_qty`, `product_net_revenue`, `product_gross_revenue`, `coupon_amount`, `tax_amount`, `shipping_amount`, `shipping_tax_amount`) VALUES
(1, 22, 10, 0, 1, '2021-06-01 22:08:21', 13, 23270, 23270, 0, 0, 0, 0),
(2, 206, 83, 0, 1, '2021-06-03 23:13:39', 1, 799, 799, 0, 0, 0, 0),
(3, 220, 83, 0, 2, '2021-06-15 18:32:35', 1, 799, 799, 0, 0, 0, 0),
(4, 221, 83, 0, 3, '2021-06-16 00:06:51', 1, 799, 799, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_wc_order_stats`
--
-- Создание: Июн 01 2021 г., 11:17
--

DROP TABLE IF EXISTS `wp_wc_order_stats`;
CREATE TABLE `wp_wc_order_stats` (
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `parent_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `num_items_sold` int(11) NOT NULL DEFAULT '0',
  `total_sales` double NOT NULL DEFAULT '0',
  `tax_total` double NOT NULL DEFAULT '0',
  `shipping_total` double NOT NULL DEFAULT '0',
  `net_total` double NOT NULL DEFAULT '0',
  `returning_customer` tinyint(1) DEFAULT NULL,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `customer_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_wc_order_stats`
--

INSERT INTO `wp_wc_order_stats` (`order_id`, `parent_id`, `date_created`, `date_created_gmt`, `num_items_sold`, `total_sales`, `tax_total`, `shipping_total`, `net_total`, `returning_customer`, `status`, `customer_id`) VALUES
(22, 0, '2021-06-01 22:08:21', '2021-06-01 19:08:21', 13, 23270, 0, 0, 23270, 1, 'wc-trash', 1),
(206, 0, '2021-06-03 23:13:39', '2021-06-03 20:13:39', 1, 799, 0, 0, 799, 0, 'wc-completed', 1),
(220, 0, '2021-06-15 18:32:35', '2021-06-15 15:32:35', 1, 799, 0, 0, 799, 0, 'wc-trash', 2),
(221, 0, '2021-06-16 00:06:51', '2021-06-15 21:06:51', 1, 799, 0, 0, 799, 0, 'wc-trash', 3);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_wc_order_tax_lookup`
--
-- Создание: Июн 01 2021 г., 11:17
--

DROP TABLE IF EXISTS `wp_wc_order_tax_lookup`;
CREATE TABLE `wp_wc_order_tax_lookup` (
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `tax_rate_id` bigint(20) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `shipping_tax` double NOT NULL DEFAULT '0',
  `order_tax` double NOT NULL DEFAULT '0',
  `total_tax` double NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_wc_product_meta_lookup`
--
-- Создание: Июн 01 2021 г., 11:16
--

DROP TABLE IF EXISTS `wp_wc_product_meta_lookup`;
CREATE TABLE `wp_wc_product_meta_lookup` (
  `product_id` bigint(20) NOT NULL,
  `sku` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `virtual` tinyint(1) DEFAULT '0',
  `downloadable` tinyint(1) DEFAULT '0',
  `min_price` decimal(19,4) DEFAULT NULL,
  `max_price` decimal(19,4) DEFAULT NULL,
  `onsale` tinyint(1) DEFAULT '0',
  `stock_quantity` double DEFAULT NULL,
  `stock_status` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT 'instock',
  `rating_count` bigint(20) DEFAULT '0',
  `average_rating` decimal(3,2) DEFAULT '0.00',
  `total_sales` bigint(20) DEFAULT '0',
  `tax_status` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT 'taxable',
  `tax_class` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_wc_product_meta_lookup`
--

INSERT INTO `wp_wc_product_meta_lookup` (`product_id`, `sku`, `virtual`, `downloadable`, `min_price`, `max_price`, `onsale`, `stock_quantity`, `stock_status`, `rating_count`, `average_rating`, `total_sales`, `tax_status`, `tax_class`) VALUES
(10, '', 0, 0, '1790.0000', '1790.0000', 0, NULL, 'instock', 0, '0.00', 13, 'taxable', ''),
(29, '', 0, 0, '1990.0000', '1990.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(51, '', 0, 0, '1999.0000', '1999.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(53, '', 0, 0, '1599.0000', '1599.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(57, '', 0, 0, '999.0000', '999.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(59, '', 0, 0, '699.0000', '699.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(61, '', 0, 0, '2499.0000', '2499.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(63, '', 0, 0, '1699.0000', '1699.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(65, '', 0, 0, '2999.0000', '2999.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(67, '', 0, 0, '2999.0000', '2999.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(69, '', 0, 0, '2999.0000', '2999.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(71, '', 0, 0, '1999.0000', '1999.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(73, '', 0, 0, '899.0000', '899.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(75, '', 0, 0, '1799.0000', '1799.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(77, '', 0, 0, '1999.0000', '1999.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(79, '', 0, 0, '999.0000', '999.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(81, '', 0, 0, '599.0000', '599.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(83, '', 0, 0, '799.0000', '799.0000', 0, NULL, 'instock', 0, '0.00', 3, 'taxable', ''),
(85, '', 0, 0, '1799.0000', '1799.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(88, '', 0, 0, '1999.0000', '1999.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(90, '', 0, 0, '1999.0000', '1999.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(92, '', 0, 0, '1999.0000', '1999.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(94, '', 0, 0, '1799.0000', '1799.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(96, '', 0, 0, '1799.0000', '1799.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(98, '', 0, 0, '2299.0000', '2299.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(100, '', 0, 0, '1999.0000', '1999.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(102, '', 0, 0, '2199.0000', '2199.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(104, '', 0, 0, '1799.0000', '1799.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(106, '', 0, 0, '2799.0000', '2799.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(108, '', 0, 0, '1999.0000', '1999.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(110, '', 0, 0, '1899.0000', '1899.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(112, '', 0, 0, '1299.0000', '1299.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(114, '', 0, 0, '1299.0000', '1299.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(116, '', 0, 0, '1599.0000', '1599.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(118, '', 0, 0, '2499.0000', '2499.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(120, '', 0, 0, '2499.0000', '2499.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(122, '', 0, 0, '1999.0000', '1999.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(124, '', 0, 0, '1999.0000', '1999.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(126, '', 0, 0, '1999.0000', '1999.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(128, '', 0, 0, '699.0000', '699.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(130, '', 0, 0, '2299.0000', '2299.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(132, '', 0, 0, '2499.0000', '2499.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(135, '', 0, 0, '1299.0000', '1299.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(137, '', 0, 0, '1299.0000', '1299.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(139, '', 0, 0, '1299.0000', '1299.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(141, '', 0, 0, '1799.0000', '1799.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(143, '', 0, 0, '1999.0000', '1999.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(145, '', 0, 0, '1999.0000', '1999.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(148, '', 0, 0, '1999.0000', '1999.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(150, '', 0, 0, '1999.0000', '1999.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(152, '', 0, 0, '1999.0000', '1999.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(154, '', 0, 0, '1599.0000', '1599.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(156, '', 0, 0, '899.0000', '899.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(158, '', 0, 0, '1599.0000', '1599.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(160, '', 0, 0, '1599.0000', '1599.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(162, '', 0, 0, '1599.0000', '1599.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(164, '', 0, 0, '1899.0000', '1899.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(166, '', 0, 0, '1999.0000', '1999.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(168, '', 0, 0, '1499.0000', '1499.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(170, '', 0, 0, '1599.0000', '1599.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(172, '', 0, 0, '699.0000', '699.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(174, '', 0, 0, '699.0000', '699.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(178, '', 0, 0, '899.0000', '899.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(180, '', 0, 0, '699.0000', '699.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(183, '', 0, 0, '999.0000', '999.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(185, '', 0, 0, '599.0000', '599.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(188, '', 0, 0, '699.0000', '699.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(190, '', 0, 0, '599.0000', '599.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(192, '', 0, 0, '699.0000', '699.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(194, '', 0, 0, '899.0000', '899.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(199, '', 0, 0, '599.0000', '599.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(201, '', 0, 0, '849.0000', '849.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', '');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_wc_reserved_stock`
--
-- Создание: Июн 01 2021 г., 11:16
--

DROP TABLE IF EXISTS `wp_wc_reserved_stock`;
CREATE TABLE `wp_wc_reserved_stock` (
  `order_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `stock_quantity` double NOT NULL DEFAULT '0',
  `timestamp` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `expires` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_wc_tax_rate_classes`
--
-- Создание: Июн 01 2021 г., 11:16
--

DROP TABLE IF EXISTS `wp_wc_tax_rate_classes`;
CREATE TABLE `wp_wc_tax_rate_classes` (
  `tax_rate_class_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_wc_tax_rate_classes`
--

INSERT INTO `wp_wc_tax_rate_classes` (`tax_rate_class_id`, `name`, `slug`) VALUES
(1, 'Пониженная ставка', 'ponizhennaja-stavka'),
(2, 'Нулевая ставка', 'nulevaja-stavka');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_wc_webhooks`
--
-- Создание: Июн 01 2021 г., 11:16
--

DROP TABLE IF EXISTS `wp_wc_webhooks`;
CREATE TABLE `wp_wc_webhooks` (
  `webhook_id` bigint(20) UNSIGNED NOT NULL,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `delivery_url` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `secret` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `topic` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `api_version` smallint(4) NOT NULL,
  `failure_count` smallint(10) NOT NULL DEFAULT '0',
  `pending_delivery` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_woocommerce_api_keys`
--
-- Создание: Июн 01 2021 г., 11:16
--

DROP TABLE IF EXISTS `wp_woocommerce_api_keys`;
CREATE TABLE `wp_woocommerce_api_keys` (
  `key_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `permissions` varchar(10) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `consumer_key` char(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `consumer_secret` char(43) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `nonces` longtext COLLATE utf8mb4_unicode_520_ci,
  `truncated_key` char(7) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `last_access` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_woocommerce_attribute_taxonomies`
--
-- Создание: Июн 01 2021 г., 11:16
--

DROP TABLE IF EXISTS `wp_woocommerce_attribute_taxonomies`;
CREATE TABLE `wp_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) UNSIGNED NOT NULL,
  `attribute_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_label` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `attribute_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_orderby` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_public` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_woocommerce_downloadable_product_permissions`
--
-- Создание: Июн 01 2021 г., 11:16
--

DROP TABLE IF EXISTS `wp_woocommerce_downloadable_product_permissions`;
CREATE TABLE `wp_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `download_id` varchar(36) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `order_key` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_email` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `downloads_remaining` varchar(9) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_woocommerce_log`
--
-- Создание: Июн 01 2021 г., 11:16
--

DROP TABLE IF EXISTS `wp_woocommerce_log`;
CREATE TABLE `wp_woocommerce_log` (
  `log_id` bigint(20) UNSIGNED NOT NULL,
  `timestamp` datetime NOT NULL,
  `level` smallint(4) NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `context` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_woocommerce_order_itemmeta`
--
-- Создание: Июн 01 2021 г., 11:16
--

DROP TABLE IF EXISTS `wp_woocommerce_order_itemmeta`;
CREATE TABLE `wp_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `order_item_id` bigint(20) UNSIGNED NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_woocommerce_order_itemmeta`
--

INSERT INTO `wp_woocommerce_order_itemmeta` (`meta_id`, `order_item_id`, `meta_key`, `meta_value`) VALUES
(1, 1, '_product_id', '10'),
(2, 1, '_variation_id', '0'),
(3, 1, '_qty', '13'),
(4, 1, '_tax_class', ''),
(5, 1, '_line_subtotal', '23270'),
(6, 1, '_line_subtotal_tax', '0'),
(7, 1, '_line_total', '23270'),
(8, 1, '_line_tax', '0'),
(9, 1, '_line_tax_data', 'a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),
(10, 2, '_product_id', '83'),
(11, 2, '_variation_id', '0'),
(12, 2, '_qty', '1'),
(13, 2, '_tax_class', ''),
(14, 2, '_line_subtotal', '799'),
(15, 2, '_line_subtotal_tax', '0'),
(16, 2, '_line_total', '799'),
(17, 2, '_line_tax', '0'),
(18, 2, '_line_tax_data', 'a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),
(19, 3, '_product_id', '83'),
(20, 3, '_variation_id', '0'),
(21, 3, '_qty', '1'),
(22, 3, '_tax_class', ''),
(23, 3, '_line_subtotal', '799'),
(24, 3, '_line_subtotal_tax', '0'),
(25, 3, '_line_total', '799'),
(26, 3, '_line_tax', '0'),
(27, 3, '_line_tax_data', 'a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),
(28, 4, '_product_id', '83'),
(29, 4, '_variation_id', '0'),
(30, 4, '_qty', '1'),
(31, 4, '_tax_class', ''),
(32, 4, '_line_subtotal', '799'),
(33, 4, '_line_subtotal_tax', '0'),
(34, 4, '_line_total', '799'),
(35, 4, '_line_tax', '0'),
(36, 4, '_line_tax_data', 'a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_woocommerce_order_items`
--
-- Создание: Июн 01 2021 г., 11:16
--

DROP TABLE IF EXISTS `wp_woocommerce_order_items`;
CREATE TABLE `wp_woocommerce_order_items` (
  `order_item_id` bigint(20) UNSIGNED NOT NULL,
  `order_item_name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `order_item_type` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `order_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_woocommerce_order_items`
--

INSERT INTO `wp_woocommerce_order_items` (`order_item_id`, `order_item_name`, `order_item_type`, `order_id`) VALUES
(1, 'ЖИЛЕТ С КАПЮШОНОМ ДЛЯ МАЛЬЧИКОВ', 'line_item', 22),
(2, 'БЕЖЕВАЯ ФУТБОЛКА С ПРИНТОМ CREATE', 'line_item', 206),
(3, 'БЕЖЕВАЯ ФУТБОЛКА С ПРИНТОМ CREATE', 'line_item', 220),
(4, 'БЕЖЕВАЯ ФУТБОЛКА С ПРИНТОМ CREATE', 'line_item', 221);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_woocommerce_payment_tokenmeta`
--
-- Создание: Июн 01 2021 г., 11:16
--

DROP TABLE IF EXISTS `wp_woocommerce_payment_tokenmeta`;
CREATE TABLE `wp_woocommerce_payment_tokenmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `payment_token_id` bigint(20) UNSIGNED NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_woocommerce_payment_tokens`
--
-- Создание: Июн 01 2021 г., 11:16
--

DROP TABLE IF EXISTS `wp_woocommerce_payment_tokens`;
CREATE TABLE `wp_woocommerce_payment_tokens` (
  `token_id` bigint(20) UNSIGNED NOT NULL,
  `gateway_id` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `token` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `type` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_woocommerce_sessions`
--
-- Создание: Июн 01 2021 г., 11:16
--

DROP TABLE IF EXISTS `wp_woocommerce_sessions`;
CREATE TABLE `wp_woocommerce_sessions` (
  `session_id` bigint(20) UNSIGNED NOT NULL,
  `session_key` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_expiry` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_woocommerce_sessions`
--

INSERT INTO `wp_woocommerce_sessions` (`session_id`, `session_key`, `session_value`, `session_expiry`) VALUES
(597, '16ba4766fe1da294593a456ddc68c8a5', 'a:8:{s:4:\"cart\";s:823:\"a:2:{s:32:\"fe9fc289c3ff0af142b6d3bead98a923\";a:11:{s:3:\"key\";s:32:\"fe9fc289c3ff0af142b6d3bead98a923\";s:10:\"product_id\";i:83;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:4;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:3196;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:3196;s:8:\"line_tax\";i:0;}s:32:\"7e7757b1e12abcb736ab9a754ffb617a\";a:11:{s:3:\"key\";s:32:\"7e7757b1e12abcb736ab9a754ffb617a\";s:10:\"product_id\";i:166;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:3;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:5997;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:5997;s:8:\"line_tax\";i:0;}}\";s:11:\"cart_totals\";s:396:\"a:15:{s:8:\"subtotal\";s:4:\"9193\";s:12:\"subtotal_tax\";d:0;s:14:\"shipping_total\";s:1:\"0\";s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";s:4:\"9193\";s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";s:1:\"0\";s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";s:4:\"9193\";s:9:\"total_tax\";d:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:10:\"wc_notices\";N;s:8:\"customer\";s:687:\"a:26:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:8:\"postcode\";s:0:\"\";s:4:\"city\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:5:\"state\";s:0:\"\";s:7:\"country\";s:2:\"RU\";s:17:\"shipping_postcode\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:14:\"shipping_state\";s:0:\"\";s:16:\"shipping_country\";s:2:\"RU\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";}\";}', 1625142724),
(604, 'c30411ec87ae1da4db7e796e225189df', 'a:8:{s:4:\"cart\";s:415:\"a:1:{s:32:\"7f6ffaa6bb0b408017b62254211691b5\";a:11:{s:3:\"key\";s:32:\"7f6ffaa6bb0b408017b62254211691b5\";s:10:\"product_id\";i:112;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:1299;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:1299;s:8:\"line_tax\";i:0;}}\";s:11:\"cart_totals\";s:396:\"a:15:{s:8:\"subtotal\";s:4:\"1299\";s:12:\"subtotal_tax\";d:0;s:14:\"shipping_total\";s:1:\"0\";s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";s:4:\"1299\";s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";s:1:\"0\";s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";s:4:\"1299\";s:9:\"total_tax\";d:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:10:\"wc_notices\";N;s:8:\"customer\";s:687:\"a:26:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:8:\"postcode\";s:0:\"\";s:4:\"city\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:5:\"state\";s:0:\"\";s:7:\"country\";s:2:\"RU\";s:17:\"shipping_postcode\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:14:\"shipping_state\";s:0:\"\";s:16:\"shipping_country\";s:2:\"RU\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";}\";}', 1625186462),
(605, '6b6b5139033458093a180a0a17a5024d', 'a:8:{s:4:\"cart\";s:413:\"a:1:{s:32:\"1c9ac0159c94d8d0cbedc973445af2da\";a:11:{s:3:\"key\";s:32:\"1c9ac0159c94d8d0cbedc973445af2da\";s:10:\"product_id\";i:156;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:899;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:899;s:8:\"line_tax\";i:0;}}\";s:11:\"cart_totals\";s:393:\"a:15:{s:8:\"subtotal\";s:3:\"899\";s:12:\"subtotal_tax\";d:0;s:14:\"shipping_total\";s:1:\"0\";s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";s:3:\"899\";s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";s:1:\"0\";s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";s:3:\"899\";s:9:\"total_tax\";d:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:10:\"wc_notices\";N;s:8:\"customer\";s:687:\"a:26:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:8:\"postcode\";s:0:\"\";s:4:\"city\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:5:\"state\";s:0:\"\";s:7:\"country\";s:2:\"RU\";s:17:\"shipping_postcode\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:14:\"shipping_state\";s:0:\"\";s:16:\"shipping_country\";s:2:\"RU\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";}\";}', 1625217568),
(606, '9bb974c0e1decd01a83c449f34c17fae', 'a:8:{s:4:\"cart\";s:415:\"a:1:{s:32:\"65ded5353c5ee48d0b7d48c591b8f430\";a:11:{s:3:\"key\";s:32:\"65ded5353c5ee48d0b7d48c591b8f430\";s:10:\"product_id\";i:132;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:2499;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:2499;s:8:\"line_tax\";i:0;}}\";s:11:\"cart_totals\";s:396:\"a:15:{s:8:\"subtotal\";s:4:\"2499\";s:12:\"subtotal_tax\";d:0;s:14:\"shipping_total\";s:1:\"0\";s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";s:4:\"2499\";s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";s:1:\"0\";s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";s:4:\"2499\";s:9:\"total_tax\";d:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:10:\"wc_notices\";N;s:8:\"customer\";s:687:\"a:26:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:8:\"postcode\";s:0:\"\";s:4:\"city\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:5:\"state\";s:0:\"\";s:7:\"country\";s:2:\"RU\";s:17:\"shipping_postcode\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:14:\"shipping_state\";s:0:\"\";s:16:\"shipping_country\";s:2:\"RU\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";}\";}', 1625228483),
(607, '127183ac47af694ad6c5c7d62366a641', 'a:8:{s:4:\"cart\";s:413:\"a:1:{s:32:\"76dc611d6ebaafc66cc0879c71b5db5c\";a:11:{s:3:\"key\";s:32:\"76dc611d6ebaafc66cc0879c71b5db5c\";s:10:\"product_id\";i:128;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:699;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:699;s:8:\"line_tax\";i:0;}}\";s:11:\"cart_totals\";s:393:\"a:15:{s:8:\"subtotal\";s:3:\"699\";s:12:\"subtotal_tax\";d:0;s:14:\"shipping_total\";s:1:\"0\";s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";s:3:\"699\";s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";s:1:\"0\";s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";s:3:\"699\";s:9:\"total_tax\";d:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:10:\"wc_notices\";N;s:8:\"customer\";s:687:\"a:26:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:8:\"postcode\";s:0:\"\";s:4:\"city\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:5:\"state\";s:0:\"\";s:7:\"country\";s:2:\"RU\";s:17:\"shipping_postcode\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:14:\"shipping_state\";s:0:\"\";s:16:\"shipping_country\";s:2:\"RU\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";}\";}', 1625238001),
(608, 'b41a1414bffe89cd38f94195f6797e11', 'a:8:{s:4:\"cart\";s:415:\"a:1:{s:32:\"b73ce398c39f506af761d2277d853a92\";a:11:{s:3:\"key\";s:32:\"b73ce398c39f506af761d2277d853a92\";s:10:\"product_id\";i:160;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:1599;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:1599;s:8:\"line_tax\";i:0;}}\";s:11:\"cart_totals\";s:396:\"a:15:{s:8:\"subtotal\";s:4:\"1599\";s:12:\"subtotal_tax\";d:0;s:14:\"shipping_total\";s:1:\"0\";s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";s:4:\"1599\";s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";s:1:\"0\";s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";s:4:\"1599\";s:9:\"total_tax\";d:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:10:\"wc_notices\";N;s:8:\"customer\";s:687:\"a:26:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:8:\"postcode\";s:0:\"\";s:4:\"city\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:5:\"state\";s:0:\"\";s:7:\"country\";s:2:\"RU\";s:17:\"shipping_postcode\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:14:\"shipping_state\";s:0:\"\";s:16:\"shipping_country\";s:2:\"RU\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";}\";}', 1625241331),
(609, 'c90486db019b951ed43f9865e969b4d1', 'a:8:{s:4:\"cart\";s:413:\"a:1:{s:32:\"bf8229696f7a3bb4700cfddef19fa23f\";a:11:{s:3:\"key\";s:32:\"bf8229696f7a3bb4700cfddef19fa23f\";s:10:\"product_id\";i:174;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:699;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:699;s:8:\"line_tax\";i:0;}}\";s:11:\"cart_totals\";s:393:\"a:15:{s:8:\"subtotal\";s:3:\"699\";s:12:\"subtotal_tax\";d:0;s:14:\"shipping_total\";s:1:\"0\";s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";s:3:\"699\";s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";s:1:\"0\";s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";s:3:\"699\";s:9:\"total_tax\";d:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:10:\"wc_notices\";N;s:8:\"customer\";s:687:\"a:26:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:8:\"postcode\";s:0:\"\";s:4:\"city\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:5:\"state\";s:0:\"\";s:7:\"country\";s:2:\"RU\";s:17:\"shipping_postcode\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:14:\"shipping_state\";s:0:\"\";s:16:\"shipping_country\";s:2:\"RU\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";}\";}', 1625246448),
(610, '8cab5f74839ece5cffa72dfc2567fc87', 'a:8:{s:4:\"cart\";s:413:\"a:1:{s:32:\"1c9ac0159c94d8d0cbedc973445af2da\";a:11:{s:3:\"key\";s:32:\"1c9ac0159c94d8d0cbedc973445af2da\";s:10:\"product_id\";i:156;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:899;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:899;s:8:\"line_tax\";i:0;}}\";s:11:\"cart_totals\";s:393:\"a:15:{s:8:\"subtotal\";s:3:\"899\";s:12:\"subtotal_tax\";d:0;s:14:\"shipping_total\";s:1:\"0\";s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";s:3:\"899\";s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";s:1:\"0\";s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";s:3:\"899\";s:9:\"total_tax\";d:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:10:\"wc_notices\";N;s:8:\"customer\";s:687:\"a:26:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:8:\"postcode\";s:0:\"\";s:4:\"city\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:5:\"state\";s:0:\"\";s:7:\"country\";s:2:\"RU\";s:17:\"shipping_postcode\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:14:\"shipping_state\";s:0:\"\";s:16:\"shipping_country\";s:2:\"RU\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";}\";}', 1625246451),
(611, 'b75844d884b0004b1bf3e95d7a26a410', 'a:8:{s:4:\"cart\";s:414:\"a:1:{s:32:\"28dd2c7955ce926456240b2ff0100bde\";a:11:{s:3:\"key\";s:32:\"28dd2c7955ce926456240b2ff0100bde\";s:10:\"product_id\";i:77;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:1999;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:1999;s:8:\"line_tax\";i:0;}}\";s:11:\"cart_totals\";s:396:\"a:15:{s:8:\"subtotal\";s:4:\"1999\";s:12:\"subtotal_tax\";d:0;s:14:\"shipping_total\";s:1:\"0\";s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";s:4:\"1999\";s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";s:1:\"0\";s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";s:4:\"1999\";s:9:\"total_tax\";d:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:10:\"wc_notices\";N;s:8:\"customer\";s:687:\"a:26:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:8:\"postcode\";s:0:\"\";s:4:\"city\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:5:\"state\";s:0:\"\";s:7:\"country\";s:2:\"RU\";s:17:\"shipping_postcode\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:14:\"shipping_state\";s:0:\"\";s:16:\"shipping_country\";s:2:\"RU\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";}\";}', 1625246456),
(612, 'd12a73fd2ddf4c42f2ff27ce5f40ed96', 'a:8:{s:4:\"cart\";s:415:\"a:1:{s:32:\"7e7757b1e12abcb736ab9a754ffb617a\";a:11:{s:3:\"key\";s:32:\"7e7757b1e12abcb736ab9a754ffb617a\";s:10:\"product_id\";i:166;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:1999;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:1999;s:8:\"line_tax\";i:0;}}\";s:11:\"cart_totals\";s:396:\"a:15:{s:8:\"subtotal\";s:4:\"1999\";s:12:\"subtotal_tax\";d:0;s:14:\"shipping_total\";s:1:\"0\";s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";s:4:\"1999\";s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";s:1:\"0\";s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";s:4:\"1999\";s:9:\"total_tax\";d:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:10:\"wc_notices\";N;s:8:\"customer\";s:687:\"a:26:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:8:\"postcode\";s:0:\"\";s:4:\"city\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:5:\"state\";s:0:\"\";s:7:\"country\";s:2:\"RU\";s:17:\"shipping_postcode\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:14:\"shipping_state\";s:0:\"\";s:16:\"shipping_country\";s:2:\"RU\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";}\";}', 1625246457),
(613, '8ee3e9631491eb130cfaf6d485e18b10', 'a:8:{s:4:\"cart\";s:415:\"a:1:{s:32:\"7f1de29e6da19d22b51c68001e7e0e54\";a:11:{s:3:\"key\";s:32:\"7f1de29e6da19d22b51c68001e7e0e54\";s:10:\"product_id\";i:135;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:1299;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:1299;s:8:\"line_tax\";i:0;}}\";s:11:\"cart_totals\";s:396:\"a:15:{s:8:\"subtotal\";s:4:\"1299\";s:12:\"subtotal_tax\";d:0;s:14:\"shipping_total\";s:1:\"0\";s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";s:4:\"1299\";s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";s:1:\"0\";s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";s:4:\"1299\";s:9:\"total_tax\";d:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:10:\"wc_notices\";N;s:8:\"customer\";s:687:\"a:26:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:8:\"postcode\";s:0:\"\";s:4:\"city\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:5:\"state\";s:0:\"\";s:7:\"country\";s:2:\"RU\";s:17:\"shipping_postcode\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:14:\"shipping_state\";s:0:\"\";s:16:\"shipping_country\";s:2:\"RU\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";}\";}', 1625246458),
(614, 'ca0c2f1f3103faaa1745ae4b0055e992', 'a:8:{s:4:\"cart\";s:414:\"a:1:{s:32:\"f4b9ec30ad9f68f89b29639786cb62ef\";a:11:{s:3:\"key\";s:32:\"f4b9ec30ad9f68f89b29639786cb62ef\";s:10:\"product_id\";i:94;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:1799;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:1799;s:8:\"line_tax\";i:0;}}\";s:11:\"cart_totals\";s:396:\"a:15:{s:8:\"subtotal\";s:4:\"1799\";s:12:\"subtotal_tax\";d:0;s:14:\"shipping_total\";s:1:\"0\";s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";s:4:\"1799\";s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";s:1:\"0\";s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";s:4:\"1799\";s:9:\"total_tax\";d:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:10:\"wc_notices\";N;s:8:\"customer\";s:687:\"a:26:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:8:\"postcode\";s:0:\"\";s:4:\"city\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:5:\"state\";s:0:\"\";s:7:\"country\";s:2:\"RU\";s:17:\"shipping_postcode\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:14:\"shipping_state\";s:0:\"\";s:16:\"shipping_country\";s:2:\"RU\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";}\";}', 1625246460),
(615, 'cacd19f10bd6c0470fd4fa67d8d8459d', 'a:8:{s:4:\"cart\";s:412:\"a:1:{s:32:\"fe9fc289c3ff0af142b6d3bead98a923\";a:11:{s:3:\"key\";s:32:\"fe9fc289c3ff0af142b6d3bead98a923\";s:10:\"product_id\";i:83;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:799;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:799;s:8:\"line_tax\";i:0;}}\";s:11:\"cart_totals\";s:393:\"a:15:{s:8:\"subtotal\";s:3:\"799\";s:12:\"subtotal_tax\";d:0;s:14:\"shipping_total\";s:1:\"0\";s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";s:3:\"799\";s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";s:1:\"0\";s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";s:3:\"799\";s:9:\"total_tax\";d:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:10:\"wc_notices\";N;s:8:\"customer\";s:687:\"a:26:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:8:\"postcode\";s:0:\"\";s:4:\"city\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:5:\"state\";s:0:\"\";s:7:\"country\";s:2:\"RU\";s:17:\"shipping_postcode\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:14:\"shipping_state\";s:0:\"\";s:16:\"shipping_country\";s:2:\"RU\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";}\";}', 1625285766);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_woocommerce_shipping_zones`
--
-- Создание: Июн 01 2021 г., 11:16
--

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zones`;
CREATE TABLE `wp_woocommerce_shipping_zones` (
  `zone_id` bigint(20) UNSIGNED NOT NULL,
  `zone_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `zone_order` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_woocommerce_shipping_zone_locations`
--
-- Создание: Июн 01 2021 г., 11:16
--

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_locations`;
CREATE TABLE `wp_woocommerce_shipping_zone_locations` (
  `location_id` bigint(20) UNSIGNED NOT NULL,
  `zone_id` bigint(20) UNSIGNED NOT NULL,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_woocommerce_shipping_zone_methods`
--
-- Создание: Июн 01 2021 г., 11:16
--

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_methods`;
CREATE TABLE `wp_woocommerce_shipping_zone_methods` (
  `zone_id` bigint(20) UNSIGNED NOT NULL,
  `instance_id` bigint(20) UNSIGNED NOT NULL,
  `method_id` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `method_order` bigint(20) UNSIGNED NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_woocommerce_tax_rates`
--
-- Создание: Июн 01 2021 г., 11:16
--

DROP TABLE IF EXISTS `wp_woocommerce_tax_rates`;
CREATE TABLE `wp_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) UNSIGNED NOT NULL,
  `tax_rate_country` varchar(2) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate` varchar(8) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) UNSIGNED NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT '0',
  `tax_rate_shipping` int(1) NOT NULL DEFAULT '1',
  `tax_rate_order` bigint(20) UNSIGNED NOT NULL,
  `tax_rate_class` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_woocommerce_tax_rate_locations`
--
-- Создание: Июн 01 2021 г., 11:16
--

DROP TABLE IF EXISTS `wp_woocommerce_tax_rate_locations`;
CREATE TABLE `wp_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) UNSIGNED NOT NULL,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tax_rate_id` bigint(20) UNSIGNED NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `wp_actionscheduler_actions`
--
ALTER TABLE `wp_actionscheduler_actions`
  ADD PRIMARY KEY (`action_id`),
  ADD KEY `hook` (`hook`),
  ADD KEY `status` (`status`),
  ADD KEY `scheduled_date_gmt` (`scheduled_date_gmt`),
  ADD KEY `args` (`args`),
  ADD KEY `group_id` (`group_id`),
  ADD KEY `last_attempt_gmt` (`last_attempt_gmt`),
  ADD KEY `claim_id` (`claim_id`);

--
-- Индексы таблицы `wp_actionscheduler_claims`
--
ALTER TABLE `wp_actionscheduler_claims`
  ADD PRIMARY KEY (`claim_id`),
  ADD KEY `date_created_gmt` (`date_created_gmt`);

--
-- Индексы таблицы `wp_actionscheduler_groups`
--
ALTER TABLE `wp_actionscheduler_groups`
  ADD PRIMARY KEY (`group_id`),
  ADD KEY `slug` (`slug`(191));

--
-- Индексы таблицы `wp_actionscheduler_logs`
--
ALTER TABLE `wp_actionscheduler_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `action_id` (`action_id`),
  ADD KEY `log_date_gmt` (`log_date_gmt`);

--
-- Индексы таблицы `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Индексы таблицы `wp_comments`
--
ALTER TABLE `wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10)),
  ADD KEY `woo_idx_comment_type` (`comment_type`);

--
-- Индексы таблицы `wp_links`
--
ALTER TABLE `wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Индексы таблицы `wp_options`
--
ALTER TABLE `wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`),
  ADD KEY `autoload` (`autoload`);

--
-- Индексы таблицы `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Индексы таблицы `wp_posts`
--
ALTER TABLE `wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Индексы таблицы `wp_robomarket_orders`
--
ALTER TABLE `wp_robomarket_orders`
  ADD PRIMARY KEY (`post_id`,`other_id`),
  ADD UNIQUE KEY `other_id` (`other_id`),
  ADD UNIQUE KEY `post_id` (`post_id`);

--
-- Индексы таблицы `wp_sms_stats`
--
ALTER TABLE `wp_sms_stats`
  ADD PRIMARY KEY (`sms_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `status` (`status`);

--
-- Индексы таблицы `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Индексы таблицы `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Индексы таблицы `wp_term_relationships`
--
ALTER TABLE `wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Индексы таблицы `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Индексы таблицы `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Индексы таблицы `wp_users`
--
ALTER TABLE `wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- Индексы таблицы `wp_wc_admin_notes`
--
ALTER TABLE `wp_wc_admin_notes`
  ADD PRIMARY KEY (`note_id`);

--
-- Индексы таблицы `wp_wc_admin_note_actions`
--
ALTER TABLE `wp_wc_admin_note_actions`
  ADD PRIMARY KEY (`action_id`),
  ADD KEY `note_id` (`note_id`);

--
-- Индексы таблицы `wp_wc_category_lookup`
--
ALTER TABLE `wp_wc_category_lookup`
  ADD PRIMARY KEY (`category_tree_id`,`category_id`);

--
-- Индексы таблицы `wp_wc_customer_lookup`
--
ALTER TABLE `wp_wc_customer_lookup`
  ADD PRIMARY KEY (`customer_id`),
  ADD UNIQUE KEY `user_id` (`user_id`),
  ADD KEY `email` (`email`);

--
-- Индексы таблицы `wp_wc_download_log`
--
ALTER TABLE `wp_wc_download_log`
  ADD PRIMARY KEY (`download_log_id`),
  ADD KEY `permission_id` (`permission_id`),
  ADD KEY `timestamp` (`timestamp`);

--
-- Индексы таблицы `wp_wc_order_coupon_lookup`
--
ALTER TABLE `wp_wc_order_coupon_lookup`
  ADD PRIMARY KEY (`order_id`,`coupon_id`),
  ADD KEY `coupon_id` (`coupon_id`),
  ADD KEY `date_created` (`date_created`);

--
-- Индексы таблицы `wp_wc_order_product_lookup`
--
ALTER TABLE `wp_wc_order_product_lookup`
  ADD PRIMARY KEY (`order_item_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `date_created` (`date_created`);

--
-- Индексы таблицы `wp_wc_order_stats`
--
ALTER TABLE `wp_wc_order_stats`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `date_created` (`date_created`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `status` (`status`(191));

--
-- Индексы таблицы `wp_wc_order_tax_lookup`
--
ALTER TABLE `wp_wc_order_tax_lookup`
  ADD PRIMARY KEY (`order_id`,`tax_rate_id`),
  ADD KEY `tax_rate_id` (`tax_rate_id`),
  ADD KEY `date_created` (`date_created`);

--
-- Индексы таблицы `wp_wc_product_meta_lookup`
--
ALTER TABLE `wp_wc_product_meta_lookup`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `virtual` (`virtual`),
  ADD KEY `downloadable` (`downloadable`),
  ADD KEY `stock_status` (`stock_status`),
  ADD KEY `stock_quantity` (`stock_quantity`),
  ADD KEY `onsale` (`onsale`),
  ADD KEY `min_max_price` (`min_price`,`max_price`);

--
-- Индексы таблицы `wp_wc_reserved_stock`
--
ALTER TABLE `wp_wc_reserved_stock`
  ADD PRIMARY KEY (`order_id`,`product_id`);

--
-- Индексы таблицы `wp_wc_tax_rate_classes`
--
ALTER TABLE `wp_wc_tax_rate_classes`
  ADD PRIMARY KEY (`tax_rate_class_id`),
  ADD UNIQUE KEY `slug` (`slug`(191));

--
-- Индексы таблицы `wp_wc_webhooks`
--
ALTER TABLE `wp_wc_webhooks`
  ADD PRIMARY KEY (`webhook_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Индексы таблицы `wp_woocommerce_api_keys`
--
ALTER TABLE `wp_woocommerce_api_keys`
  ADD PRIMARY KEY (`key_id`),
  ADD KEY `consumer_key` (`consumer_key`),
  ADD KEY `consumer_secret` (`consumer_secret`);

--
-- Индексы таблицы `wp_woocommerce_attribute_taxonomies`
--
ALTER TABLE `wp_woocommerce_attribute_taxonomies`
  ADD PRIMARY KEY (`attribute_id`),
  ADD KEY `attribute_name` (`attribute_name`(20));

--
-- Индексы таблицы `wp_woocommerce_downloadable_product_permissions`
--
ALTER TABLE `wp_woocommerce_downloadable_product_permissions`
  ADD PRIMARY KEY (`permission_id`),
  ADD KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(16),`download_id`),
  ADD KEY `download_order_product` (`download_id`,`order_id`,`product_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `user_order_remaining_expires` (`user_id`,`order_id`,`downloads_remaining`,`access_expires`);

--
-- Индексы таблицы `wp_woocommerce_log`
--
ALTER TABLE `wp_woocommerce_log`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `level` (`level`);

--
-- Индексы таблицы `wp_woocommerce_order_itemmeta`
--
ALTER TABLE `wp_woocommerce_order_itemmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `order_item_id` (`order_item_id`),
  ADD KEY `meta_key` (`meta_key`(32));

--
-- Индексы таблицы `wp_woocommerce_order_items`
--
ALTER TABLE `wp_woocommerce_order_items`
  ADD PRIMARY KEY (`order_item_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Индексы таблицы `wp_woocommerce_payment_tokenmeta`
--
ALTER TABLE `wp_woocommerce_payment_tokenmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `payment_token_id` (`payment_token_id`),
  ADD KEY `meta_key` (`meta_key`(32));

--
-- Индексы таблицы `wp_woocommerce_payment_tokens`
--
ALTER TABLE `wp_woocommerce_payment_tokens`
  ADD PRIMARY KEY (`token_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Индексы таблицы `wp_woocommerce_sessions`
--
ALTER TABLE `wp_woocommerce_sessions`
  ADD PRIMARY KEY (`session_id`),
  ADD UNIQUE KEY `session_key` (`session_key`);

--
-- Индексы таблицы `wp_woocommerce_shipping_zones`
--
ALTER TABLE `wp_woocommerce_shipping_zones`
  ADD PRIMARY KEY (`zone_id`);

--
-- Индексы таблицы `wp_woocommerce_shipping_zone_locations`
--
ALTER TABLE `wp_woocommerce_shipping_zone_locations`
  ADD PRIMARY KEY (`location_id`),
  ADD KEY `location_id` (`location_id`),
  ADD KEY `location_type_code` (`location_type`(10),`location_code`(20));

--
-- Индексы таблицы `wp_woocommerce_shipping_zone_methods`
--
ALTER TABLE `wp_woocommerce_shipping_zone_methods`
  ADD PRIMARY KEY (`instance_id`);

--
-- Индексы таблицы `wp_woocommerce_tax_rates`
--
ALTER TABLE `wp_woocommerce_tax_rates`
  ADD PRIMARY KEY (`tax_rate_id`),
  ADD KEY `tax_rate_country` (`tax_rate_country`),
  ADD KEY `tax_rate_state` (`tax_rate_state`(2)),
  ADD KEY `tax_rate_class` (`tax_rate_class`(10)),
  ADD KEY `tax_rate_priority` (`tax_rate_priority`);

--
-- Индексы таблицы `wp_woocommerce_tax_rate_locations`
--
ALTER TABLE `wp_woocommerce_tax_rate_locations`
  ADD PRIMARY KEY (`location_id`),
  ADD KEY `tax_rate_id` (`tax_rate_id`),
  ADD KEY `location_type_code` (`location_type`(10),`location_code`(20));

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `wp_actionscheduler_actions`
--
ALTER TABLE `wp_actionscheduler_actions`
  MODIFY `action_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT для таблицы `wp_actionscheduler_claims`
--
ALTER TABLE `wp_actionscheduler_claims`
  MODIFY `claim_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2896;

--
-- AUTO_INCREMENT для таблицы `wp_actionscheduler_groups`
--
ALTER TABLE `wp_actionscheduler_groups`
  MODIFY `group_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `wp_actionscheduler_logs`
--
ALTER TABLE `wp_actionscheduler_logs`
  MODIFY `log_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT для таблицы `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `wp_comments`
--
ALTER TABLE `wp_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `wp_links`
--
ALTER TABLE `wp_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `wp_options`
--
ALTER TABLE `wp_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7142;

--
-- AUTO_INCREMENT для таблицы `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2019;

--
-- AUTO_INCREMENT для таблицы `wp_posts`
--
ALTER TABLE `wp_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=223;

--
-- AUTO_INCREMENT для таблицы `wp_sms_stats`
--
ALTER TABLE `wp_sms_stats`
  MODIFY `sms_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT для таблицы `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT для таблицы `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT для таблицы `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT для таблицы `wp_users`
--
ALTER TABLE `wp_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `wp_wc_admin_notes`
--
ALTER TABLE `wp_wc_admin_notes`
  MODIFY `note_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT для таблицы `wp_wc_admin_note_actions`
--
ALTER TABLE `wp_wc_admin_note_actions`
  MODIFY `action_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2466;

--
-- AUTO_INCREMENT для таблицы `wp_wc_customer_lookup`
--
ALTER TABLE `wp_wc_customer_lookup`
  MODIFY `customer_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `wp_wc_download_log`
--
ALTER TABLE `wp_wc_download_log`
  MODIFY `download_log_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `wp_wc_tax_rate_classes`
--
ALTER TABLE `wp_wc_tax_rate_classes`
  MODIFY `tax_rate_class_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `wp_wc_webhooks`
--
ALTER TABLE `wp_wc_webhooks`
  MODIFY `webhook_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `wp_woocommerce_api_keys`
--
ALTER TABLE `wp_woocommerce_api_keys`
  MODIFY `key_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `wp_woocommerce_attribute_taxonomies`
--
ALTER TABLE `wp_woocommerce_attribute_taxonomies`
  MODIFY `attribute_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `wp_woocommerce_downloadable_product_permissions`
--
ALTER TABLE `wp_woocommerce_downloadable_product_permissions`
  MODIFY `permission_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `wp_woocommerce_log`
--
ALTER TABLE `wp_woocommerce_log`
  MODIFY `log_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `wp_woocommerce_order_itemmeta`
--
ALTER TABLE `wp_woocommerce_order_itemmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT для таблицы `wp_woocommerce_order_items`
--
ALTER TABLE `wp_woocommerce_order_items`
  MODIFY `order_item_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `wp_woocommerce_payment_tokenmeta`
--
ALTER TABLE `wp_woocommerce_payment_tokenmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `wp_woocommerce_payment_tokens`
--
ALTER TABLE `wp_woocommerce_payment_tokens`
  MODIFY `token_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `wp_woocommerce_sessions`
--
ALTER TABLE `wp_woocommerce_sessions`
  MODIFY `session_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=616;

--
-- AUTO_INCREMENT для таблицы `wp_woocommerce_shipping_zones`
--
ALTER TABLE `wp_woocommerce_shipping_zones`
  MODIFY `zone_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `wp_woocommerce_shipping_zone_locations`
--
ALTER TABLE `wp_woocommerce_shipping_zone_locations`
  MODIFY `location_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `wp_woocommerce_shipping_zone_methods`
--
ALTER TABLE `wp_woocommerce_shipping_zone_methods`
  MODIFY `instance_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `wp_woocommerce_tax_rates`
--
ALTER TABLE `wp_woocommerce_tax_rates`
  MODIFY `tax_rate_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `wp_woocommerce_tax_rate_locations`
--
ALTER TABLE `wp_woocommerce_tax_rate_locations`
  MODIFY `location_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `wp_wc_download_log`
--
ALTER TABLE `wp_wc_download_log`
  ADD CONSTRAINT `fk_wp_wc_download_log_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `wp_woocommerce_downloadable_product_permissions` (`permission_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
